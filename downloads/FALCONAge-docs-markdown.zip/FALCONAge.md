# FALCONAge
Bhagesh Hunakunti

- [Chapter 1. FALCONAge](#chapter-1-falconage)
  - [Run it in three commands](#run-it-in-three-commands)
  - [Input](#input)
  - [Output](#output)
  - [Where to go next](#where-to-go-next)
  - [Citation](#citation)
- [Chapter 2. Install](#chapter-2-install)
  - [With Docker (recommended)](#with-docker-recommended)
  - [Without Docker](#without-docker)
  - [When something looks wrong](#when-something-looks-wrong)
- [Chapter 3. Your first run](#chapter-3-your-first-run)
  - [1. Run the demo](#1-run-the-demo)
  - [2. Output files](#2-output-files)
  - [3. Run your own data](#3-run-your-own-data)
  - [4. In a pipeline](#4-in-a-pipeline)
  - [The same in Python or R](#the-same-in-python-or-r)
  - [Scoring](#scoring)
  - [Interpreting the result](#interpreting-the-result)
- [Chapter 4. About and design](#chapter-4-about-and-design)
  - [Scope and limitations](#scope-and-limitations)
- [Chapter 5. The Claude skill](#chapter-5-the-claude-skill)
- [Chapter 6. Loading your data](#chapter-6-loading-your-data)
  - [Readers by input format](#readers-by-input-format)
  - [A beta matrix](#a-beta-matrix)
  - [A GEO series matrix](#a-geo-series-matrix)
  - [A ComputAgeBench study](#a-computagebench-study)
  - [A targeted assay](#a-targeted-assay)
  - [Clinical chemistry](#clinical-chemistry)
  - [NMR metabolomics](#nmr-metabolomics)
  - [After loading](#after-loading)
- [Chapter 7. Preparing data and
  coverage](#chapter-7-preparing-data-and-coverage)
  - [Preparing the input](#preparing-the-input)
  - [Methylation clock coverage](#methylation-clock-coverage)
- [Chapter 8. Age acceleration](#chapter-8-age-acceleration)
  - [Age acceleration](#age-acceleration)
- [Chapter 9. Uncertainty, specimen and
  platform](#chapter-9-uncertainty-specimen-and-platform)
  - [Measurement uncertainty](#measurement-uncertainty)
- [Chapter 10. Clinical chemistry and
  survival](#chapter-10-clinical-chemistry-and-survival)
  - [Clinical chemistry](#clinical-chemistry-1)
  - [Survival and association](#survival-and-association)
- [Chapter 11. Benchmarking](#chapter-11-benchmarking)
- [Chapter 12. Beyond the clock
  score](#chapter-12-beyond-the-clock-score)
  - [Disorder: entropy, drift and the
    barometer](#disorder-entropy-drift-and-the-barometer)
  - [Repertoire structure](#repertoire-structure)
  - [Where a clock’s weight sits](#where-a-clocks-weight-sits)
  - [Reliability: trait, state and
    technical](#reliability-trait-state-and-technical)
  - [Mosaic ages within a tissue](#mosaic-ages-within-a-tissue)
  - [What none of this is](#what-none-of-this-is)
- [Chapter 13. Figures and reports](#chapter-13-figures-and-reports)
  - [Reporting](#reporting)
  - [Plots](#plots)
- [Chapter 14. Figure gallery](#chapter-14-figure-gallery)
  - [Start here](#start-here)
  - [Is the clock calibrated](#is-the-clock-calibrated)
  - [Age acceleration](#age-acceleration-1)
  - [Outcomes](#outcomes)
  - [How the clocks relate](#how-the-clocks-relate)
  - [Benchmarking](#benchmarking)
  - [Data quality](#data-quality)
  - [Other](#other)
  - [In total](#in-total)
- [Chapter 15. Build a clock](#chapter-15-build-a-clock)
  - [1. Compare learners](#1-compare-learners)
  - [2. The learners](#2-the-learners)
  - [3. Read the comparison honestly](#3-read-the-comparison-honestly)
  - [4. Fit the chosen learner and save
    it](#4-fit-the-chosen-learner-and-save-it)
- [Chapter 16. Add a clock](#chapter-16-add-a-clock)
  - [1. Write the entry](#1-write-the-entry)
  - [2. Score it](#2-score-it)
  - [What is checked, and what a clock of your own does not
    get](#what-is-checked-and-what-a-clock-of-your-own-does-not-get)
- [Chapter 17. Stack clocks](#chapter-17-stack-clocks)
  - [1. Fit a stack](#1-fit-a-stack)
  - [2. Choose a method](#2-choose-a-method)
  - [3. Save it as a clock](#3-save-it-as-a-clock)
  - [Do not test a group difference on the samples the stack was fitted
    on](#do-not-test-a-group-difference-on-the-samples-the-stack-was-fitted-on)
- [Chapter 18. Choosing a clock](#chapter-18-choosing-a-clock)
  - [Choosing by research question](#choosing-by-research-question)
  - [Scale type and permitted
    operations](#scale-type-and-permitted-operations)
  - [Coverage and validity](#coverage-and-validity)
  - [Feature count and coefficient
    mass](#feature-count-and-coefficient-mass)
  - [Reliability](#reliability)
  - [Specimen type](#specimen-type)
  - [The clock catalogue](#the-clock-catalogue)
  - [Which clocks were trained on data like
    mine](#which-clocks-were-trained-on-data-like-mine)
- [Chapter 19. What a score means](#chapter-19-what-a-score-means)
  - [The clock catalogue](#the-clock-catalogue-1)
  - [Training targets, and what a score
    means](#training-targets-and-what-a-score-means)
  - [Scale types and permitted
    operations](#scale-types-and-permitted-operations)
  - [Output types and units](#output-types-and-units)
- [Chapter 20. Clock catalogue](#chapter-20-clock-catalogue)
  - [Querying it from code](#querying-it-from-code)
- [Chapter 21. Known discrepancies](#chapter-21-known-discrepancies)
- [Chapter 22. Published formulas and
  constants](#chapter-22-published-formulas-and-constants)
  - [Exact published formulas and
    constants](#exact-published-formulas-and-constants)
  - [Appendix F - Reproducing the four reference computations by
    hand](#appendix-f---reproducing-the-four-reference-computations-by-hand)
- [Chapter 23. Uncertainty, specimen and
  platform](#chapter-23-uncertainty-specimen-and-platform)
- [Chapter 24. Downstream statistics on an aging
  score](#chapter-24-downstream-statistics-on-an-aging-score)
- [Chapter 25. Benchmarking and
  validation](#chapter-25-benchmarking-and-validation)
- [Chapter 26. 23. Building a clock of your
  own](#chapter-26-23-building-a-clock-of-your-own)
  - [The objective](#the-objective)
  - [Choosing the penalty honestly](#choosing-the-penalty-honestly)
  - [The age transform](#the-age-transform)
  - [Feature selection is not
    settled](#feature-selection-is-not-settled)
  - [Two metrics that disagree, and both are
    needed](#two-metrics-that-disagree-and-both-are-needed)
  - [The step that gets skipped](#the-step-that-gets-skipped)
  - [What to publish](#what-to-publish)
  - [Fitting one here](#fitting-one-here)
- [Chapter 27. References](#chapter-27-references)
  - [Prior software this package builds
    on](#prior-software-this-package-builds-on)
  - [Foundational clocks](#foundational-clocks)
  - [Non-methylation clocks](#non-methylation-clocks)
  - [Methods, tooling, benchmarking](#methods-tooling-benchmarking)
  - [Biology of aging](#biology-of-aging)
  - [Sources traced while implementing the clocks they
    describe](#sources-traced-while-implementing-the-clocks-they-describe)
  - [Mechanism, limits and
    translation](#mechanism-limits-and-translation)
  - [Beyond the clock score: disorder, repertoire and coefficient
    mass](#beyond-the-clock-score-disorder-repertoire-and-coefficient-mass)

*Generated from the FALCONAge documentation site,
https://bhagesh-h.github.io/FALCONAge/*



# Chapter 1. FALCONAge

FALCONAge applies 68 published human aging clocks to DNA methylation,
clinical chemistry and NMR metabolomics data. Every clock ships its
coefficients and runs offline. Each score is reported with its unit, the
source of its coefficients and its technical standard error.

The input is data that is already preprocessed and quality controlled: a
beta matrix from an array pipeline such as
[methylarray](https://github.com/bhagesh-h/methylarray), a GEO series
matrix, a clinical chemistry table or a Nightingale NMR table.

### Run it in three commands

You need [Docker](https://docs.docker.com/get-docker/) and nothing else.
[Install](https://bhagesh-h.github.io/FALCONAge/start/install.html)
covers Docker itself and other ways to install.

**1. Get the image** (once, about 430 MB to download):

``` bash
docker pull bhagesh/falconage:1.0.0-cpu
```

**2. See it work** on a small synthetic dataset, in about a minute:

``` bash
docker run --rm -v "$PWD:/work" bhagesh/falconage:1.0.0-cpu demo
```

**3. Run your own data.** Put your beta matrix and, if you have one, a
sample sheet with each sample’s age, sex and tissue in the current
folder:

``` bash
docker run --rm -v "$PWD:/work" bhagesh/falconage:1.0.0-cpu run betas.csv --samples samples.csv
```

Open `betas_falconage/report.html`. [Your first
run](https://bhagesh-h.github.io/FALCONAge/start/quickstart.html)
explains every file the run writes and how to read the report.

### Input

| Input | Reader | Notes |
|----|----|----|
| Beta matrix (CSV, TSV, Parquet, `.h5ad`) | `read_betas()` | Normalised betas in either orientation; EPIC v2 identifiers are harmonised |
| GEO series matrix | `read_series_matrix()` | Sample characteristics become sample annotation |
| Targeted panel | `read_panel()` | Pyrosequencing, EpiTYPER, amplicon; the declared CpG list is checked, not intersected |
| ComputAgeBench study | `read_computage_bench()` | 65 harmonised case-control studies, pinned to a commit |
| Clinical chemistry | `read_clinical()` | Units declared per column, never inferred |
| Nightingale NMR | `read_nightingale()` | Column names translated to the names the scores were fitted with |

Raw IDATs, sequencing coverage files and proteomic or transcriptomic
tables are not read. Normalisation, detection filtering and sample QC
are done upstream.

### Output

- One score per sample per clock, for every catalogued clock the input
  supports
- **A technical standard error on every score**, propagated from
  published per-probe reliability through each clock’s weights, and a
  distribution-free prediction interval
- A coverage map of every clock’s CpGs across the genome, a coverage
  table per clock, and the expected shift in years caused by missing
  probes
- A run manifest recording the package and registry versions, the
  SHA-256 of every coefficient file, the reliability table behind the
  intervals, the floating-point precision, the imputation policy and
  every warning raised

**Execution.** One numerical core in Python, called from R through
reticulate, so a result is the same in either language.

**Refusals.** A saliva sample scored on a whole-blood clock (measured at
3.83–16.46 years of error in the same people). Cell-free DNA on any
array clock. Age acceleration on a pace-of-aging clock. A cohort-centred
clock given one sample. Each refusal names the measurement behind it.

### Where to go next

| You want to | Read |
|----|----|
| Install, including without Docker | [Install](https://bhagesh-h.github.io/FALCONAge/start/install.html) |
| Read the output files of a run | [Your first run](https://bhagesh-h.github.io/FALCONAge/start/quickstart.html) |
| Load a beta matrix, GEO series, clinical or NMR data | [Loading your data](https://bhagesh-h.github.io/FALCONAge/data/loading.html) |
| Pick the right clock for your question | [Choosing a clock](https://bhagesh-h.github.io/FALCONAge/clocks/choosing.html) |
| Fit, add or combine clocks of your own | [Build a clock](https://bhagesh-h.github.io/FALCONAge/own/compare.html) |
| Know what the tool refuses to do, and why | [About and design](https://bhagesh-h.github.io/FALCONAge/start/about.html) |
| Look up a function | [Python](https://bhagesh-h.github.io/FALCONAge/reference/index.html) or [R](https://bhagesh-h.github.io/FALCONAge/r/index.html) reference |

The whole site is also downloadable as PDF or markdown from the
**Download** menu.

### Citation

<!-- BEGIN GENERATED: citation -->

APA:

    Hunakunti, B. (2026). FALCONAge: Multiomic biological age and aging clock scoring in Python and R (Version 1.0.0) [Computer software]. https://github.com/bhagesh-h/FALCONAge

BibTeX:

``` bibtex
@software{falconage2026,
  author  = {Bhagesh Hunakunti},
  title   = {FALCONAge: Multiomic Biological Age and Aging Clock Scoring in Python and R},
  year    = {2026},
  version = {1.0.0},
  url     = {https://github.com/bhagesh-h/FALCONAge},
  license = {GPL-3.0-or-later}
}
```

In R, `citation("FALCONAge")`. The machine-readable version is
[CITATION.cff](https://github.com/bhagesh-h/FALCONAge/blob/main/CITATION.cff),
which is what GitHub’s *Cite this repository* button reads.

The clock FALCONAge computed for you is somebody else’s work, and citing
FALCONAge does not cite it. Every registry entry carries its primary
reference, so the list for an analysis comes out of the analysis:

<div class="panel-tabset">

#### Python

``` python
fa.registry.load().get("dnamphenoage").cite("bibtex")
```

#### R

``` r
cite_clock("dnamphenoage", "bibtex")
```

</div>

<!-- END GENERATED: citation -->



# Chapter 2. Install

### With Docker (recommended)

One image carries Python, R, the `falconage` command and every bundled
clock at pinned versions, so the same input gives the same numbers on
any machine. Nothing else needs installing.

**1. Install Docker.** [Docker
Desktop](https://www.docker.com/products/docker-desktop/) on Windows or
macOS, Docker Engine on Linux. Start it, then check it answers:

``` bash
docker --version
```

“command not found” or “cannot connect to the Docker daemon” means
Docker is not installed or not running; nothing below works until it is.

**2. Get the image:**

``` bash
docker pull bhagesh/falconage:1.0.0-cpu
```

**3. Check it:**

``` bash
docker run --rm bhagesh/falconage:1.0.0-cpu config
```

<div class="falcon-output">

    FALCONAge 1.0.0
      registry     1.1.0  (68 human clocks, 68 score offline)
      numpy        2.5.1
      cpu cores    8

</div>

That is the whole install. [Your first
run](https://bhagesh-h.github.io/FALCONAge/start/quickstart.html) is the
next step.

#### Which image

| Tag | Contains | Use it when |
|----|----|----|
| `1.0.0-cpu` (also `latest`) | Python, R, the command line, every reader | Almost always |
| `1.0.0-py` | Python and the command line; no R, and no parquet or `.h5ad` reader | You only use Python or the command line, on CSV, TSV, GEO series, clinical or NMR files, and want a smaller download |

#### Typing the commands

`"$PWD"` in the commands on this site means “the folder I am in now”,
and it is spelled differently in each shell:

| Where you are typing                 | Write      |
|--------------------------------------|------------|
| macOS Terminal, Linux, Git Bash, WSL | `"$PWD"`   |
| Windows PowerShell                   | `"${PWD}"` |
| Windows `cmd.exe`                    | `"%cd%"`   |

A path error on Windows is almost always this.

The image’s entrypoint is the `falconage` command, so the first word
after the image name is a verb: `demo`, `run`, `config`, `clocks`. The
exceptions are `python`, `R`, `Rscript` and `bash`, which open that
program inside the image:

``` bash
docker run --rm -it -v "$PWD:/work" bhagesh/falconage:1.0.0-cpu python
docker run --rm -it -v "$PWD:/work" bhagesh/falconage:1.0.0-cpu R
```

On Linux, if the run cannot write into your folder (“Permission
denied”), run the container as yourself by adding
`-u "$(id -u):$(id -g)"` after `docker run --rm`.

#### Keeping downloads between runs

Nothing bundled needs the network. Public data fetched with
`falconage download` is cached. Add a named volume so a new container
does not fetch it again:

``` bash
docker run --rm -v "$PWD:/work" -v falconage-cache:/opt/falconage/cache \
  bhagesh/falconage:1.0.0-cpu download GSE40279
```

#### Building the image yourself

Both images are published, so pulling is the two-minute route:

``` bash
docker pull bhagesh/falconage:1.0.0-cpu
docker pull bhagesh/falconage:1.0.0-py
```

To build them from a clone of the repository instead, about ten minutes
the first time:

``` bash
git clone https://github.com/bhagesh-h/FALCONAge.git
cd FALCONAge
docker build -f docker/Dockerfile.cpu -t bhagesh/falconage:1.0.0-cpu .
docker build -f docker/Dockerfile.cpu --target py -t bhagesh/falconage:1.0.0-py .
```

### Without Docker

If you already manage your own Python or R environment.

<div class="panel-tabset">

#### Python

``` bash
pip install "falconage[plot] @ git+https://github.com/bhagesh-h/FALCONAge.git#subdirectory=python"
falconage config
```

Optional extras: `methylation` (parquet), `anndata` (`.h5ad`),
`metabolomics` (Nightingale `.xlsx`), or `all`.

#### R

``` r
remotes::install_github("bhagesh-h/FALCONAge", subdir = "r")

library(FALCONAge)
falconage_install()   # builds the Python environment R calls into; a few minutes
falconage_config()    # what resolved: versions, registry size
```

The R package hands every number to the Python core, so it needs a
Python environment either way. On reticulate 1.41 or later one is built
on first use and `falconage_install()` is optional; use it when you want
a pinned, reproducible environment.

</div>

Every command on this site works the same in a native install; only the
`docker run --rm -v "$PWD:/work" bhagesh/falconage:1.0.0-cpu` prefix
goes away.

### When something looks wrong

Run `falconage config` (or `falconage_config()` in R) first. It reports
the version, the registry and how many clocks are usable, and it is the
first thing to include in a bug report.



# Chapter 3. Your first run

This page assumes the image is installed
([Install](https://bhagesh-h.github.io/FALCONAge/start/install.html)).
Every command is run from the folder that holds your data, and the
output is written to that same folder.

### 1. Run the demo

``` bash
docker run --rm -v "$PWD:/work" bhagesh/falconage:1.0.0-cpu demo
```

It writes a small synthetic dataset (40 samples, labelled as synthetic
in every file), runs the whole pipeline on it, and prints:

<div class="falcon-output">

    read 40 sample(s) x 325375 feature(s) on 450K
    scored 53 clock(s); 119 skipped
      consensus: unsupported
      31 figure(s)
    49 note(s) about individual clocks: falconage_demo/results/warnings.csv

    done. Open falconage_demo/results/report.html

</div>

The values are random draws with an age trend, so the ages in the report
are not meaningful. Its purpose is to show every output file before you
run your own data.

### 2. Output files

| File | What it holds |
|----|----|
| `report.html` | The report: open this first. Scores, uncertainty, acceleration, the figures, and every note |
| `scores.csv` | One row per sample per clock, with the clock’s scale and unit |
| `scores_wide.csv` | The same scores as a table, samples by clocks |
| `technical_se.csv` | How much of each score is measurement noise (a standard error per score) |
| `conformal_interval.csv` | A prediction interval per score, for clocks with a published calibration |
| `acceleration.csv` | Age acceleration per sample, where the sample sheet gives age and the clock’s scale allows it |
| `consensus.csv`, `consensus_verdict.txt` | Whether a difference between groups holds across clocks, when there is a `group` column |
| `interpretation.csv` | What each clock measures, its unit, and which arithmetic its scale permits |
| `evidence.csv` | Published reliability and validation results for each clock, with DOIs |
| `qc.csv`, `qc_per_sample.csv` | Feature coverage per clock and quality checks per sample |
| `skipped_clocks.csv` | Every clock not scored, with the reason |
| `warnings.csv` | Notes about individual clocks: tissue mismatches, imputed probes, known paper discrepancies |
| `run_manifest.json` | Versions, the SHA-256 of every coefficient file used, and the settings: enough to reproduce the run |
| `figures/` | Every figure in the report as its own PNG |

### 3. Run your own data

Put the data in the current folder and name it on the command line:

``` bash
docker run --rm -v "$PWD:/work" bhagesh/falconage:1.0.0-cpu run betas.csv --samples samples.csv
```

The output is written to `betas_falconage/`; `--outdir` sets another
folder.

**The input** is preprocessed, quality-controlled data in one of these
formats:

| You have | Give `run` |
|----|----|
| A beta matrix (samples by probes, or probes by samples) | `betas.csv`, `.tsv`, `.parquet` or `.h5ad` |
| A GEO series matrix | `GSE12345_series_matrix.txt.gz` |
| Clinical chemistry | `labs.csv --kind clinical` ([units](https://bhagesh-h.github.io/FALCONAge/data/loading.html) are declared in the file) |
| A Nightingale NMR export | `nmr.xlsx --kind nightingale` |

**The sample sheet** is optional but worth having. Its first column is
the sample id, exactly as in the data, and any of these columns are
used:

    sample_id,age,sex,tissue,group
    S001,34.5,F,whole blood,control
    S002,61.0,M,whole blood,case

| Column   | Enables                                                    |
|----------|------------------------------------------------------------|
| `age`    | Age acceleration, and agreement of each clock with age     |
| `tissue` | The check that each clock was fitted on your specimen type |
| `group`  | The test of whether a group difference holds across clocks |
| `sex`    | Sex-specific clocks and the sex check on X-linked probes   |

Without a sample sheet the run still scores every clock; it says which
steps it skipped and why.

**Choosing clocks.** By default `run` scores every clock your data
supports. To score named ones:

``` bash
docker run --rm -v "$PWD:/work" bhagesh/falconage:1.0.0-cpu \
  run betas.csv --samples samples.csv --clocks horvath2013,hannum,dnamphenoage
```

`falconage clocks list` shows every id, and [Choosing a
clock](https://bhagesh-h.github.io/FALCONAge/clocks/choosing.html) helps
pick.

### 4. In a pipeline

`run` is built to be called unattended by a workflow manager such as
Nextflow or Snakemake:

``` bash
falconage run betas.csv --samples samples.csv --outdir results --format tsv \
  --threads 4 --log-file results.log
falconage versions --process FALCONAGE_RUN > versions.yml
```

| Option or behaviour | What it gives a pipeline |
|----|----|
| `--threads N` | Caps the numerical thread pools at the CPUs the task was given |
| `--format tsv` | Tab-separated output tables |
| `--log-level {quiet,info,debug}`, `--log-file` | Progress on stdout, log records on stderr and in the file |
| Exit status | 0 success, 1 internal error, 2 usage error, 3 input data error, 4 scoring or analysis error |
| `falconage versions --process NAME` | The YAML a `versions.yml` takes |
| The image | Passes an absolute-path command (`/bin/bash .command.sh`) straight through, ships `ps` for task metrics, and runs as any user id |

An error prints one line naming the cause, for example
`falconage: error: input not found: betas.csv`; `--log-level debug` adds
the traceback.

### The same in Python or R

<div class="panel-tabset">

#### Python

``` python
import falconage as fa

data = fa.prepare(fa.read_betas("betas.csv"))
res  = fa.score(data, clocks="compatible")

res.summary()
fa.acceleration(res, method="both")
fa.plot.ba_vs_ca(res, "horvath2013")
fa.report.write_report(res, "report.html")
```

#### R

``` r
library(FALCONAge)

d   <- prepare(read_betas("betas.csv"))
res <- score(d, clocks = "compatible")

summary(res)
acceleration(res, method = "both")
plot_ba_vs_ca(res, "horvath2013")
report(res, "report.html")
```

</div>

Both produce the same numbers, because both run the same code. The R
package delegates all arithmetic to the Python core through reticulate,
and the R suite asserts equality at tolerance exactly zero rather than
approximate agreement.

### Scoring

Every Python and R snippet from here on runs unchanged in three places:
inside the Docker image
(`docker run --rm -it -v "$PWD:/work" bhagesh/falconage:1.0.0-cpu python`,
or `... R`), in a native install, or in the CLI-free path below. Only
the way you open the session differs.

<div class="panel-tabset">

#### Python

``` python
d   = fa.prepare(fa.read_betas("betas.csv"))
res = fa.score(d, clocks="compatible")

res.summary()
res.scores               # samples x clocks
res.long()               # one row per sample per clock, with the scale
res.qc()                 # per-clock feature coverage and skip reasons
res.manifest             # versions, precision, SHA-256 of every coefficient file
```

#### R

``` r
d   <- prepare(read_betas("betas.csv"))
res <- score(d, clocks = "compatible")

summary(res)
as.data.frame(res)                  # samples x clocks
as.data.frame(res, form = "long")   # one row per sample per clock, with the scale
coverage(res)                       # per-clock feature coverage and skip reasons
manifest(res)                       # versions, precision, and every coefficient checksum
```

</div>

`clocks = "compatible"` scores what this dataset can support and reports
the rest as skipped with a reason. Naming clocks explicitly is
different: then every one must work, because an explicit request should
never be dropped quietly.

### Interpreting the result

The scale, the unit, which arithmetic is permitted, both coverage
measures, the published reliability where one exists, and any documented
disagreement between the clock’s paper and the coefficients in
circulation, all on the object rather than only on this website:

<div class="panel-tabset">

#### Python

``` python
res.interpretation()
```

#### R

``` r
interpretation(res)
```

</div>

`technical_icc` and `biological_icc` are separate columns because they
measure different things and do not track together: the same sample
assayed twice, versus the same person sampled again a few days later. A
clock can be excellent on the first and poor on the second, and the
clocks most used to claim an intervention worked are where that gap is
widest.



# Chapter 4. About and design

FALCONAge computes biological age scores from molecular data. It reads
what a laboratory actually produces, applies published aging clocks to
it, and returns each score with its unit, its provenance, and an
estimate of how much of it is measurement noise.

An aging clock is a supervised model mapping molecular features, most
often DNA methylation at specific CpG sites, to a single number. Roughly
two hundred have been published since 2013, and they were not fitted to
the same target. Some were regressed on calendar age, some on a
survival-weighted composite and then rescaled into years, some on the
rate of change in organ-system biomarkers tracked longitudinally, some
on cumulative stem-cell divisions. Those are four different quantities.
Reported together as “biological age” they look comparable, and the
arithmetic that mixes them has no defined meaning.

This package treats that as the problem to solve rather than a caveat to
mention. Every catalogue entry declares the target its clock was trained
on, the unit the output carries, and which downstream operations are
consequently defined. Asking for age acceleration on a pace-of-aging
clock returns an error naming the units, not a number. Scoring a
placenta clock on blood is refused. Scoring saliva on a whole-blood
clock warns and cites the size of the error measured in people sampled
both ways. The refusals are the design, and each one names the
measurement it rests on.

The second half of the package is about what a single number is worth.
Technical replicates of the same DNA differ by up to nine years on
prominent clocks, and only 18% of probes on the 450K array reach an
intraclass correlation of 0.5 in whole blood. A score reported without
that context invites a reader to believe a difference that the assay
alone could have produced. FALCONAge propagates published per-probe
reliability through each clock’s own weights to give a standard error
per sample, and calibrates distribution-free prediction intervals
against known ages.

It is one numerical core in Python, called from R through reticulate, so
a result obtained in either language is the same bits rather than two
implementations that agree approximately. The catalogue holds 68 human
clocks, and every one of them ships its coefficients and scores offline.

These are instruments for population research, not a clinical judgement
about one person. FALCONAge computes what the papers specify and records
how it did so; whether a given clock is fit for a given decision is not
something a scoring tool can certify, and the limits below say what else
it cannot do.

### Scope and limitations

What the tool is for, what it declines to do, and what it cannot do yet.
Three different questions with three different answers, in the order a
[model card](https://arxiv.org/abs/1810.03993) puts them.

#### Intended use

The reason, rather than the disclaimer. Reliability varies sharply
between clocks, and technical reproducibility and biological stability
are separate properties that do not track together: a clock can be
highly repeatable on split samples and still move with a meal or a
night’s sleep. So a score that survives replication is not thereby
measuring a stable trait, and the two failures need different evidence
to rule out. [The science of aging
clocks](https://bhagesh-h.github.io/FALCONAge/methods/formulas.html)
sets out, clock by clock, which is established and which is contested.

#### Out-of-scope use

Each gate is a place where the wrong answer is available and cheap. A
clock scored on the wrong specimen, on too little of its own model, on a
scale that does not admit the operation asked for, on clinical values
whose units were never stated, or from a weights file that cannot be
redistributed, all return a number that looks exactly like a right one.
The output of the last gate is a score and a manifest recording which
gates it passed and on what evidence.

Each of these is a silent wrong answer somewhere else, so each is a hard
failure here:

- **Fill a missing probe with zero.** In beta space zero means
  completely unmethylated, which is a real and extreme measurement. An
  absent feature takes the clock’s reference value: the authors’ own for
  Horvath 2013, DunedinPoAm38, CorticalClock and AltumAge, a healthy
  adult blood mean for 22 other blood clocks. Where there is none, it
  takes the mean of the clock’s present features, and the run names that
  fallback with the share of the weight it touched. Every substitution
  is counted in the manifest.
- **Guess clinical units.** PhenoAge has SI and conventional variants
  that disagree by years. `units=` has no default.
- **Score below the coverage floor.** A clock whose features are largely
  absent is skipped and named, rather than scored on mostly-imputed
  input.
- **Treat probes as interchangeable.** Coverage is measured twice: by
  count, and by the share of the model’s total \|coefficient\| the
  present features carry. A clock can clear a 92% feature floor having
  lost the probes that do a third of the work, and only the second
  number sees it. `probe_loss()` reports both before you score anything.
- **Claim coverage means validity.** High coverage says the probes are
  present. It says nothing about whether coefficients fitted in one
  tissue, species or population transfer to yours; that judgement stays
  with you, and [Choosing a
  clock](https://bhagesh-h.github.io/FALCONAge/clocks/choosing.html)
  lays out the grounds for it.
- **Let a paper-versus-implementation disagreement pass silently.**
  Eleven clocks in the catalogue are scored from coefficients that
  differ from what their paper describes: a feature count, a changed
  statistic, a constant. Each carries the note, and it is raised as a
  warning at score time, not left on a documentation page.

#### Known limitations

Said here rather than left to be inferred.
[Uncertainty](https://bhagesh-h.github.io/FALCONAge/analysis/uncertainty.html)
and [Preparing data and
coverage](https://bhagesh-h.github.io/FALCONAge/data/preprocessing.html)
cover each in full, with the algorithms and the reason each is or is not
blocked.

- **It does not repair cross-platform probe loss.** It measures it twice
  over: by count, by coefficient mass, and now in *years* per clock per
  platform. It cannot undo it. The liftover mapping tables encode
  concordance measured on paired samples and are not derivable from the
  array manifests.
- **It does not preprocess raw data.** IDAT decoding, normalisation,
  detection filtering and sample QC belong to an array pipeline such as
  [methylarray](https://github.com/bhagesh-h/methylarray); FALCONAge
  reads the resulting beta matrix. Its own preparation is limited to
  identifier harmonisation, EPIC v2 replicate collapse and clipping.
- **It has no proteomic or transcriptomic clocks.** No published model
  in either family may be redistributed, and proteomic and
  transcriptomic tables are not read.
- **It has no foundation-model backend.** The `NeuralClock` architecture
  ships, safetensors only. CpGPT and MethylGPT are interesting here for
  zero-shot imputation and array conversion rather than as another age
  predictor.

Removed from this list, because it now exists: single-cell scoring.



# Chapter 5. The Claude skill

The repository ships a [Claude](https://claude.com/claude-code) skill at
`.claude/skills/falconage/`. It is four markdown files: the workflow
(`SKILL.md`), the Docker command set, the clock catalogue routed by the
question each clock answers, and every refusal with the measurement
behind it.

It is active already for anyone working inside a clone. To have it
available in any directory, copy it into your personal skills folder
with `cp -r .claude/skills/falconage ~/.claude/skills/`, or on Windows
PowerShell
`Copy-Item -Recurse .claude\skills\falconage $HOME\.claude\skills\`.

Then ask in plain language. “Score this beta matrix and tell me which
clocks you refused and why” is enough; the skill supplies the rest.

> [!NOTE]
>
> ### Why the skill is checked by CI, and checked harder than the prose
>
> `docs/check_api_docs.py` resolves every `fa.*` name and every
> `falconage <verb>` in the skill against the running package on each
> push, exactly as it does for these pages.
>
> The reason it matters more here is that these pages are read by a
> person, who notices when a function does not exist and goes looking. A
> skill is read by a model that then *runs* what it says. The first
> draft named five readers at top level that actually live under
> `fa.preprocess`, and invented a `falconage probe` verb outright,
> copied from a specification section of the architecture page that
> described a verb never built. The check caught all six, and then
> caught two more invented verbs on that page.



# Chapter 6. Loading your data

FALCONAge scores data that is already preprocessed and quality
controlled. Normalisation, detection filtering and sample QC of
methylation arrays belong upstream, in an array pipeline such as
[methylarray](https://github.com/bhagesh-h/methylarray), minfi or
SeSAMe; FALCONAge takes their beta matrix as input. Clinical chemistry
and NMR tables are read as reported by the laboratory.

Every reader returns a `FalconData`: a samples-by-features matrix with
its modality, platform and sample annotation. Scoring is the same call
whichever reader produced it.

Every output on this page was produced by running the code above it,
against the public test corpus where the corpus has that input type and
against a small file written inline where it does not. Nothing here is
illustrative.

### Readers by input format

| Input | Reader | Modality | CLI |
|----|----|----|----|
| A beta matrix: CSV, TSV, parquet or `.h5ad` | `read_betas()` | `dna_methylation` | `falconage run betas.csv` |
| A GEO series matrix | `read_series_matrix()` | `dna_methylation` | `falconage run GSE…_series_matrix.txt.gz` |
| A ComputAgeBench study | `read_computage_bench()` | `dna_methylation` |  |
| A targeted assay: pyrosequencing, EpiTYPER, ddPCR | `read_panel()` | `dna_methylation` |  |
| Clinical chemistry | `read_clinical()` | `clinical_chemistry` | `falconage run labs.csv --kind clinical` |
| Nightingale NMR metabolomics | `read_nightingale()` | `metabolomics_nmr` | `falconage run nmr.xlsx --kind nightingale` |

Raw IDAT files, sequencing coverage files (RRBS, bedMethyl) and
proteomic or transcriptomic tables are not accepted. A folder of IDATs
passed to `falconage run` is refused with a message naming the
preprocessing step it needs.

`fa.read(path)` selects the reader from the file name. Arguments
specific to a reader, such as the units of a clinical table, are passed
to that reader directly.

### A beta matrix

Probes down the rows, samples across the columns, or the transpose: the
orientation is detected from which axis carries probe ids.

``` python
d = fa.read_betas("betas.csv")
```

    FalconData(3 samples x 3 features, dna_methylation, 0.0% missing)

The file that produced it:

    probe,S001,S002,S003
    cg00000029,0.512,0.488,0.559
    cg00000165,0.113,0.096,0.140
    cg00000236,0.842,0.871,0.836

Betas belong in 0 to 1. A matrix of percentages is a factor of a hundred
out and every clock will return a confidently wrong number, so
`prepare()` checks the range and says so.

**EPIC v2 identifiers are harmonised automatically.** EPIC v2 probe ids
carry a suffix (`cg00000029_TC21`), and a clock fitted on 450K finds no
matching features until the suffixes are removed. `prepare()` removes
them and averages replicate probes of the same CpG;
`aggregate_epicv2=False` disables the step.

**Pass the matrix before probe filtering.** Filters for SNP,
cross-reactive or detection-failed probes are designed for association
studies. A clock CpG removed by them is replaced by an imputed value at
scoring time, and `score()` reports how much of each clock’s weight that
affects (see [Preparing data and
coverage](https://bhagesh-h.github.io/FALCONAge/data/preprocessing.html)).

### A GEO series matrix

The `*_series_matrix.txt.gz` GEO offers for most published studies.
Sample metadata comes with it.

``` python
d = fa.read_series_matrix("GSE330325_series_matrix.txt.gz")
d.obs.head(3)
```

    FalconData(8 samples x 888987 features, dna_methylation, EPICv2, 0.0% missing)

                     title            tissue    cell_type
    sample_id
    GSM9723838  GSD1a_rep1  Skin Fibroblasts  Fibroblasts
    GSM9723839  GSD1a_rep2  Skin Fibroblasts  Fibroblasts
    GSM9723840  GSD1a_rep3  Skin Fibroblasts  Fibroblasts

The `characteristics:` lines become `obs` columns. Set `obs["tissue"]`
before scoring and the specimen check runs; leave it and every clock’s
tissue assumption goes unchecked.

### A ComputAgeBench study

65 curated case-control studies with age, sex, tissue and condition
already normalised.

``` python
fa.io.list_computage_bench().head()
d = fa.read_computage_bench("GSE107143")
```

                  n platform tissue      conditions  age_min  age_max
    dataset
    GSE56046   1128     450K  Blood  AS=789, HC=339     44.0     83.0
    GSE42861    689     450K  Blood  HC=335, RA=354     18.0     70.0
    GSE117859   608     450K  Blood         HIV=608     25.0     75.0
    GSE111629   572     450K  Blood  HC=237, PD=335     35.0     92.0
    GSE117860   529   EPICv1  Blood         HIV=529     25.0     75.0

    FalconData(16 samples x 460295 features, dna_methylation, 450K, 0.0% missing)

                  dataset       gpl tissue    cell_type sex   age condition class
    SampleID
    GSM2861662  GSE107143  GPL13534  Blood  Whole blood   M  79.0        AS   CVD
    GSM2861663  GSE107143  GPL13534  Blood  Whole blood   M  88.0        AS   CVD
    GSM2861664  GSE107143  GPL13534  Blood  Whole blood   M  88.0        AS   CVD

This is the input `run_benchmark()` expects: it needs `condition`, a
control group, and `age`, and this reader supplies all three.

### A targeted assay

Pyrosequencing, EpiTYPER, ddPCR: a handful of CpGs measured directly,
with samples down the rows.

``` python
d = fa.read_panel("panel.csv")
```

    FalconData(2 samples x 3 features, dna_methylation, targeted panel, 0.0% missing)

    sample,cg16867657,cg09809672,cg02228185
    P01,0.68,0.41,0.55
    P02,0.72,0.38,0.51

A panel almost never carries a whole clock, and the coverage floor is
what stops a three-probe file being scored as though it were a 353-probe
model. `probe_loss()` says what a partial set costs before you score
anything.

### Clinical chemistry

The clinical clocks take laboratory values, and they take them in
declared units.

``` python
UNITS = {"albumin": "g/L", "creatinine": "umol/L", "glucose": "mmol/L",
         "crp": "mg/L", "lymphocyte_percent": "%", "mean_cell_volume": "fL",
         "red_cell_distribution_width": "%", "alkaline_phosphatase": "U/L",
         "white_blood_cell_count": "10^9/L"}

d = fa.read_clinical("labs.csv", units=UNITS)
fa.score(d, clocks=["phenoage"]).scores.round(2)
```

    FalconData(2 samples x 10 features, clinical_chemistry, 0.0% missing)

    WARNING [phenoage] Two constants circulate in the divisor of the Gompertz inversion:
    0.090165 and 0.09165. FALCONAge uses 0.090165, the value BioAge corrected to in April
    2026. Code still using 0.09165 differs by several years on the same input.

               phenoage
    sample_id
    C01           55.79
    C02           69.61

**Units are per column, not per file.** A clinical table mixes them, so
there is no single name to pass; `units="SI"` is refused with the
mapping it wants. PhenoAge exists in an SI and a conventional variant
that disagree by years, and `units=` has no default for that reason.

**HbA1c in mmol/mol.** Laboratories outside the US report HbA1c in IFCC
units. Declare `"hba1c": "mmol/mol"` and it is converted to the NGSP
percentage the reference models were fitted in, by the published master
equation NGSP = 0.09148 × IFCC + 2.152
([NGSP](https://ngsp.org/ifccngsp.asp); Hoelzel et al., *Clin Chem*
2004;50:166-174,
[doi:10.1373/clinchem.2003.024802](https://doi.org/10.1373/clinchem.2003.024802)).
It is not a ratio, so it applies to HbA1c only.

**A cohort measured unlike its reference.** KDM and homeostatic
dysregulation are fitted on a reference cohort, and `fit_kdm`/`fit_hd`
record each marker’s distribution there. When a scored cohort leaves it,
`score()` says so (category `reference_range`): a median outside the
reference’s 1st to 99th percentile, which is what a unit mismatch looks
like, or many values beyond the reference’s range. The case that matters
most is CRP. NHANES III’s assay read nothing below 0.21 mg/dL, and 63.9%
of its adults sit at that floor, so a high-sensitivity CRP cohort scored
against it has most of its values where the reference has none.
`fa.models.clinical.censor_to_reference(df, ref)` sets values below a
reference’s reporting floor to the floor, which is how the reference
itself recorded them, and returns how many moved. It only touches
markers whose minimum is a floor (at least 1% of reference rows sitting
exactly at it); values above the reference’s range are real measurements
and are left alone.

### NMR metabolomics

A Nightingale Health export (CSV, TSV or Excel), samples down the rows:

``` python
d = fa.read_nightingale("nightingale.xlsx")      # Excel needs the `metabolomics` extra (openpyxl)
res = fa.score(d, clocks=["metaboage", "metabohealth"])
```

Column names are translated to the BBMRI-NL names the two scores were
fitted with, by MiMIR’s table and MiMIR’s rule (lower-cased, and
translated only when exactly one entry lists the name); a name the table
does not know is kept and listed in `obs.attrs["untranslated"]` rather
than guessed. MetaboAge (van den Akker et al. 2020) and MetaboHealth
(Deelen et al. 2019) are scored as MiMIR scores them, its quality
control included, and match it to 1e-9 and 1e-12. MetaboHealth z-scores
each measure within the cohort, so a score depends on who else is in the
file: it is marked `requires_cohort` and is not comparable between files
scored separately.

### After loading

Whatever you loaded, the rest is the same:

``` python
res = fa.score(d, clocks="compatible")   # only the clocks this data supports
res.interpretation()                     # scale, unit, legal operations, caveats
fa.technical_se(res, d)                  # how much of each score is the assay
```

`clocks="compatible"` is the safe default: it asks the registry which
clocks this platform, modality and specimen actually support, and skips
the rest by name rather than scoring them on whatever features happen to
match.



# Chapter 7. Preparing data and coverage

### Preparing the input

#### The input contract

FALCONAge does not normalise, filter probes or run sample QC. The input
is a matrix that has already been through those steps upstream, for
example in the [methylarray](https://github.com/bhagesh-h/methylarray)
pipeline, minfi or SeSAMe. What `fa.prepare()` (CLI:
`falconage prepare`) applies is limited to what scoring requires:
identifier harmonisation, EPIC v2 replicate collapse, clipping to the
beta range and platform detection.

Rows are samples, columns are features. Feature names are the
identifiers the clock coefficients use: `cg00000029` for methylation
probes, and the declared analyte names for clinical chemistry and NMR.
`fa.FalconData` holds the matrix in `X`, sample metadata (age, sex,
tissue, group) in `obs`, and per-feature annotation in `var`; it reads
and writes AnnData’s `.h5ad`.

#### EPIC v2 probe aggregation

EPIC v2 column names look like `cg00000029_TC21`. `fa.prepare()` strips
the suffix and averages replicate probes of the same CpG before anything
else. Skipping this means every clock sees almost no overlapping
features on EPIC v2 data.

#### Two distinct imputation stages

**Stage 1 - dataset-level, before the clock.** `fa.preprocess.impute()`
with `median` (default), `mean` or `none`, run only when asked.

**Stage 2 - clock-level, for features the dataset does not contain at
all.** Filling with zero in beta space means “fully unmethylated”, which
is biologically wrong for most sites, so FALCONAge never does it.

**What FALCONAge does, and what the R packages do.** For a linear clock
FALCONAge fills an absent feature with the mean of the clock’s observed
features over the whole dataset: one constant, the same for every absent
feature and every sample (`models/linear.py`). `imputation="reference"`
replaces it with a per-feature value wherever a reference is supplied.
The mitotic mean, percentile and transmission clocks (epiTOC1/2/3,
HypoClock, EPICmitHyper/Hypo, stemTOC, stemTOCvitro) are the exception:
their published statistic is taken over the sites present, so FALCONAge
leaves absent sites out and records `imputation: "excluded"`.
methylclock 1.16.0 leaves absent CpGs out of the sum (`predAge` in
`R/internals.R`), which is a fill of 0. dnaMethyAge 0.2.0 fills each one
with its per-probe mean from the package’s `golden_ref` table
(`meanImputation`, called from `methyAge`). Each policy adds the same
amount to every sample, so on one dataset the packages differ by a
constant

    Δ = Σ_{j absent} w_j (f_j − g_j)

where `w_j` is the coefficient and `f_j`, `g_j` are the two fills. For
Horvath’s clocks the constant is multiplied by 21 above the adult age of
20, where the anti-log transform is linear.

On a dataset that lacks some of a clock’s CpGs, the packages in
circulation fill them differently (methylclock and dnaMethyAge among
them), and that alone can move the same clock’s age by several years
between packages that agree on every coefficient and intercept. Given
identical complete input there is no difference to explain: the
conformance suite in `test/conformance/` scores 75 clock-package pairs
on the same filled matrix, and every difference left over is traced to a
coefficient copy that departs from its primary source. The offsets
belong to a dataset’s missing CpGs, not to the clocks, so the registry
does not carry them as per-clock discrepancies. The coverage record
(`res.coverage[clock_id]`) gives the number of values filled
(`n_imputed`) and the method (`imputation`). Neither 0 nor a pooled mean
is a published value for a CpG, which is why a per-CpG reference from
each clock’s own training data is the better fill.

**Horvath’s normalisation is optional in his own code, and the packages
default differently.** Horvath 2013 supplied a calibration step
(Additional file 24, `BMIQcalibration`): each sample’s betas over 21,368
probes are mapped onto the distribution of `goldstandard2`, the
per-probe means in Additional file 22 ([Genome Biology, CC BY
2.0](https://doi.org/10.1186/gb-2013-14-10-r115)), after absent probes
are set to those means. dnaMethyAge 0.2.0 runs it by default for
`HorvathS2013` (`simple_mode = TRUE` skips it), methylclock 1.16.0 does
not (`normalize = FALSE`), and FALCONAge offers it as an opt-in step,
`fa.preprocess.horvath_normalise()` (R: `horvath_normalise()`). The step
mostly moves the level of Horvath 2013 age rather than the ranking of
samples, so a comparison across packages has to say whether it ran.

`horvath_normalise()` is a port of `BMIQcalibration`. The R code fits
its beta mixtures on 20,000 probes drawn by `set.seed(1); sample(...)`
and stops its optimisers early (Nelder-Mead after 50 evaluations), so
its result depends on the exact draw and the exact optimiser path; the
port reproduces each piece as R computes it (the Mersenne-Twister draw,
`optim`’s Nelder-Mead and BFGS, RPMM’s `blc`, `density()`). Against the
unmodified Additional file 24 it agrees to 3e-10 in beta on a synthetic
fixture and to 2e-8 years of Horvath age on the 120 samples above,
reproducing the −1.87-year shift. Two arguments follow the code people
actually ran:

| Argument | Default | The other value |
|----|----|----|
| `absent` | `"drop"`: calibrate on the gold-standard probes the data carry, as Knight et al.’s published wrapper does | `"fill"`: set absent probes to their gold-standard value first |
| `sample_kind` | `"Rejection"`: R 3.6.0 and later | `"Rounding"`: the draw of earlier R |

With `sample_kind="Rounding"`, Knight et al.’s own test dataset gives
37.3665, 38.3463 and 39.322 weeks against the 37.366, 38.346 and 39.324
their instructions state; the remaining 0.002 is their
k-nearest-neighbour imputation of 51 missing values. Only the 21,368
gold-standard probes are changed, and a missing value is set to its
gold-standard value first, as Horvath’s code does for a single sample;
both counts are recorded in `uns["horvath_normalisation"]`.

Reporting the imputation method alongside a score is not optional; it
changes the answer, and the run manifest records it.

#### Preprocessing steps that live inside a model

These are per-clock and must run *after* feature selection, not before:

| Step | Clocks in the catalogue |
|----|----|
| robust scale `(x − median)/std` | AltumAge |
| per-sample z-score across features | ZhangEN, ZhangBLUP |
| mean over non-missing | epiTOC1, HypoClock, EPICmitHyper, EPICmitHypo |
| 0.95 quantile over non-missing | stemTOC, stemTOCvitro |
| nan → 0 | epiTOC2, epiTOC3 |
| NaN → reference value | most linear clocks |

### Methylation clock coverage

#### Coverage across the genome

Every `falconage run` on methylation data draws this figure first,
before any clock is scored. It is written to
`figures/clock_coverage_across_the_genome.png`, with its legend text in
the `.txt` file beside it, and includes clocks added with
`--clocks-dir`.

<div id="fig-coverage-map">

![](figures/gallery/clock_coverage_across_the_genome.png)

Figure 1: **Clock coverage across the genome.** Every DNA methylation
clock in FALCONAge, one track each, with its CpGs at their positions on
the genome (hg19). Coloured where the EPIC v1 array carries the CpG,
grey where it does not; the legend gives each clock’s colour and the
share of its CpGs on the array. CpGs aligned across tracks are shared
between clocks.

</div>

Python: `fa.plot.clock_coverage_manhattan(data)`, or `platform="EPICv2"`
without data. R: `plot_clock_coverage()`.

#### Coverage and weight per clock

`probe_loss()` reports, per clock, how many features are present **and**
how much of the model’s weight they carry. The second number is the one
that detects EPIC v2 probe loss:

<div class="panel-tabset">

#### Python

``` python
fa.probe_loss(d, clocks="scoreable")
```

#### R

``` r
probe_loss(d, clocks = "scoreable")
```

</div>

<div class="falcon-output">

                       tier  n_features  n_present  coverage  mass_coverage  bias_years          heaviest_absent
    horvath2013     bundled         353        339    0.9603         0.9715     -1.2570   cg11932564 (0.8%), ...
    hannum          bundled          71         64    0.9014         0.8994      1.0279   cg21139312 (2.7%), ...
    zhangmortality  bundled          10          9    0.9000         0.7687      0.0124  cg08362785 (23.1%), ...

</div>

Three rows of the table for the EPIC v2 series in the test corpus
(GSE330325). `zhangmortality` has nine of its ten CpGs, 90% by count,
and the one it lacks carries 23% of its weight.

`bias_years` is filled in when the platform is one the shift has been
measured on; see [what probe loss
costs](https://bhagesh-h.github.io/FALCONAge/methods/uncertainty.html#probe-loss-priced).
`NaN` there means *not measured*, never *no bias*.

A clock at 96% feature coverage and 61% weight coverage has kept nearly
all its probes and lost the ones that matter. The scoring floor applies
to both measures, so this run would be refused with a message naming the
heaviest absent probes rather than returning a confident number.

#### Clock CpGs removed by upstream probe QC

A clock CpG can be absent for two reasons. The array may not carry it
(platform loss), or the array carried it and a probe filter removed it
afterwards. FALCONAge separates the two with a table, bundled with the
package, of which Illumina arrays (27K, 450K, EPIC v1, EPIC v2) carry
each clock CpG (`fa.preprocess.platform_probes()`). When removed CpGs
carry at least 1% of a clock’s absolute weight, `score()` raises a
`probe_qc` warning naming the heaviest of them, and the coverage record
gives `n_removed_by_qc` and `qc_removed_mass`.

SNP, cross-reactive and detection filters are designed for association
studies. For clock scoring, pass the matrix taken before probe
filtering: the clock weights were fitted on those probes, and an imputed
value replaces each one that is removed.



# Chapter 8. Age acceleration

### Age acceleration

The conventions disagree by several years on the same data, and papers
frequently do not say which they used.

<div class="panel-tabset">

#### Python

``` python
fa.acceleration(res, method="absolute")      # predicted - chronological
fa.acceleration(res, method="residual")      # residual of predicted on chronological
fa.acceleration(res, method="both")          # both, as <clock>_absolute / <clock>_residual
fa.acceleration(res, method="within_group", group="dataset")
```

#### R

``` r
acceleration(res, method = "absolute")
acceleration(res, method = "residual")
acceleration(res, method = "both")
acceleration(res, method = "within_group", group = "dataset")
```

</div>

Absolute is interpretable in years and carries the clock’s own bias: a
clock five years high on everybody gives everybody five years of
acceleration. Residual removes that bias, and removes any real
cohort-wide effect with it. Within-group is what the AA2 benchmark
needs: it asks whether cases accelerate relative to *their own*
controls. `"both"` returns the first two side by side, suffixed, for
when you would otherwise have to pick without knowing which the
comparison paper used.

#### Against a reference population

The residual is centred on this cohort, so it cannot say how the cohort
compares with anyone else, and it absorbs any effect the whole cohort
shares. `method="reference"` fits the age line in a second, scored
population and applies it unchanged here:

``` python
ref = fa.score(reference_data, clocks=["phenoage"])
fa.acceleration(res, method="reference", reference=ref, match=("age", "sex"))
```

The line is fitted separately within each level of the categorical
`match` columns (usually sex), an age outside the reference’s range in
its stratum is refused rather than extrapolated, and a reference scored
with different coefficients is refused. `attrs["reference_fit"]`
records, per clock and stratum, the reference sample size, age range,
fitted line and residual SD.

#### Adjusting for cell composition

Blood cell composition changes with age, and with most other things that
happen to a person. In more than 10,000 blood samples, immune
composition was significantly associated with age acceleration for
**every one** of six widely used clocks (Zhang et al., *Aging Cell*
2024;23:e14071,
[doi:10.1111/acel.14071](https://doi.org/10.1111/acel.14071)), so an
unadjusted acceleration is measuring two things and reporting one
number.

The proportions needed to separate them are usually already in the
result, computed by the deconvolution clocks in the same run:

<div class="panel-tabset">

#### Python

``` python
fa.cell_composition(res)                        # the proportions, as covariates
fa.acceleration(res, adjust="cell_composition") # net of them
fa.acceleration(res, adjust=["cd8t", "mono"])   # or measured counts from obs
```

#### R

``` r
cell_composition(res)
acceleration(res, adjust = "cell_composition")
acceleration(res, adjust = c("cd8t", "mono"))
```

</div>

An adjusted acceleration is a different quantity from an unadjusted one,
so the returned frame records which covariates went in. Comparing the
two as though they were the same measurement is the error this is
designed to make visible.

Ask for acceleration on a pace-of-aging clock and it refuses:

<div class="falcon-output">

    IllegalOperationError: 'acceleration' is not defined for dunedinpoam38, whose output is
      pace_ratio (biological years per chronological year).
      Legal here: correlate, difference, mean, rank.
      A pace of aging is already a rate; subtracting chronological age from it is a units
      error, not a conservative choice.

</div>

That refusal is the point. A wrong number in a column of numbers is
invisible.

→ **Why it works this way:** [Downstream statistics on an aging
score](https://bhagesh-h.github.io/FALCONAge/methods/downstream.html)



# Chapter 9. Uncertainty, specimen and platform

### Measurement uncertainty

Technical replicates of the *same DNA* differ by up to nine years on
prominent clocks, so a bare number does not say whether a difference
between two samples is real.

<div class="panel-tabset">

#### Python

``` python
se = fa.technical_se(res, d)
se.diagnostics[["median_se", "se_over_sd", "implied_cohort_icc"]]

fa.conformal_interval(res, level=0.90)     # the other, larger uncertainty
fa.power("horvath2013", effect=0.5, result=res)   # how many samples you need
```

#### R

``` r
u <- technical_se(res, d)
u$diagnostics

conformal_interval(res, level = 0.90)
power_n("horvath2013", effect = 0.5, result = res)
```

</div>

<div class="falcon-output">

                  method  n_features  median_se  se_over_sd  implied_cohort_icc
    horvath2013    probe         353       1.58        0.14                0.98
    hannum         probe          71       2.46        0.22                0.95
    dunedinpoam38  probe          46       0.04        0.53                0.72

</div>

Two samples whose intervals overlap are not distinguishable by that
clock on that assay, however different their point estimates look.

→ **Why it works this way:** [Uncertainty, specimen and
platform](https://bhagesh-h.github.io/FALCONAge/methods/uncertainty.html)



# Chapter 10. Clinical chemistry and survival

### Clinical chemistry

``` r
d <- read_clinical("nhanes.csv", units = list(
  albumin = "g/L", creatinine = "umol/L", glucose = "mmol/L", crp = "mg/dL",
  lymphocyte_percent = "%", mean_cell_volume = "fL",
  red_cell_distribution_width = "%", alkaline_phosphatase = "U/L",
  white_blood_cell_count = "10^3/uL", age = "years"))

score(d, clocks = "phenoage")
```

Units are required and never guessed. Albumin at 4.2 is g/dL and albumin
at 42 is g/L; both are clinically normal, and PhenoAge fitted on one
returns nonsense for the other. No range check can separate them, so the
only correct behaviour is to ask.

KDM and homeostatic dysregulation have no coefficients of their own:
each is defined relative to a reference cohort. FALCONAge ships one such
fit, BioAge’s NHANES III KDM (`fa.models.clinical.kdm_bioage`); for any
other reference, fit it:

``` r
ref <- fit_kdm(nhanes3, markers = markers)
score(d, clocks = "kdm", reference = ref)
```

#### LinAge2

LinAge2 (Fong et al. 2025) is trained on survival rather than age:
examination, blood and urine inputs in NHANES variable names and units,
three scores from health questionnaire items, and a Cox model on
principal components, one per sex, returned as the age at which a model
on age alone gives the same risk. The inputs are named as in the
authors’ codebook, with age and sex in `obs`:

``` python
d = fa.FalconData(X=nhanes_style_inputs, obs=obs[["age", "sex"]], modality="clinical_chemistry")
fa.score(d, clocks=["linage2"])
```

Cotinine (`LBXCOT`) in ng/mL is binned into the authors’ four smoking
categories. A missing lipid sets LDL to 0, as the authors’ code does,
and the result names the samples that happened to; any other missing
input leaves that sample without a score. The parameters are what the
authors’ `linAge2.R` fits from the NHANES file it ships with, and
FALCONAge reproduces its output to 5e-10 years on the 2,344 subjects of
their test wave.

#### Blood-count ratios

``` python
fa.blood_count_ratios(cbc, units={"neutrophils": "10^9/L", "lymphocytes": "10^9/L",
                                  "monocytes": "10^9/L", "platelets": "10^9/L"})
```

NLR, LMR, PLR and SII from a complete blood count. Units are declared,
as everywhere; counts are converted to 10^9/L. Percentages give the two
ratios that do not depend on the total (NLR, LMR) and not the two that
involve platelets, and a zero lymphocyte count gives no ratio rather
than infinity.

#### Which marker carries an association

A composite clinical clock associated with an outcome does not say which
of its markers carries the association.
`fa.leave_one_marker_out(res, "kdm", data=d, reference=ref, test="outcome")`
recomputes KDM, HD or PhenoAge without each marker in turn (KDM and HD
are refitted; for PhenoAge the marker is held at the reference mean) and
reports how far the score and the association moved.

### Survival and association

Two figures that most aging-clock papers carry, and that need the
analysis functions above.

#### Survival

<div class="panel-tabset">

#### Python

``` python
fa.cox_hazard(res, time_col="time", event_col="status")      # HR per unit (per year for an age clock)
fa.plot.kaplan_meier(res, "horvath2013",
                     time_col="time", event_col="status")    # the figure
```

#### R

``` r
cox_hazard(res, time_col = "time", event_col = "status")
plot_kaplan_meier(res, "horvath2013", time_col = "time", event_col = "status")
```

</div>

The curves compare the fastest-ageing tenth with the slowest, not two
halves. The middle of the acceleration distribution is where a clock
discriminates least, so a median split dilutes the comparison; the tails
are the published convention. The log-rank p is in the figure’s legend
text, the `.txt` written beside it.

If the curves cross: the hazards are not proportional and the single
hazard ratio beside them is an average over a period during which the
ordering changed. That is worth saying in a caption rather than leaving
for a reader to notice.

#### Association

<div class="panel-tabset">

#### Python

``` python
assoc = fa.associate(res, "crp", covariates=("age", "sex"))
fa.plot.volcano(assoc, fdr=0.05)
```

#### R

``` r
assoc <- associate(res, "crp", covariates = c("age", "sex"))
plot_volcano(assoc, fdr = 0.05)
```

</div>

The dashed line is the Benjamini-Hochberg threshold at the stated FDR,
read off the `q` column rather than recomputed. This matters more than
it looks: across a few hundred tests a raw 0.05 admits roughly one in
twenty of the nulls, and drawing that line instead labels them
significant.



# Chapter 11. Benchmarking

Score each study separately, combine the results, and run the AA1 and
AA2 tests across them.

<div class="panel-tabset">

#### Python

``` python
res = fa.combine([r1, r2, r3], keys=["GSE1", "GSE2", "GSE3"])
b   = fa.run_benchmark(res, condition_col="condition", control="HC",
                       dataset_col="dataset")
b.summary()
```

#### R

``` r
res <- combine(list(r1, r2, r3), keys = c("GSE1", "GSE2", "GSE3"))
b   <- run_benchmark(res, condition_col = "condition", control = "HC",
                     dataset_col = "dataset")
b$summary
```

</div>

Median absolute error against chronological age is reported but never
ranked on: a perfect chronological oracle would score best on it and be
useless, because it would have no age acceleration left to detect
anything with.

→ **Why it works this way:** [Benchmarking and
validation](https://bhagesh-h.github.io/FALCONAge/methods/benchmarking.html)



# Chapter 12. Beyond the clock score

Every clock in the catalogue models the *mean* beta at a set of sites
and returns one number. That is not the only thing a methylation matrix
can be asked, and on the field’s own evidence it may not be the most
informative thing.

Tong et al. \[65\] quantified how much of a clock is entropy rather than
biology: roughly 66 to 75 per cent of Horvath2013’s accuracy against
chronological age is reproducible by a purely stochastic model of
methylation change, about 90 per cent for Zhang, and about 63 per cent
for PhenoAge. The gradient is the interesting part. The more accurately
a clock predicts chronological age, the more of it is drift.

This page covers five things FALCONAge computes that are not clocks: the
disorder readouts, repertoire structure, where a clock’s coefficient
mass sits, reliability components, and mosaic ages within a tissue. None
of them returns an age, none is gated by `scale_type`, and none is
comparable between datasets processed differently.

### Disorder: entropy, drift and the barometer

`falconage.disorder` holds four functions, and the division between them
is about *what carries the number*, which is the distinction most easily
lost.

| Function | Returns | Per what |
|----|----|----|
| `fa.entropy` | how far the methylome sits from fully committed | sample |
| `fa.drift` | how far a sample sits from the cohort centroid | sample |
| `fa.noise_barometer` | summed per-site SD over age-variable sites | **group** |
| `fa.variable_sites` | which cytosines widen with age | site |

#### Entropy

Normalised Shannon entropy over the beta matrix:

$$
S = \frac{1}{N \log \tfrac{1}{2}} \sum_{i=1}^{N}
    \Big[ \beta_i \log \beta_i + (1-\beta_i) \log (1-\beta_i) \Big]
$$

Bounded 0 to 1. A site at beta 0 or 1 is decided and contributes
nothing; a site at 0.5 is maximally uncertain and contributes its full
share. So $S = 0$ is a methylome where every site is committed and
$S = 1$ is one where none of them is.

``` python
import falconage as fa

data = fa.read("betas.csv")
ent = fa.entropy(data)        # entropy, n_sites
```

`n_sites` is not decoration. Entropy is a *mean over sites*, so a mean
over different sites is not a comparison. The default restricts to sites
covered in every sample for exactly that reason; set
`complete_sites=False` to use each sample’s own coverage and then read
`n_sites` before comparing any two rows.

On the test corpus this lands at 0.695 with an SD of 0.007 across
825,177 complete sites, which is what a clean bimodal EPIC distribution
looks like once it is summarised to one number.

#### Drift

The barometer is a property of a group, which leaves nothing to regress
against an outcome. `fa.drift` is the per-sample analogue: the distance
from the cohort centroid, computed **leave-one-out** so that a sample is
never scored against a mean it helped compute.

``` python
dri = fa.drift(data)                          # drift from this cohort
dri = fa.drift(data, reference=young_mean)    # drift from a young reference
```

The leave-one-out default matters more than it looks. Scoring a sample
against a centroid that includes it shrinks its own distance, and in a
small cohort that shrinkage is large enough to invert a group
difference.

#### Which sites actually widen

The barometer of Mei et al. \[70\] is defined over “cytosines whose
variance rises with age”, and that clause is the whole statistic. Summed
over every site instead, the sum is dominated by sites that are merely
variable, most of which have nothing to do with age.

`fa.variable_sites` is that selection step, split out so it can be
inspected rather than assumed. The test is Brown-Forsythe, which is
Levene’s test using the median, across age bins. Bartlett’s test is the
more common choice in this literature and is the wrong one here: it
assumes normality within each group, and beta values near 0 or 1 are
visibly not normal, so Bartlett reports variance differences that are
distributional artefacts.

A significant result says the variances *differ* between bins. It does
not say variance *rises*, and a site whose variance falls is just as
significant, so `direction` carries the sign of the trend and `rising`
is the conjunction the barometer wants.

> [!IMPORTANT]
>
> ### What this looks like on a cohort that is too small
>
> Run on the test corpus, `sites_rising` under Benjamini-Hochberg is
> **zero**. Twenty-seven samples in three bins of nine, against roughly
> 820,000 tests, has almost no power once the correction is applied.
>
> That is the correct answer, not a gap in the implementation. A
> barometer that means anything needs a cohort in the hundreds.
> `fa.noise_barometer` accepts an explicit `sites=` list so a selection
> made elsewhere can be reused, which is also the only way the statistic
> transfers between cohorts.

### Repertoire structure

`falconage.immune` addresses a covariate no published blood clock
carries.

Deconvolution answers *how many cells of each type*. It says nothing
about *how many distinct clones those cells represent*, and the two are
different measurements: two donors with an identical CD8 memory fraction
can differ by orders of magnitude in clone count.

#### Why clone count should move a clock at all

Take one cell type holding fraction $f$ of the sample, split into clones
of relative size $w_k$ with $\sum_k w_k = 1$. Give clone $k$ a somatic
offset $\delta_k$ from its lineage mean at some site, with mean zero and
variance $\sigma^2$. The compartment’s bulk beta is the size-weighted
mean, so

$$
\mathrm{Var}\Big[\sum_k w_k \delta_k\Big] = \sigma^2 \sum_k w_k^2
   = \frac{\sigma^2}{N_{\text{eff}}},
\qquad N_{\text{eff}} = \Big(\sum_k w_k^2\Big)^{-1}
$$

and $\sum_k w_k^2$ is exactly the Simpson index. The variance a clonal
compartment contributes to bulk methylation is inversely proportional to
its **effective number of clones**, and clone count enters through that
quantity and no other. Three equal clones carry one cell’s somatic state
at full weight; ten thousand clones average it to nothing.

This is why the effect is invisible to composition adjustment: $f$ can
be identical between two donors while $N_{\text{eff}}$ differs
thousand-fold, and every published blood clock sees only $f$.

The myeloid version of the question is settled. Nachun et al. \[71\]
measured clonal hematopoiesis against six clocks and found 1.31 years of
acceleration on GrimAge to 3.08 on extrinsic EEAA. The lymphoid analogue
has not been asked.

#### Measuring it

``` python
div = fa.repertoire_diversity(clones, sample_col="sample_id", count_col="count")
data.obs = data.obs.join(div)

res = fa.score(data, clocks="compatible")
acc = fa.acceleration(res, adjust=["clonality", "cd8mem_fraction"])
```

`fa.acceleration` already accepts arbitrary `obs` columns as covariates,
so the incremental test is one call. The question is entirely whether
clonality adds variance beyond cell fraction.

Depth is the trap. Richness and Shannon both rise with sequencing depth,
so an unrarefied comparison between a deeply and a shallowly sequenced
donor measures the library rather than the donor. Pass `rarefy="min"` to
subsample every donor to a common depth by multivariate hypergeometric
draw, which is what a shallower run would actually have produced;
sampling with replacement inflates richness at low depth, in the same
direction as the bias being corrected. `clonality`, `simpson` and
`effective_clones` are far more stable and are the ones to trust when
rarefaction is not possible.

#### Simulating it

The mechanism arm needs no paired cohort. `fa.simulate_clonality`
generates bulk methylomes at **fixed** cell fractions and varying clone
structure, so anything a clock does in response is clone structure
alone.

``` python
sim = fa.simulate_clonality(
    reference, {"CD8mem": 0.3, "Neu": 0.7},
    clonal_types=["CD8mem"],
    clone_sizes=[fa.immune.zipf_clone_sizes(n, alpha=1.0)
                 for n in (2, 20, 200, 2000)],
    n_replicates=20)
res = fa.score(sim, clocks="compatible")
```

`reference` is sorted-cell mean beta, features by cell type. The
six-cell IDOL library that the bundled deconvolution entries use
(FlowSorted.Blood.EPIC, GPL-3) is one such table:
`fa.registry.load().deconvolution_table("deconvolutebloodepicbcell", "EPICv1")`
returns it, 450 CpGs by six cell types.

> [!NOTE]
>
> ### What the simulation returns on the test corpus
>
> Across 42 clocks scored on 48 simulated samples at identical cell
> fractions, the median log-log slope of score spread against effective
> clone count is **-0.494**, interquartile range -0.559 to -0.415. The
> derivation predicts -0.5 and was not fitted to the simulation.
>
> Among the clocks reporting years, `dnamphenoage` moves **4.35 years**
> between an effectively-two-clone compartment and a diverse one, and
> `horvath2013` moves 1.54 years. Both fall below a year once the
> compartment holds a few hundred effective clones.
>
> Cell-type fractions were identical for every one of those samples, so
> composition adjustment cannot remove any of it.

### Where a clock’s weight sits

A clock is a weight vector over CpGs, and two questions about that
vector need no samples at all.

**Is this clock exposed to genotype?** If a clock CpG is under strong
meQTL control and the allele frequency at that variant differs between
ancestral populations, a systematic difference in clock output between
ancestry groups follows from genotype frequency alone, with no
difference in aging. Cruz-Gonzalez et al. \[75\] established that the
major clocks lose accuracy in admixed individuals; whether the size of
that loss tracks each clock’s meQTL exposure is open, and half of that
measurement is a property of the coefficients.

**Is this clock regulatory?** Patel et al. \[76\] report that most CpGs
used by established clocks do *not* overlap known transcription factor
binding sites. Reproducing that against any annotation class is the same
computation with a different list.

``` python
mass = fa.coefficient_mass({"meqtl": godmc_cpgs, "enhancer": enhancer_cpgs})
```

#### Why mass and not count

Counting annotated sites answers the wrong question. A clock’s behaviour
is driven by its heavy features: a 353-CpG clock with two enormous
weights and 351 small ones behaves like a two-CpG clock. The statistic
is therefore the share of $\sum_j |w_j|$ on annotated sites, with the
plain count returned beside it. **When the two diverge, the annotated
sites are the heavy ones, and that divergence is the finding.**

Run on the registry with each clock’s own CpG set as the annotation,
which needs no external file, `horvath2013` shares 11.6 per cent of its
*sites* with `dnamphenoage` but 19.6 per cent of its *mass*. `weidner`
shares two of its three sites with `dnamphenoage` and 89 per cent of its
mass. Two clocks that share their heaviest features will agree with each
other for reasons that have nothing to do with either being right.

FALCONAge bundles no annotation list. meQTL catalogues and regulatory
builds are large, versioned and separately licensed, and freezing one
into a wheel would make it silently stale. GoDMC and the EPIGEN meQTL
database are the usual sources for the first question, the Ensembl
Regulatory Build or a Roadmap chromatin-state track for the second.
`.attrs["unmatched"]` reports how many supplied ids matched nothing,
which is the check that catches an EPIC v2 list with `_TC21` suffixes
meeting bare `cg` probe ids.

### Reliability: trait, state and technical

A published ICC answers “how reproducible is this clock across a
cohort”. Someone asking “has my number moved” needs a different
quantity, and the gap between the two is why clock ICCs in the
literature read as reassuring while replicate disagreement of up to nine
years is also true \[68\].

`fa.variance_components` separates them, given repeated measurement:

$$
y_{ijk} = \mu + a_i + s_{ij} + \varepsilon_{ijk}
$$

for person $i$, occasion $j$, replicate $k$, fitted by Henderson’s
method of moments. Two ICCs come back and the gap between them is the
point:

`icc`  
On raw scores. Comparable to what the literature publishes.

`icc_age_adjusted`  
The same after chronological age is regressed out. A cohort spanning
decades holds most of its between-person variance in the age term, so a
raw ICC largely reports that the clock tracks age, which was never in
question. The adjusted figure is between-person reliability among people
of the same age, which is what any individual-level claim rests on.

A clock whose raw ICC is 0.98 and whose adjusted ICC is 0.4 is not a
precise instrument. It is a cohort with a wide age range.

``` python
vc = fa.variance_components(res, subject_col="donor", occasion_col="visit")
vc.table                      # var_trait, var_state, var_tech, icc, icc_age_adjusted
vc.replicates_needed(0.9)     # per occasion, to reach ICC 0.9
```

With one draw per visit and no technical replicates, which is the usual
longitudinal design, day-to-day change and assay noise cannot be told
apart: `var_state` then holds both, `var_tech` is NaN, `icc` is the
test-retest reliability across visits, and `vc.design["within_person"]`
says so.

`replicates_needed` returns `inf` where no number of replicates gets
there, and that is the informative case rather than an error. Replicates
average away the *technical* term only, so a clock whose day-to-day
within-person variance already exceeds the budget cannot be rescued by
running the array again. The honest answer is then a second draw, not a
second scan.

Components are not clipped at zero. A negative one means the
within-level spread exceeded the between-level spread, which is real for
a small design or a clock measuring nothing in this cohort, and rounding
it to zero disguises both.

### Mosaic ages within a tissue

`fa.models.single_cell.scage` gives an age per cell \[28\]. A bulk clock
already reports the mean, so the quantity worth having is the *shape* of
the distribution underneath it: a tissue whose cells are uniformly
middle-aged and one holding a mixture of young and very old cells have
the same bulk methylation and, plausibly, very different biology.

The obstacle is that single-cell methylation coverage is sparse, so each
per-cell age rests on few sites and carries large error. Observed spread
is therefore always positive, and reporting it as heterogeneity is the
mistake `fa.mosaic` exists to avoid.

The null is stated plainly: **every cell in the group has the same true
age, and all observed spread is estimation error**. It is simulated by
drawing each cell from a normal centred on the group mean with that
cell’s own standard error, taken from the profile-likelihood width
`scage` already returns.

``` python
ages = fa.models.single_cell.scage(cells, reference)
mos  = fa.mosaic(ages, group="tissue")
```

A small `p_excess` is evidence of genuine mosaicism. A large one says
the data cannot distinguish a mosaic tissue from a uniform one measured
badly, which at typical single-cell coverage is the usual answer and is
worth reporting as such. `n_at_grid_edge` counts cells whose estimate
landed on the boundary of the age grid, where the likelihood was
truncated rather than maximised; those pile up and inflate the tails, so
a group with many of them should have its skew and kurtosis ignored.

### What none of this is

None of these functions is a clock, and none returns an age. They carry
no coefficients, no `scale_type` gate applies, and their outputs move
with normalisation, probe panel and detection-p filtering. The only
defensible comparison is within one processed matrix.

That is a real constraint rather than a disclaimer. Entropy computed on
noob-normalised betas and entropy computed on raw betas are different
numbers for the same DNA, and neither is more correct than the other.



# Chapter 13. Figures and reports

### Reporting

Two documents, each one self-contained HTML file.

**The one-page report** is the scores, the run and a few figures, small
enough to send:

``` r
write_results(res, "results/")
report(res, "report.html", group = "condition")
```

It is one file, inlined CSS, base64 figures, the table embedded, so it
still works after somebody emails it, which is the only thing anybody
does with a report.

**The full run, step by step.** `run_report()` runs quality control,
scoring, technical error, prediction intervals, age acceleration, a
consensus test across clocks when a group column is named, and the
interpretation tables, and writes every deliverable into one directory:
the same directory the `report` command writes. With `quarto = TRUE` it
adds `falconage_report.qmd`, in which every file of that directory sits
under the step that produced it, in the order a reader has to take them,
because each step is only as reliable as the ones before it:

| Step | What it holds |
|----|----|
| 0\. Provenance | versions, the coefficient file and SHA-256 behind each clock, precision, warnings |
| 1\. Input and quality control | per-sample missingness and beta distribution; the QC figures |
| 2\. Coverage | per-clock coverage by feature count and by coefficient weight; clocks not scored, and why |
| 3\. Scores | the scores, what each category of clock measures, and how the clocks relate |
| 4\. Agreement with chronological age | error against age and whether it depends on age |
| 5\. Uncertainty | technical standard error and conformal prediction intervals |
| 6\. Age acceleration | residuals on age, for the scales where they are defined |
| 7\. Group comparison | the consensus verdict and the test for every clock |
| 8\. Interpretation | what each score means and the published evidence, with DOIs |
| 9\. Further outputs | every other file in the directory, named and sized |

A file the report does not recognise still appears, in step 9, so
nothing in the directory is left out. Tables expand, search, page and
download as CSV; figures enlarge on click and download at full
resolution. Rendered, it is one HTML file with every figure and table
embedded: 3.7 MB for 16 samples and three clocks.

<div class="panel-tabset">

#### Python

``` python
fa.report.run_report(d, "results/", group_col="condition", quarto=True)
```

#### R

``` r
run_report(d, "results/", group = "condition", quarto = TRUE)
```

#### Command line

``` bash
docker run --rm -v "$PWD:/work" -w /work bhagesh/falconage:1.0.0-cpu \
  report betas.csv --outdir results/ --group-col condition --quarto
```

</div>

**Rendering it.** Quarto is not in the FALCONAge image. Installed it
takes 423 MB, which would add about 17% to the 2.5 GB image for an
optional document, so inside the image the source is written and the run
says so. Render it with the Quarto container, from the output directory,
and open `falconage_report.html`:

``` bash
cd results
docker run --rm --user "$(id -u):$(id -g)" -e HOME=/tmp -v "$PWD:/w" -w /w \
  ghcr.io/quarto-dev/quarto quarto render falconage_report.qmd
```

Where Quarto is installed, `run_report()` renders it directly, and
`quarto_report("results/")` (R) or
`fa.report.write_quarto_report("results/", render=True)` (Python)
rewrites the report for a directory that already exists.

### Plots

#### What FALCONAge draws

Thirty-two figures in Python, twenty-one of them also in R, drawn alike
because both languages read their colours, titles, subtitles and
one-line descriptions from the same `colorscheme.yaml`. The
[gallery](https://bhagesh-h.github.io/FALCONAge/analysis/figures.html)
shows every one. The coverage map is drawn first on every run, before
any clock is scored, and cannot be switched off. Every function returns
its data frame as well as its figure, which is how two rendering engines
draw the same numbers.

**Ready for a manuscript.** A figure carries its axes and its legend and
nothing else: no title, no subtitle and no caption on the canvas, so it
drops into a panel layout as it is. Each one is written as a pair named
after its title, with the clock appended for per-clock figures:

    figures/predicted_against_chronological_age_horvath2013.png
    figures/predicted_against_chronological_age_horvath2013.txt

The `.txt` holds the title, the figure’s own numbers (n, r, MedAE and
the like) and the description, ready to paste into a figure legend.
`save_figure()` writes a pair from any figure you draw yourself, in
Python (`fa.plot.save_figure(fig, "figures")`) and in R
(`save_figure(p, "figures")`); `figure_text()` returns the same text as
a list. Both reports show the title and description beneath each figure
and link its `.txt`.

| Figure | Answers |
|----|----|
| `clock_coverage_manhattan` | where every clock’s CpGs sit on the genome, which ones the data carries, and which clocks share them |
| `ba_vs_ca` | does this clock track age here, and with what bias |
| `bland_altman` | is the error age-dependent (regression dilution made visible) |
| `calibration` | is the predicted age calibrated across the age range |
| `acceleration_by_group` | do cases accelerate relative to controls |
| `acceleration_density` | the same, as distributions rather than summaries |
| `acceleration_heatmap` | clock × study, the whole pooled picture in one panel |
| `forest` | effect size with an interval, per clock |
| `clock_corr` | which clocks agree, clustered |
| `clock_chord` | how much of that agreement is shared CpGs rather than shared signal |
| `clock_radar` | one profile per group across clocks, on a common z scale |
| `clock_pca`, `clock_embedding` | sample structure in clock space; ageotypes |
| `clock_scatter_matrix` | pairwise acceleration, the `plot_baa` layout |
| `coverage_bar`, `missingness` | which clocks are scoring imputed values, read before the scores |
| `beta_density` | is the beta distribution bimodal, or did normalisation break |
| `sex_check` | does the X/Y dosage match the recorded sex |
| `platform_comparison`, `study_comparison` | is the batch bigger than the biology |
| `benchmark_bars`, `benchmark_error_bias`, `benchmark_heatmap` | AA1/AA2, the MedAE–MedE tradeoff, clock × dataset |
| `timecourse`, `trajectory` | clocks across a timepoint variable |
| `clock_atlas` | every clock, every pooled study, one figure |

`clock_chord` is the one with no precedent in the list above and it
earns its place: the correlation heatmap says two clocks agree, and the
chord says how much of that agreement was built in by construction. A
pair with a thick chord and a high correlation has told you much less
than a pair with a high correlation and no chord at all.

A volcano plot of clock associations is implemented (`fa.plot.volcano`,
R `plot_volcano`). GSEA (11) belongs to feature-level biology rather
than to scoring, and spatial maps (12) wait on the spatial modality.

Two rules the code enforces rather than recommends. A figure whose data
is empty, flat, or all zeros raises `NothingToPlot` and `save_all`
records the reason, because an axis-free rectangle in a report reads as
a measurement of nothing rather than as an absence of measurement. And
the scale-type gate applies to figures too: a `pace_ratio` clock never
reaches an acceleration panel.



# Chapter 14. Figure gallery

<!-- GENERATED by docs/build_gallery.py from test/output_figures/gallery.
     Edit that script, colorscheme.yaml, or regenerate the figures. -->

Each of these is produced by `test/run_all.py` against the public test
corpus and copied into `test/output_figures/gallery/`. They are
regenerated from the code, so a figure here is what the current version
actually draws – not a screenshot taken once.

The figures carry no title or caption on the canvas, only axes and
legend, so they drop into a manuscript or a panel layout as they are.
Each PNG is named after its title, and a `.txt` of the same name beside
it holds the title, the figure’s own numbers and the description; the
caption under each image here is read from that file. The same file’s
`ui` block sets the colours and fonts of both HTML reports and of this
site, so a figure, a report and a page of the documentation share one
palette: Okabe-Ito for data, because group membership is carried by hue
alone and has to survive colour-vision deficiency, and the logo orange,
in a darker shade where it is text, only for links and controls.

> [!NOTE]
>
> ### Reproducing these
>
> ``` bash
> docker run --rm -v "$PWD:/work" -w /work falconage:1.0.0-cpu \
>   python test/run_all.py
> ```
>
> Which dataset each figure comes from, and why that one was chosen, is
> recorded in
> [SOURCES.md](https://github.com/bhagesh-h/FALCONAge/blob/main/test/output_figures/gallery/SOURCES.md).

### Start here

Where every clock’s CpGs sit on the genome and which ones the array
carries, then the question everyone actually has: which of these
algorithms detects anything.

#### Clock coverage across the genome

![Clock coverage across the
genome](figures/gallery/clock_coverage_across_the_genome.png)

*62 clocks · the EPICv1 array · mean coverage 98.0% · 41 fully covered.*

One track per clock, every CpG at its position on the genome (hg19). In
the clock’s colour, the data carries it; in grey, it does not. CpGs that
line up across tracks are shared between clocks. Read this before the
scores: a clock whose track is mostly grey is scored largely on filled
values.

`plot.clock_coverage_manhattan()` in Python; written as
`clock_coverage_across_the_genome.png` with
`clock_coverage_across_the_genome.txt`.

#### Clock atlas across pooled studies

![Clock atlas across pooled
studies](figures/gallery/clock_atlas_across_pooled_studies.png)

*40 clocks · 13 studies · 394 samples · 12 of 193 comparisons
significant at BH q \< 0.05.*

Read panel D down the page. A row of hollow circles on zero is an
algorithm that detected nothing in any cohort; filled dots pushed right
are the ones that did, and a row with several says the effect held
across studies rather than in one. Panels B and C are diagnostics for
reading D, not scores: a clock that merely returned chronological age
would be perfect in B, empty in D, and useless. Panel F separates the
two ways of finding nothing: a clock that saw its features and detected
no difference, from one that never had the features to look with. Panel
G is for the clocks whose scale admits no acceleration at all (a pace, a
telomere length, a division count) and asks the question their scale
does allow: were cases and controls separated. Cliff’s delta, so 0 is no
separation and 1 is complete, and unlike D it is not adjusted for age,
which matters when a cohort’s cases are older than its controls.

`plot.clock_atlas()` in Python; written as
`clock_atlas_across_pooled_studies.png` with
`clock_atlas_across_pooled_studies.txt`.

### Is the clock calibrated

Before any biology: does the prediction track chronological age, and
where does it drift.

#### Predicted against chronological age

![Predicted against chronological
age](figures/gallery/predicted_against_chronological_age.png)

*altumage · n = 27 · r = 0.59 · MedAE = 45.45 years.*

Distance from the dashed identity line is error, not acceleration; a
clock sitting parallel to it but offset is biased, which MedE
quantifies.

`plot.ba_vs_ca()` in Python; written as
`predicted_against_chronological_age.png` with
`predicted_against_chronological_age.txt`.

#### Agreement across the age range

![Agreement across the age
range](figures/gallery/agreement_across_the_age_range.png)

*altumage · bias = 41.92 years · limits of agreement 21.8 to 62.1.*

A trend in this cloud means the clock’s error depends on age, which a
correlation coefficient cannot show and which invalidates a single
MedAE.

`plot.bland_altman()` in Python; written as
`agreement_across_the_age_range.png` with
`agreement_across_the_age_range.txt`.

#### Residual against chronological age

![Residual against chronological
age](figures/gallery/residual_against_chronological_age.png)

*altumage · slope = +0.000 · a flat line at zero is perfect
calibration.*

A negative slope is regression to the mean: the clock over-ages the
young and under-ages the old, which is the most common artefact in this
field.

`plot.calibration()` in Python; written as
`residual_against_chronological_age.png` with
`residual_against_chronological_age.txt`.

### Age acceleration

The residual after age is removed, by group and across studies.

#### Age acceleration by group

![Age acceleration by
group](figures/gallery/age_acceleration_by_group.png)

*altumage · residual convention · AS vs HC.*

Each point is one sample; the box is the median and interquartile range.
Read the separation between groups, not the distance from zero.

`plot.acceleration_by_group()` in Python; written as
`age_acceleration_by_group.png` with `age_acceleration_by_group.txt`.

#### Distribution of age acceleration

![Distribution of age
acceleration](figures/gallery/distribution_of_age_acceleration.png)

*altumage · residual convention · n = 28.*

Counted, not smoothed: a kernel density on a dozen cases invents
structure that is not in the data.

`plot.acceleration_density()` in Python; written as
`distribution_of_age_acceleration.png` with
`distribution_of_age_acceleration.txt`.

#### Age acceleration across clocks and samples

![Age acceleration across clocks and
samples](figures/gallery/age_acceleration_across_clocks_and_samples.png)

*19 clocks x 394 samples · z-scored within clock.*

Rows that disagree are clocks measuring different things; a column that
is red everywhere is a sample, not a finding.

`plot.acceleration_heatmap()` in Python; written as
`age_acceleration_across_clocks_and_samples.png` with
`age_acceleration_across_clocks_and_samples.txt`.

#### Effect of condition on age acceleration

![Effect of condition on age
acceleration](figures/gallery/effect_of_condition_on_age_acceleration.png)

*40 comparisons · point and 95% interval · BH-corrected.*

Intervals crossing zero are the honest majority. Width tracks sample
size, so a wide interval far from zero is a small study, not a large
effect.

`plot.forest()` in Python; written as
`effect_of_condition_on_age_acceleration.png` with
`effect_of_condition_on_age_acceleration.txt`.

### Outcomes

Whether acceleration predicts anything that happens to a person.

#### Survival by age acceleration

![Survival by age
acceleration](figures/gallery/survival_by_age_acceleration.png)

*phenoage · 500 subjects · 277 events · log-rank p \< 0.001.*

Strata are the tails of the acceleration distribution, not a median
split: the published figure compares the fastest-ageing tenth with the
slowest, because the middle of the distribution is where a clock has
least to say. Curves that cross mean the hazard is not proportional, and
the hazard ratio beside them is then an average over a period during
which the ordering changed.

`plot.kaplan_meier()` in Python; written as
`survival_by_age_acceleration.png` with
`survival_by_age_acceleration.txt`.

#### Association with age acceleration

![Association with age
acceleration](figures/gallery/association_with_age_acceleration.png)

*3 tested · 3 pass FDR 0.05.*

Effect size against evidence. The dashed line is the Benjamini-Hochberg
threshold at the stated FDR, not a raw p-value cut; with thousands of
tests the two differ by orders of magnitude. Points far right with small
-log10 p are the usual trap: a large effect measured in few samples.

`plot.volcano()` in Python; written as
`association_with_age_acceleration.png` with
`association_with_age_acceleration.txt`.

### How the clocks relate

Twenty clocks are not twenty measurements. These show how much they
share – of their features, and of their answers.

#### Agreement between clocks

![Agreement between
clocks](figures/gallery/agreement_between_clocks.png)

*Spearman rank correlation · 53 clocks · 394 samples.*

Rank, not Pearson: clocks on different scales have no meaningful linear
correlation. Blocks of agreement are usually shared training data.

`plot.clock_corr()` in Python; written as `agreement_between_clocks.png`
with `agreement_between_clocks.txt`.

#### Feature sharing between clocks

![Feature sharing between
clocks](figures/gallery/feature_sharing_between_clocks.png)

*24 clocks on the ring · 71 pairs sharing at least 5 CpGs.*

Chord width is the number of CpGs two clocks have in common. This is the
answer to the question the correlation heatmap raises: clocks agree
partly because they measure the same biology and partly because they are
built from the same probes.

`plot.clock_chord()` in Python; written as
`feature_sharing_between_clocks.png` with
`feature_sharing_between_clocks.txt`.

#### Multi-clock profile

![Multi-clock profile](figures/gallery/multi_clock_profile.png)

*12 clocks · 12 groups by condition · z-scored within clock against the
cohort.*

One closed polygon per group, on a common z scale. A spike on one axis
is one clock disagreeing with the rest, which is a finding about the
clock at least as often as about the sample.

`plot.clock_radar()` in Python; written as `multi_clock_profile.png`
with `multi_clock_profile.txt`.

#### Samples in clock space

![Samples in clock space](figures/gallery/samples_in_clock_space.png)

*PCA of z-scored clock scores · PC1 37% · PC2 21%.*

PC1 is almost always chronological age. Structure on PC2 that follows a
batch and not a phenotype is a batch effect.

`plot.clock_pca()` in Python; written as `samples_in_clock_space.png`
with `samples_in_clock_space.txt`.

### Benchmarking

AA1 and AA2 against the ComputAgeBench conditions, and the
error-versus-bias tradeoff that decides the ranking.

#### Datasets detected per clock

![Datasets detected per
clock](figures/gallery/datasets_detected_per_clock.png)

*17 clocks · 13 datasets · BH q \< 0.05.*

AA2 compares cases with their own controls; AA1 tests case-only cohorts
against zero. Ordered by the combined total, not by either alone.

`plot.benchmark_bars()` in Python; written as
`datasets_detected_per_clock.png` with
`datasets_detected_per_clock.txt`.

#### Error against bias on healthy controls

![Error against bias on healthy
controls](figures/gallery/error_against_bias_on_healthy_controls.png)

*17 clocks · point size is the benchmark total.*

Neither axis is a ranking. A clock at the origin merely predicts
chronological age well, which is the one thing a useful clock need not
do.

`plot.benchmark_error_bias()` in Python; written as
`error_against_bias_on_healthy_controls.png` with
`error_against_bias_on_healthy_controls.txt`.

#### Effect size per clock and dataset

![Effect size per clock and
dataset](figures/gallery/effect_size_per_clock_and_dataset.png)

*17 clocks x 13 datasets · outlined cells are significant.*

Read the columns. A dataset that is blank across every clock is either a
condition the clocks cannot see or a cohort too small to show it.

`plot.benchmark_heatmap()` in Python; written as
`effect_size_per_clock_and_dataset.png` with
`effect_size_per_clock_and_dataset.txt`.

### Data quality

Drawn before the results, because a coverage problem invalidates
everything after it.

#### Feature coverage per clock

![Feature coverage per
clock](figures/gallery/feature_coverage_per_clock.png)

*8 clocks · floor at 80% · mixed.*

The plot to read before the scores. Below the dashed line a clock is
mostly scoring imputed values, which is why it was refused.

`plot.coverage_bar()` in Python; written as
`feature_coverage_per_clock.png` with `feature_coverage_per_clock.txt`.

#### Missing values per sample

![Missing values per
sample](figures/gallery/missing_values_per_sample.png)

*21 samples · median 0.06% missing.*

One sample far to the right is a failed array; a shifted whole cohort is
a probe filter someone applied upstream.

`plot.missingness()` in Python; written as
`missing_values_per_sample.png` with `missing_values_per_sample.txt`.

#### Beta value distribution per sample

![Beta value distribution per
sample](figures/gallery/beta_value_distribution_per_sample.png)

*27 samples · EPICv1.*

Two peaks near 0 and 1 is what a working array looks like. A sample with
a filled middle failed, and no downstream normalisation will fix it.

`plot.beta_density()` in Python; written as
`beta_value_distribution_per_sample.png` with
`beta_value_distribution_per_sample.txt`.

#### Score distribution by platform

![Score distribution by
platform](figures/gallery/score_distribution_by_platform.png)

*altumage · 3 platforms · 394 samples.*

A shift between platforms in the same tissue is a technical effect. It
is the reason cross-study comparisons need the platform as a covariate.

`plot.platform_comparison()` in Python; written as
`score_distribution_by_platform.png` with
`score_distribution_by_platform.txt`.

#### Score distribution by study

![Score distribution by
study](figures/gallery/score_distribution_by_study.png)

*altumage · 13 studies · 394 samples.*

Between-study spread is usually larger than the within-study effect
being tested, which is why AA2 compares cases with their own controls.

`plot.study_comparison()` in Python; written as
`score_distribution_by_study.png` with
`score_distribution_by_study.txt`.

### Other

Figures not yet placed in a section above.

#### Does the difference hold up across clocks?

![Does the difference hold up across
clocks?](figures/gallery/does_the_difference_hold_up_across_clocks.png)

*verdict: unsupported · 44 clocks tested · alpha 0.05.*

One bar per clock, coloured by generation; \* survives
Benjamini-Hochberg and \*\* survives Bonferroni across the tests
actually run. The shape is the finding, not any one bar. A real change
lights up across generations; a single lit bar among twenty dark ones is
the published signature of a false positive, and five of six re-analysed
intervention datasets looked exactly like that.

`plot.consensus_plot()` in Python; written as
`does_the_difference_hold_up_across_clocks.png` with
`does_the_difference_hold_up_across_clocks.txt`.

#### How much of each score is the assay

![How much of each score is the
assay](figures/gallery/how_much_of_each_score_is_the_assay.png)

*43 clocks · probe · bar is SE / cohort SD; the label is the raw SE.*

Measurement error propagated from published per-probe reliability
through each clock’s own weights. The ICC beside each bar is what this
cohort implies, not a published figure: green above 0.8, amber below it,
red where the assay noise is as large as the spread between these
samples, a clock that cannot tell them apart, however confident its
point estimate.

`plot.reliability_forest()` in Python; written as
`how_much_of_each_score_is_the_assay.png` with
`how_much_of_each_score_is_the_assay.txt`.

#### Scores with the uncertainty they carry

![Scores with the uncertainty they
carry](figures/gallery/scores_with_the_uncertainty_they_carry.png)

*dnamphenoage · n = 27 · years.*

Two samples whose bars overlap are not distinguishable by this clock on
this assay. The narrow bar is measurement error: what a repeat of the
same DNA would do. The wide grey bar, where present, is the conformal
prediction interval against chronological age, which is a larger
question and has a larger answer. Neither is a confidence interval on a
diagnosis.

`plot.score_interval()` in Python; written as
`scores_with_the_uncertainty_they_carry.png` with
`scores_with_the_uncertainty_they_carry.txt`.

#### What probe loss costs, in years

![What probe loss costs, in
years](figures/gallery/what_probe_loss_costs_in_years.png)

*14 clocks · platforms: EPICv1, EPICv2 · measured, not assumed.*

Full 450K matrices masked down to each platform’s probe set and
rescored, absent probes filled from each clock’s reference values as
score() fills them; the bar is the median shift and the whisker a
bootstrap interval. A bar at zero is a clock that lost nothing. A long
bar is a clock whose lost probes carry weight no fill value stands in
for, which is why a correlation check passes while the intercept moves.
Reported, never subtracted.

`plot.platform_bias()` in Python; written as
`what_probe_loss_costs_in_years.png` with
`what_probe_loss_costs_in_years.txt`.

### In total

27 figures. Every one is also written per dataset under
`test/output_figures/<group>/<dataset>/` when the full corpus run is
executed; the gallery keeps one representative of each type so a reader
does not have to fetch 586 MB to see them.



# Chapter 15. Build a clock

When no published clock fits your assay or your question, fit one to
your cohort. FALCONAge compares several learners first, every number out
of fold, and then fits the one you choose.

### 1. Compare learners

<div class="panel-tabset">

#### Python

``` python
import falconage as fa

d   = fa.prepare(fa.read_betas("betas.csv"))      # obs must hold the target, e.g. "age"
cmp = fa.compare_learners(d, target="age", groups="person")

cmp.table          # one row per learner: MAE, MedAE, r, slope, bias by thirds, seconds
cmp.selected       # the nested error of "pick the best": the number to report
cmp.best           # the learner with the lowest out-of-fold MAE
```

#### R

``` r
library(FALCONAge)

d   <- prepare(read_betas("betas.csv"))
cmp <- compare_learners(d, target = "age", groups = "person")

cmp$table
cmp$selected
```

</div>

`groups` names a sample-sheet column whose members always stay on the
same side of a split: the person, when there are repeated visits, or the
batch or cohort, for leave-one-group-out. Without it, a person’s second
visit is predicted by a model that was trained on their first.

### 2. The learners

| Name | What it is | Writes a clock file | Needs |
|----|----|----|----|
| `elasticnet` | glmnet’s elastic net, alpha 0.5, lambda by inner cross-validation | yes | nothing extra |
| `lasso`, `ridge` | the same with alpha 1 and 0 | yes | nothing extra |
| `screened_elasticnet` | the 2,000 CpGs most correlated with the target, then elastic net; the screen runs inside each training part | yes | nothing extra |
| `pc_elasticnet` | principal components, then elastic net; maps back to one weight per CpG | yes | nothing extra |
| `random_forest`, `gradient_boosting`, `svr`, `mlp` | scikit-learn regressors | no | `pip install "falconage[learn]"` (in the Docker image already) |

Pass `transform="horvath"` to fit Horvath’s log-linear transform of age
and invert it, which matters when the cohort includes children.

### 3. Read the comparison honestly

- **Quote `selected`, not the best row of `table`.** Picking the best of
  several learners is itself a fitted choice, so the winner’s own error
  is optimistic. `selected` repeats the pick inside each outer fold and
  measures it on samples the pick never saw.
- **Look at the slope and the bias by thirds**, not only MAE. Every
  penalised model pulls predictions towards the mean, so the old read
  young and the young read old.
- **The most accurate age predictor is not necessarily the best
  biomarker.** Test the residual against an outcome on a cohort the
  model was not fitted on.

### 4. Fit the chosen learner and save it

<div class="panel-tabset">

#### Python

``` python
fit = fa.fit_clock(d, target="age", learner="pc_elasticnet", groups="person")
fit.metrics                        # out-of-fold MAE, MedAE, r, slope
fit.to_clock("mycohortclock", "my_clocks/")
```

#### R

``` r
fit <- fit_clock(d, target = "age", learner = "pc_elasticnet", groups = "person")
fit$metrics
clock_to_file(fit, "mycohortclock", "my_clocks/")
```

</div>

`to_clock` writes `mycohortclock.yaml`, its coefficients and its
reference values into `my_clocks/`. [Add a
clock](https://bhagesh-h.github.io/FALCONAge/own/add.html) scores it
like any catalogue clock.

→ **Why it works this way:** [Building a
clock](https://bhagesh-h.github.io/FALCONAge/methods/building.html)



# Chapter 16. Add a clock

A clock of your own is a YAML entry and a coefficient file. Added to a
run, it gets everything a catalogue clock gets: the coverage check, the
specimen check, a technical standard error, a row in the report, and a
manifest entry recording that it is yours and the SHA-256 of its file.

### 1. Write the entry

`my_clocks/mycohortclock.yaml`:

``` yaml
id: mycohortclock
name: Cohort clock fitted on our blood samples
data_type: dna_methylation
tissue: [whole blood]
platform: [EPICv1]
training_target: [chronological age]
scale_type: age_years
unit: [years]
coefficients: mycohortclock.csv
reference: mycohortclock_reference.csv    # optional
```

`my_clocks/mycohortclock.csv`:

    feature_id,coefficient
    (Intercept),31.47
    cg16867657,22.1
    cg06639320,-14.8

[Build a clock](https://bhagesh-h.github.io/FALCONAge/own/compare.html)
and [Stack clocks](https://bhagesh-h.github.io/FALCONAge/own/stack.html)
write both files for you.

| Field | Why it is required |
|----|----|
| `scale_type` | Decides which arithmetic is legal: `age_years` permits acceleration, a pace or a relative score does not |
| `tissue` | Drives the check that your samples are the specimen the clock was fitted on |
| `training_target`, `unit` | What the score estimates, and in what |
| `coefficients` | One weight per feature, with an optional `(Intercept)` row |

Optional: `platform`, `reference` (a `feature_id,value` file of fill
values for CpGs a dataset lacks), `preprocess` and `postprocess` steps
by the names in the registry, `citation`, `notes`.

### 2. Score it

From the command line, point `run` at the folder:

``` bash
docker run --rm -v "$PWD:/work" bhagesh/falconage:1.0.0-cpu \
  run betas.csv --samples samples.csv --clocks-dir my_clocks
```

From Python or R, add it for the session:

<div class="panel-tabset">

#### Python

``` python
fa.add_clock("my_clocks/mycohortclock.yaml")
res = fa.score(d, clocks=["mycohortclock", "horvath2013"])
```

#### R

``` r
add_clock("my_clocks/mycohortclock.yaml")
res <- score(d, clocks = c("mycohortclock", "horvath2013"))
```

</div>

### What is checked, and what a clock of your own does not get

The coefficient file must have two columns, unique feature ids and
finite values; processing steps must name operations FALCONAge
implements; and the id may not replace a clock that ships with the
package. A clock of your own has no published calibration, so it gets no
prediction interval until you supply one, and no published reliability,
so `interpretation()` says so.



# Chapter 17. Stack clocks

A stack learns weights for several clocks’ scores, out of fold, and
reports the result next to the best single clock and the plain mean
measured the same way, so the gain (or its absence) is visible.

### 1. Fit a stack

<div class="panel-tabset">

#### Python

``` python
res = fa.score(d, clocks="compatible")
st  = fa.stack_clocks(res, target="age",
                      clocks=["horvath2013", "hannum", "dnamphenoage", "zhangen"],
                      method="nnls")

st.weights        # one weight per clock, on standardised scores
st.metrics        # out-of-fold MAE, MedAE, r, slope
st.comparison     # each clock alone, and the plain mean, measured the same way
```

#### R

``` r
res <- score(d, clocks = "compatible")
st  <- stack_clocks(res, target = "age",
                    clocks = c("horvath2013", "hannum", "dnamphenoage", "zhangen"),
                    method = "nnls")
st$weights
st$comparison
```

</div>

### 2. Choose a method

| `method` | What it does | Allowed when |
|----|----|----|
| `"mean"` | The plain average of the scores | Every clock has the same scale type |
| `"nnls"` | Non-negative weights on standardised scores (default) | Always |
| `"ridge"` | Ridge-penalised weights on standardised scores | Always |
| `"cox"` | A Cox model on the scores; `target` is follow-up time and `event_col` the event | You have survival data |

A plain mean of years and a pace has no unit, so it is refused; the
learned methods standardise each clock and take the scale of the target.
First-generation clocks are strongly correlated with each other, which
is why the weights come from non-negative least squares or ridge.

### 3. Save it as a clock

``` python
st.to_clock("mystack", "my_clocks/")
```

When every clock in the stack is a weighted sum of CpGs followed by
constant shifts and scalings, the stack is itself a weighted sum over
all their CpGs. It is written as one coefficient file that [Add a
clock](https://bhagesh-h.github.io/FALCONAge/own/add.html) scores like
any other, with coverage checks and a technical standard error. A stack
containing a clock with a nonlinear output (Horvath’s anti-log, a
sigmoid) stays in the session: use `st.predict(res)`.

One difference to know: a CpG your data lacks, and that no clock in the
stack publishes a reference value for, is filled with the mean of the
present CpGs. For the combined clock that mean is taken over all of its
CpGs rather than each clock’s own, so on data missing such CpGs the
collapsed clock and `st.predict(res)` can differ slightly.
`warnings.csv` names every such fill.

### Do not test a group difference on the samples the stack was fitted on

A stack fitted on the same samples you then compare between groups has
already seen the answer. Fit it on one set and test on another. To ask
whether a group difference holds across clocks, use `fa.consensus()`
instead ([Age
acceleration](https://bhagesh-h.github.io/FALCONAge/analysis/acceleration.html)):
it tests rather than fits.



# Chapter 18. Choosing a clock

There is no best clock. There is a clock that answers the question you
asked, and a much larger number that answer a different one in the same
units.

The generations are not successive improvements on one measurement. Each
was trained against a different target, so each returns a different
quantity: a predicted age whose signal is the residual, a mortality
composite rescaled into year-like units, a rate, a pair of scores with
no shared origin, and a division count. A later generation is not a
better answer to the earlier question, and the first generation is still
the right choice when the question really is how old a sample looks.

### Choosing by research question

<!-- BEGIN GENERATED: by-question -->

| Question | Clocks | Scale |
|:---|:---|:---|
| How old does this sample look? | `altumage`, `cage`, `corticalclock`, `hannum`, `horvath2013`, `intrinclock`, `lin`, `metaboage`, `pedbe`, `skinandblood`, `stoch`, `stocp`, and 6 more | `age_years` |
| How old is this newborn, gestationally? | `bohlin`, `knight`, `leecontrol`, `leerefinedrobust`, `leerobust`, `mayne` | `gestational_weeks` |
| How fast is this person aging? | `dunedinpoam38` | `pace_ratio` |
| Who is at risk of dying sooner, or is frailer? | `dnamfili`, `dnamic`, `dnamphenoage`, `hd`, `hrsinchphenoage`, `kdm`, `linage2`, `metabohealth`, `phenoage`, `zhangmortality` | `age_years`, `mortality_log_hazard`, `relative_score` |
| Is damage separable from adaptation? | `yingadaptage`, `yingdamage` | `age_years_relative` |
| How much has this tissue divided? | `cellpopage`, `epicmithyper`, `epicmithypo`, `epitoc1`, `epitoc2`, `epitoc3`, `hypoclock`, `replitali`, `stemtoc`, `stemtocvitro` | `divisions`, `relative_score` |
| What is the blood’s cell composition? | `deconvolutebloodepicbcell`, `deconvolutebloodepiccd4tcell`, `deconvolutebloodepiccd8tcell`, `deconvolutebloodepicmonocyte`, `deconvolutebloodepicneutrophil`, `deconvolutebloodepicnkcell` | `proportion` |
| How long are the telomeres? | `dnamtl` | `telomere_kb` |
| What is this person exposed to, or how do they live? | `dnamstress`, `mccartneyalcohol`, `mccartneybmi`, `mccartneybodyfat`, `mccartneyeducation`, `mccartneyhdlcholesterol`, `mccartneyldlcholesterol`, `mccartneysmoking`, `mccartneytotalcholesterol`, `mccartneytotalhdlratio`, `mccartneywhr` | `relative_score` |
| What is a specific protein or lab value likely to be? | `downsyndrome` | `relative_score` |
| Is a named disease more likely? | `depressionbarbu`, `prostatecancerkirby` | `relative_score` |

Every one of the 68 catalogued clocks appears above, routed by its
declared `predicts` field. The full table with paper links is the [clock
catalogue](https://bhagesh-h.github.io/FALCONAge/clocks/catalogue.html).

<!-- END GENERATED: by-question -->

Every clock listed ships its coefficients in the package and scores
offline. A clock of your own joins the same registry with
[`add_clock`](https://bhagesh-h.github.io/FALCONAge/own/add.html).

<div class="panel-tabset">

#### Python

``` python
reg = fa.registry.load()
reg.filter(generation="second", availability="bundled")
reg.compatible_with(d)
```

#### R

``` r
list_clocks(generation = "second", tier = "bundled")
compatible_clocks(d)
```

</div>

### Scale type and permitted operations

Every clock carries a `scale_type`, and it decides which downstream
operations are defined.

<!-- BEGIN GENERATED: guide-scales -->

| Scale | Clocks | Permitted | Refused, and why |
|:---|---:|:---|:---|
| `age_years` | 23 | acceleration, correlate, difference, mean, residual | — |
| `relative_score` | 18 | correlate, rank | everything except correlation and rank: there is no external unit to difference or average |
| `divisions` | 9 | correlate, difference, mean, rank | acceleration: a division count is not elapsed time |
| `gestational_weeks` | 6 | acceleration, correlate, difference, mean, residual | mixing with an age in years |
| `proportion` | 6 | compositional, correlate, difference, mean | anything ignoring the sum-to-one constraint |
| `mortality_log_hazard` | 2 | correlate, hazard ratio, mean, rank | acceleration: a log-hazard has no zero on the age scale |
| `age_years_relative` | 2 | correlate, difference, mean, residual | acceleration: the clock tracks age with a slope near one but its origin moves between cohorts, so predicted minus chronological measures the cohort |
| `telomere_kb` | 1 | acceleration, correlate, difference, mean | comparison with an age in years; and higher is the *younger* direction here, unlike every age clock beside it |
| `pace_ratio` | 1 | correlate, difference, mean, rank | acceleration: it is already a rate |

<!-- END GENERATED: guide-scales -->

`acceleration()` enforces this. Naming a clock whose scale does not
support it is an error; leaving the clock list empty quietly excludes
them.

### Coverage and validity

A clock trained on 450K runs perfectly well on EPIC data that carries
its probes, and fails on 450K data filtered to 20,000 probes. Only the
feature list can answer whether a clock is usable, which is what
`compatible_clocks()` checks.

But high coverage does not make a result meaningful. The mammalian
methylation array was designed around CpGs conserved across mammals, and
carries 96% of Horvath2013’s 353 probes, so a zebra scores at *higher*
coverage than many human 450K datasets and returns a confident number
from a clock fitted on people. Nothing in the arithmetic can notice. Set
`species` and FALCONAge warns:

``` r
d <- falcon_data(betas, modality = "dna_methylation", species = "Equus grevyi")
res <- score(d, clocks = "horvath2013")
manifest(res)$warnings
#> trained on Homo sapiens, scored on Equus grevyi. Feature coverage says nothing
#> about whether the coefficients transfer across species.
```

### Feature count and coefficient mass

Coverage has two forms and they disagree exactly when it matters: how
many of a clock’s features are present, and what share of the model’s
total \|coefficient\| those present features carry. Check both before
committing to a clock on a given array.

``` python
fa.probe_loss(d, clocks="scoreable")
#> horvath2013   coverage 0.9632   mass_coverage 0.6117   cg16867657 (14.1%), ...
```

Ninety-six per cent of probes present, sixty-one per cent of the model.
The scoring floor applies to both, so this is refused with the heaviest
absent probes named rather than scored into a confident number. The gap
opens because elastic-net coefficients are far from uniform: a handful
of probes carry a disproportionate share of the total weight, and losing
four per cent of the probes loses thirty-five per cent of the model when
the missing four per cent are those.

→ [Probe loss,
priced](https://bhagesh-h.github.io/FALCONAge/methods/uncertainty.html#probe-loss-priced)
prices the same loss in years, per clock per platform.

### Reliability

“Reliable” means two different things, and they do not track together:

|  | What is repeated | What it measures |
|----|----|----|
| **Technical ICC** | the same DNA, assayed twice | the assay, and the model’s sensitivity to array noise |
| **Biological ICC** | the same person, sampled again days later | whether the number is a property of the person or of the morning |

Nearly every clock is technically excellent; biological ICCs are
substantially lower. Measured on the clocks published with both, the gap
is widest for the mortality- and pace-trained clocks, which are the ones
most often used to claim an intervention worked. `res.interpretation()`
carries both columns, with `None` meaning “not established” rather than
“fine”.

**The rule:** measuring change within a person, prefer a clock with a
published biological ICC, and measure the ICC on your own replicates
when you can (below).

#### Measure it on your own cohort

A published ICC is somebody else’s laboratory. Measure yours:

``` python
se = fa.technical_se(res, data)
se.diagnostics[["median_se", "se_over_sd", "implied_cohort_icc"]]
```

`se_over_sd`  
measurement error as a fraction of the spread between your own samples.
Above 1, the clock cannot distinguish two of your samples however
different their point estimates look.

`implied_cohort_icc`  
the reliability *this* cohort implies. Often below the published figure,
because a narrow age range leaves less between-sample variance for the
same assay noise.

For scale: on this package’s test corpus Horvath 2013 comes out at ±1.58
years, DunedinPoAm38 is least repeatable at 0.72, and the 319,607-probe
BLUP clock reaches 1.00. With technical duplicates,
`fa.icc_from_replicates(data, "subject")` replaces the published
per-probe table with your own plates. → [Propagating measurement
error](https://bhagesh-h.github.io/FALCONAge/methods/uncertainty.html#propagating-measurement-error)
for the propagation itself.

#### Then ask how many samples you need

``` python
fa.power("horvath2013", effect=0.5, result=pilot)
```

At ICC 0.9 a tenth of the sample size exists only to average out the
instrument, and the function says so. It refuses to default the standard
deviation, because n scales with its square.

### Specimen type

Saliva clock ages ran **3.83–16.46 years above buffy coat in the same 91
people**, while still correlating with them at Spearman 0.45–0.69. A
correlation check passes and the output is a decade out, because
correlation is not agreement. The left panel is the whole argument:
every point sits above the line of identity, which is a bias, and the
scatter around it stays tight, which is what a correlation coefficient
reports. The paired lines on the right show the same donors shifting in
the same direction, so no amount of averaging removes it.

**The rule:** set `obs["tissue"]` on every dataset. FALCONAge then
compares it against what each clock was fitted on. Pan-tissue clocks say
nothing, most warn with the measured discordance, and nine refuse
outright. Cell-free DNA is refused by every clock. No `tissue` column
gets one warning saying the check did not run.

→ [Specimen type is not
metadata](https://bhagesh-h.github.io/FALCONAge/methods/uncertainty.html#specimen-type-is-not-metadata)
for the refusals and the measurements behind each. Reliability,
technical against biological, is \[39\].

### The clock catalogue

<div class="panel-tabset">

#### Python

``` python
reg = fa.registry.load()
reg.filter(availability="bundled")
reg.search("mortality")
reg.get("horvath2013")
reg.get("dnamphenoage").cite("bibtex")
```

#### R

``` r
list_clocks(tier = "bundled")
list_clocks(search = "mortality")
clock_info("horvath2013")
cite_clock("dnamphenoage", "bibtex")
```

</div>

To score a catalogue clock from a coefficient file you hold, such as a
corrected copy,
`fa.registry.register_local_weights("hannum", "my_copy.csv")`; to score
a clock that is not in the catalogue, [add
it](https://bhagesh-h.github.io/FALCONAge/own/add.html).

### Which clocks were trained on data like mine

[`overlap.csv`](https://bhagesh-h.github.io/FALCONAge/clocks/overlap.csv)
is one row per clock, 39 columns, built to answer the question the
catalogue answers backwards: *which clocks were fitted on the kind of
data I have?*

``` python
import pandas as pd

d = pd.read_csv("https://bhagesh-h.github.io/FALCONAge/clocks/overlap.csv")
d[(d.tissue_class == "whole_blood")
  & (d.species == "Homo sapiens")
  & (d.population_class.isin(["adults", "older_adults"]))
  & (d.target_class == "chronological_age")
  & (d.ships_coefficients == "yes")][["clock_id", "n_features", "verify_url"]]
```

Read it with a CSV parser rather than `awk -F,` or `cut`: citations and
several metadata fields contain commas, so a naive split silently shifts
the columns.

[`overlap_col_desc.csv`](https://bhagesh-h.github.io/FALCONAge/clocks/overlap_col_desc.csv)
is the data dictionary: one row per column with its description, where
the value came from, its closed vocabulary where it has one, how many
cells are blank, and **what a blank means**. Five columns use an empty
cell to carry information, and in each case the wrong reading is the
plausible one: a blank `feature_overlap_jaccard` means the features are
not distributed, not that the overlap is zero, and a blank
`training_cohort_note` means nothing was written down, not that the
cohort was healthy. Both files are generated together, and a test
asserts the dictionary describes exactly the columns the table has.

`tissue_class`, `population_class` and `target_class` are coarsenings of
the registry’s own vocabulary, with the raw value kept beside each one.
`profile_key` groups clocks fitted on the same kind of data, and
`peers_same_profile` names them.

Two senses of overlap are in the file. **Training overlap** is registry
metadata and exact. **Feature overlap** is the literal shared CpGs
between two clocks as a Jaccard index, computable for the clocks that
ship coefficients; the rest are blank rather than zero, because *shares
no CpGs* and *we cannot see this clock’s CpGs* are different facts.
Nearby clocks come out where they should: `leerobust` and
`leerefinedrobust` share 395 probes at J = 0.71.

Every row carries a `verify_url`, and every one is checked. 66 clocks
are cross-referenced against [TranslAGE](https://www.translage.io),
[biolearn](https://github.com/bio-learn/biolearn) and
[methylCIPHER](https://github.com/HigginsChenLab/methylCIPHER), so the
training target can be checked against someone who is not us.

**One column is deliberately absent.** Health status of the training
cohort is not a registry field and is not recoverable from one: few
entries mention it in free text. There is no “trained on healthy
individuals” column, because the honest value for nearly every row would
be *unstated*. `target_class == disease` identifies the clocks fitted on
a disease endpoint, which is the part that is knowable; for the rest,
read the paper behind `verify_url`.

Regenerate with `python python/tools/build_overlap.py --check-urls`.



# Chapter 19. What a score means

### The clock catalogue

68 human clocks, every one of which ships its coefficients (or is a
formula with none) and scores offline: 62 on DNA methylation, 4 on
clinical chemistry (PhenoAge, KDM, homeostatic dysregulation, LinAge2)
and 2 on NMR metabolomics (MetaboAge, MetaboHealth). The full list with
papers is the [clock
catalogue](https://bhagesh-h.github.io/FALCONAge/clocks/catalogue.html);
clocks of your own are added with
[`fa.add_clock()`](https://bhagesh-h.github.io/FALCONAge/own/add.html).

``` python
fa.registry.load().list()
```

### Training targets, and what a score means

Chronological age is elapsed time, and it is known without measuring
anything. Biological age is an estimate of how worn a body is for that
elapsed time. Pace of aging is a rate, years of wear per year of
calendar time, and it is the only one of the three that a single sample
cannot establish on its own: the Dunedin measure was fitted against two
decades of repeated biomarker readings. Because the three carry
different units, none of them converts into another, which is why a
registry entry declares a `scale_type` and not only a unit.

What a clock’s output *means* is set by the outcome it was regressed on.
Six families are in common use, and they are not variants of one
quantity:

- **Chronological-age clocks** (Horvath 2013 \[5\], Hannum 2013 \[4\])
  are fitted to calendar age. Their error bars are prediction error
  against a known truth.

- **Mortality- and morbidity-trained clocks** (DNAm PhenoAge \[8\]) are
  fitted to a survival-weighted composite and then rescaled into years.
  The unit is years; the target was never age.

- **Pace-of-aging clocks** (DunedinPoAm38 \[14\]) are fitted to the
  *rate of change* in organ-system biomarkers tracked longitudinally.
  Belsky and colleagues draw the distinction directly:

  > \[Pace-of-aging measures capture\] the rate of deterioration in
  > system integrity occurring over a fixed time interval, whereas
  > epigenetic clocks estimate the progress of aging up to a
  > cross-section in time.
  >
  > [Belsky et al., *eLife* 2022](https://doi.org/10.7554/eLife.73420)

- **Mitotic clocks** (epiTOC2 \[20\], StemTOC) estimate cumulative
  stem-cell divisions. The quantity is a count, not elapsed time.

- **Causality-enriched clocks** (CausAge, DamAge, AdaptAge) restrict
  features to CpGs with Mendelian-randomisation support, separating
  damaging from adaptive change ([Ying et al., *Nature Aging*
  2024](https://doi.org/10.1038/s43587-023-00557-0), \[19\]).

- **Deconvolution models** return cell-type proportions, a composition
  that is not forced to sum to one; the sum shows how much of the sample
  the reference explains.

Reporting all six as “biological age” discards the information needed to
interpret any of them.

### Scale types and permitted operations

Reading down the acceleration column is the shortest statement of the
problem. Only an age in years with a fixed origin admits it. A pace is
already a rate, a division count is not elapsed time, and a log hazard
is not even on an additive scale, so subtracting a chronological age
from any of them produces a number with no units behind it. The matrix
drawn here is the same one the code enforces, in `LEGAL_OPS`.

Every registry entry declares a `scale_type` alongside its unit,
platform, species and the tissue its coefficients were fitted in. That
field decides which downstream operations FALCONAge will perform:

<!-- BEGIN GENERATED: scales -->

| `scale_type` | n | What the number is | Units in the registry | Operations permitted |
|----|---:|----|----|----|
| `age_years` | 23 | An age. The model predicts elapsed time and is reported on the same scale as chronological age. | years | acceleration, correlate, difference, mean, residual |
| `relative_score` | 18 | A score with no external unit. Comparable within a cohort, meaningless as an absolute value. | unitless, ratio, passages, and 3 more | correlate, rank |
| `divisions` | 9 | A count of cell divisions, not elapsed time. | beta value, proportion, cell divisions per stem cell, and 1 more | correlate, difference, mean, rank |
| `gestational_weeks` | 6 | An age, before birth. | weeks | acceleration, correlate, difference, mean, residual |
| `proportion` | 6 | A composition. The estimates are fractions of a whole, not forced to sum to one; the sum shows how much the reference explains. | proportion | compositional, correlate, difference, mean |
| `mortality_log_hazard` | 2 | A risk on the log-hazard scale. Exponentiating a difference gives a hazard ratio. | log hazard, per cohort SD, unitless | correlate, hazard ratio, mean, rank |
| `age_years_relative` | 2 | An age in years with a slope near one against chronological age, but no fixed origin: the offset moves between cohorts. The residual and group differences are defined; predicted minus chronological is not. | years | correlate, difference, mean, residual |
| `telomere_kb` | 1 | An estimated physical length. | kilobases | acceleration, correlate, difference, mean |
| `pace_ratio` | 1 | A rate: how much biological ageing per year of calendar time, at the moment of sampling. | biological years per chronological year | correlate, difference, mean, rank |

<!-- END GENERATED: scales -->

Age acceleration is the residual of predicted age on chronological age.
It is defined when the prediction is in years and undefined when it is a
rate, so asking for it on DunedinPoAm38 is an error with a message, not
a number:

    IllegalOperationError: 'acceleration' is not defined for dunedinpoam38, whose output is
    pace_ratio (biological years per chronological year).
      Legal here: correlate, difference, mean, rank.
      A pace of aging is already a rate; subtracting chronological age from it is a units
      error, not a conservative choice.

### Output types and units

A tool that returns a bare number is dangerous. Every prediction needs
at least six attached fields.

#### The output record

`res.long()` returns one row per sample per clock:

    sample_id, clock, value, unit, scale_type, generation, predicts, n_features,
    coverage, mass_coverage, n_imputed, availability, registry_version, falconage_version

Acceleration is computed separately (`fa.acceleration`, with the
convention recorded), the missing features and the fill used are in
`res.coverage`, and the coefficient files’ SHA-256, the precision and
the package versions are in `res.manifest`. pyaging writes the value
into `adata.obs[clock]` and its metadata and missingness into
`adata.uns`.

#### Scale types and what you may do with them

| Scale type | Clocks in the catalogue | Legal operations |
|----|----|----|
| Age in years | Horvath 2013, Hannum, DNAm PhenoAge, Skin & Blood, AltumAge, cAge, PhenoAge, KDM, LinAge2, MetaboAge | subtract CA; residualise on CA; average across clocks only after z-scoring |
| Age in years, offset not fixed | DamAge, AdaptAge | residualise on CA; do **not** subtract CA |
| Gestational age in weeks | Knight, Bohlin, Mayne, Lee (three variants) | compare to ultrasound GA, not to adult clocks |
| Rate (bio-y per chron-y) | DunedinPoAm38 | centred at 1; do **not** subtract CA |
| Log hazard | ZhangMortality, MetaboHealth | exponentiate for HR; convert to years only with an explicit Gompertz assumption |
| Proportion | the six blood cell-type deconvolutions | not forced to sum to 1; the sum is how much the reference explains |
| Mitotic count or beta value | epiTOC1, epiTOC2, epiTOC3, stemTOC, HypoClock, EpiCMIT, RepliTali | ordinal within a study; not comparable across platforms |
| Physical units | DNAmTL (kb) | compare to measured values |
| Unitless score | DNAmFILi, DNAmIC, DNAmStress, DownSyndrome, the McCartney EpiScores, CellPopAge | rank or z-score within cohort |

A clock in physical units can be checked against the range its source
paper reports, and a median far outside that range is a computation
error rather than an unusual cohort. FALCONAge warns (category
`implausible`) when a cohort’s median leaves the interval. For DNAmTL
the interval is 4 to 12 kb: Lu et al. 2019 (Table 2) fit DNAmTL = 8.05 −
0.018 × age kb in their test cohorts, 6.2 to 8.0 kb from birth to 100
years. The guard exists because FALCONAge 1.0.0 shipped DNAmTL with its
intercept’s sign reversed and returned about −8.5 kb on adult blood;
nothing flagged it. Two more human scales carry an interval, each from a
published fact about people:

| Scale, unit | Interval | Why |
|----|----|----|
| `age_years`, years | −1 to 122.45 | No verified human age exceeds Jeanne Calment’s 122 years and 164 days ([Robine et al. 2019](https://doi.org/10.1093/gerona/glz198)); an age below −1 year precedes conception |
| `pace_ratio`, years per year | 0.40 to 2.44 | The slowest and fastest members of the Dunedin Study aged 0.40 and 2.44 biological years per chronological year over two decades ([Belsky et al. 2022](https://doi.org/10.7554/eLife.73420)) |

The intervals are wide on purpose: they catch a sign, unit or fill
error, not an unusual cohort. The pace interval did so on its first real
run. Forced below its 80% coverage floor on one cohort’s EPIC v1 betas,
DunedinPoAm38 lost 11 of its 46 CpGs, 23% of its weight, and with those
filled by the dataset’s mean its median was 0.38. The authors’ own
`PoAmProjector` fills an absent probe with its Dunedin cohort mean,
which gives 0.85 on the same data. FALCONAge now fills from those means
too.

#### Aggregate outputs

FALCONAge returns the first, second and last of these; the composite
score and the per-system profile are not built.

- Per-sample × per-clock long table (`res.long()`) and wide matrix
  (`res.wide()`).
- Age-acceleration matrix, absolute and residual
  (`fa.acceleration(res, method="both")`).
- Composite score: z-score each clock within cohort, then average within
  generation class, and report the classes separately rather than mixing
  generations.
- QC block: missingness per clock, platform detected, imputation used,
  warnings.



# Chapter 20. Clock catalogue

<!-- GENERATED by docs/build_catalogue.py from the shipped registry.
     Edit that script or the registry, not this file. -->

This page is written from the registry the package ships, so it cannot
describe a catalogue different from the one that scores. Every column
below is a field the scoring code reads.

`scale_type` is the load-bearing one. It is not a label: it decides
which downstream operations FALCONAge will perform, and asking for age
acceleration on a `pace_ratio` clock is refused rather than computed.

**68 human clocks**, registry schema `1.1.0`. Every one ships its
coefficients inside the package, or is a formula with none, so it scores
offline and gives the same numbers on any machine. Clocks of your own
are added with `fa.add_clock()` ([Add a
clock](https://bhagesh-h.github.io/FALCONAge/own/add.html)).

| Clock | Year | Predicts | Scale | Features | Tissue | Platform | Paper |
|----|---:|----|----|---:|----|----|----|
| `altumage` | 2022 | chronological age | `age_years` | 20318 | multi-tissue | 27K, 450K | [de Lima Camillo 2022](https://doi.org/10.1038/s41514-022-00085-y) |
| `bohlin` | 2016 | gestational age | `gestational_weeks` | 96 | cord blood | 450K | [Bohlin 2016](https://doi.org/10.1186/s13059-016-1063-4) |
| `cage` | 2023 | chronological age | `age_years` | 3225 | whole blood | 450K, EPICv1 | [Bernabeu 2023](https://doi.org/10.1186/s13073-023-01161-y) |
| `cellpopage` | 2024 | cell-population passage age | `relative_score` | 42 | cultured fibroblasts | EPICv1 | [Lujan 2024](https://doi.org/10.1186/s13073-024-01349-w) |
| `corticalclock` | 2020 | chronological age | `age_years` | 347 | brain cortex | 450K | [Shireby 2020](https://doi.org/10.1093/brain/awaa334) |
| `deconvolutebloodepicbcell` | 2018 | B cell proportion | `proportion` | 450 | whole blood | 450K, EPICv1 | [Salas 2018](https://doi.org/10.1186/s13059-018-1448-7) |
| `deconvolutebloodepiccd4tcell` | 2018 | CD4+ T cell proportion | `proportion` | 450 | whole blood | 450K, EPICv1 | [Salas 2018](https://doi.org/10.1186/s13059-018-1448-7) |
| `deconvolutebloodepiccd8tcell` | 2018 | CD8+ T cell proportion | `proportion` | 450 | whole blood | 450K, EPICv1 | [Salas 2018](https://doi.org/10.1186/s13059-018-1448-7) |
| `deconvolutebloodepicmonocyte` | 2018 | monocyte proportion | `proportion` | 450 | whole blood | 450K, EPICv1 | [Salas 2018](https://doi.org/10.1186/s13059-018-1448-7) |
| `deconvolutebloodepicneutrophil` | 2018 | neutrophil proportion | `proportion` | 450 | whole blood | 450K, EPICv1 | [Salas 2018](https://doi.org/10.1186/s13059-018-1448-7) |
| `deconvolutebloodepicnkcell` | 2018 | natural killer cell proportion | `proportion` | 450 | whole blood | 450K, EPICv1 | [Salas 2018](https://doi.org/10.1186/s13059-018-1448-7) |
| `depressionbarbu` | 2021 | major depressive disorder | `relative_score` | 196 | whole blood | EPICv1 | [Barbu 2021](https://doi.org/10.1038/s41380-020-0808-3) |
| `dnamfili` | 2022 | frailty risk | `relative_score` | 20 | whole blood | EPICv1, 450K | [Li 2022](https://doi.org/10.1038/s41467-022-32893-x) |
| `dnamic` | 2025 | intrinsic capacity | `relative_score` | 91 | whole blood | EPICv1 | [Fuentealba 2025](https://doi.org/10.1038/s43587-025-00883-5) |
| `dnamphenoage` | 2018 | phenotypic age | `age_years` | 513 | whole blood | 27K, 450K, EPICv1 | [Levine 2018](https://doi.org/10.18632/aging.101414) |
| `dnamstress` | 2023 | stress exposure | `relative_score` | 211 | whole blood | EPICv1 | [Jung 2023](https://doi.org/10.1016/j.biopsych.2022.06.036) |
| `dnamtl` | 2019 | leukocyte telomere length | `telomere_kb` | 140 | whole blood | 450K, EPICv1 | [Lu 2019](https://doi.org/10.18632/aging.102173) |
| `downsyndrome` | 2021 | Down syndrome methylation score | `relative_score` | 652 | neonatal blood spots | EPICv1 | [Muskens 2021](https://doi.org/10.1038/s41467-021-21064-z) |
| `dunedinpoam38` | 2020 | pace of aging | `pace_ratio` | 46 | whole blood | 450K | [Belsky 2020](https://doi.org/10.7554/elife.54870) |
| `epicmithyper` | 2020 | mitotic age | `divisions` | 184 | B cells | 450K, EPICv1 | [Duran-Ferrer 2020](https://doi.org/10.1038/s43018-020-00131-2) |
| `epicmithypo` | 2020 | mitotic age | `divisions` | 1164 | B cells | 450K, EPICv1 | [Duran-Ferrer 2020](https://doi.org/10.1038/s43018-020-00131-2) |
| `epitoc1` | 2016 | mitotic age | `divisions` | 385 | multi-tissue, whole blood | 450K | [Yang 2016](https://doi.org/10.1186/s13059-016-1064-3) |
| `epitoc2` | 2020 | mitotic age | `divisions` | 163 | whole blood | 450K | [Teschendorff 2020](https://doi.org/10.1186/s13073-020-00752-3) |
| `epitoc3` | 2020 | mitotic age | `divisions` | 170 | cultured primary human cells, whole blood, multi-tissue, cord blood | 450K, EPICv1 | [Teschendorff 2020](https://doi.org/10.1186/s13073-020-00752-3) |
| `hannum` | 2013 | chronological age | `age_years` | 71 | whole blood | 450K | [Hannum 2013](https://doi.org/10.1016/j.molcel.2012.10.016) |
| `hd` | 2013 | physiological dysregulation | `relative_score` | — | blood | clinical laboratory assays | [Cohen 2013](https://doi.org/10.1016/j.mad.2013.01.004) |
| `horvath2013` | 2013 | chronological age | `age_years` | 353 | multi-tissue | 27K, 450K | [Horvath 2013](https://doi.org/10.1186/gb-2013-14-10-r115) |
| `hrsinchphenoage` | 2022 | phenotypic age | `age_years` | 959 | whole blood | 450K, EPICv1 | [Higgins-Chen 2022](https://doi.org/10.1038/s43587-022-00248-2) |
| `hypoclock` | 2020 | mitotic age | `divisions` | 678 | multi-tissue | 450K | [Teschendorff 2020](https://doi.org/10.1186/s13073-020-00752-3) |
| `intrinclock` | 2024 | chronological age | `age_years` | 370 | multi-tissue | 450K, EPICv1 | [Tomusiak 2024](https://doi.org/10.1038/s42003-024-06609-4) |
| `kdm` | 2006 | biological age | `age_years` | — | blood | clinical laboratory assays | [Klemera 2006](https://doi.org/10.1016/j.mad.2005.10.004) |
| `knight` | 2016 | gestational age | `gestational_weeks` | 148 | cord blood, neonatal blood spots | 27K, 450K | [Knight 2016](https://doi.org/10.1186/s13059-016-1068-z) |
| `leecontrol` | 2019 | gestational age | `gestational_weeks` | 546 | placenta | 450K, EPICv1 | [Lee 2019](https://doi.org/10.18632/aging.102049) |
| `leerefinedrobust` | 2019 | gestational age | `gestational_weeks` | 395 | placenta | 450K, EPICv1 | [Lee 2019](https://doi.org/10.18632/aging.102049) |
| `leerobust` | 2019 | gestational age | `gestational_weeks` | 558 | placenta | 450K, EPICv1 | [Lee 2019](https://doi.org/10.18632/aging.102049) |
| `lin` | 2016 | chronological age | `age_years` | 99 | whole blood | 27K, 450K | [Lin 2016](https://doi.org/10.18632/aging.100908) |
| `linage2` | 2025 | mortality risk | `age_years` | 59 | blood | clinical laboratory assays | [Fong 2025](https://doi.org/10.1038/s41514-025-00221-4) |
| `mayne` | 2017 | gestational age | `gestational_weeks` | 62 | placenta | 27K, 450K | [Mayne 2017](https://doi.org/10.2217/epi-2016-0103) |
| `mccartneyalcohol` | 2018 | alcohol consumption | `relative_score` | 450 | whole blood | EPICv1 | [McCartney 2018](https://doi.org/10.1186/s13059-018-1514-1) |
| `mccartneybmi` | 2018 | body mass index | `relative_score` | 1109 | whole blood | EPICv1 | [McCartney 2018](https://doi.org/10.1186/s13059-018-1514-1) |
| `mccartneybodyfat` | 2018 | body fat percentage | `relative_score` | 968 | whole blood | EPICv1 | [McCartney 2018](https://doi.org/10.1186/s13059-018-1514-1) |
| `mccartneyeducation` | 2018 | educational attainment | `relative_score` | 373 | whole blood | EPICv1 | [McCartney 2018](https://doi.org/10.1186/s13059-018-1514-1) |
| `mccartneyhdlcholesterol` | 2018 | HDL cholesterol | `relative_score` | 737 | whole blood | EPICv1 | [McCartney 2018](https://doi.org/10.1186/s13059-018-1514-1) |
| `mccartneyldlcholesterol` | 2018 | LDL cholesterol | `relative_score` | 233 | whole blood | EPICv1 | [McCartney 2018](https://doi.org/10.1186/s13059-018-1514-1) |
| `mccartneysmoking` | 2018 | smoking exposure | `relative_score` | 233 | whole blood | EPICv1 | [McCartney 2018](https://doi.org/10.1186/s13059-018-1514-1) |
| `mccartneytotalcholesterol` | 2018 | total cholesterol | `relative_score` | 204 | whole blood | EPICv1 | [McCartney 2018](https://doi.org/10.1186/s13059-018-1514-1) |
| `mccartneytotalhdlratio` | 2018 | total-to-HDL cholesterol ratio | `relative_score` | 412 | whole blood | EPICv1 | [McCartney 2018](https://doi.org/10.1186/s13059-018-1514-1) |
| `mccartneywhr` | 2018 | waist-to-hip ratio | `relative_score` | 226 | whole blood | EPICv1 | [McCartney 2018](https://doi.org/10.1186/s13059-018-1514-1) |
| `metaboage` | 2020 | chronological age | `age_years` | 56 | blood | Nightingale Health 1H-NMR | [van den Akker 2020](https://doi.org/10.1161/CIRCGEN.119.002610) |
| `metabohealth` | 2019 | mortality | `mortality_log_hazard` | 14 | blood | Nightingale Health 1H-NMR | [Deelen 2019](https://doi.org/10.1038/s41467-019-11311-9) |
| `pedbe` | 2020 | chronological age | `age_years` | 94 | buccal epithelium | 450K, EPICv1 | [McEwen 2020](https://doi.org/10.1073/pnas.1820843116) |
| `phenoage` | 2018 | phenotypic age | `age_years` | 10 | blood | clinical laboratory assays | [Levine 2018](https://doi.org/10.18632/aging.101414) |
| `prostatecancerkirby` | 2017 | prostate cancer | `relative_score` | 3 | prostate | 450K | [Kirby 2017](https://doi.org/10.1186/s12885-017-3252-2) |
| `replitali` | 2022 | replicative history | `divisions` | 87 | cultured primary human cells | EPICv1 | [Endicott 2022](https://doi.org/10.1038/s41467-022-34268-8) |
| `skinandblood` | 2018 | chronological age | `age_years` | 391 | buccal epithelium, whole blood, epithelium, cultured fibroblasts, skin, cord blood | 450K, EPICv1 | [Horvath 2018](https://doi.org/10.18632/aging.101508) |
| `stemtoc` | 2024 | mitotic age | `divisions` | 371 | multi-tissue, cultured human cells, whole blood | 450K, EPICv1 | [Zhu 2024](https://doi.org/10.1038/s41467-024-48649-8) |
| `stemtocvitro` | 2024 | mitotic age | `divisions` | 629 | multi-tissue, cultured human cells | 450K, EPICv1 | [Zhu 2024](https://doi.org/10.1038/s41467-024-48649-8) |
| `stoch` | 2024 | chronological age | `age_years` | 353 | sorted monocytes | 450K | [Tong 2024](https://doi.org/10.1038/s43587-024-00600-8) |
| `stocp` | 2024 | chronological age | `age_years` | 513 | sorted monocytes | 450K | [Tong 2024](https://doi.org/10.1038/s43587-024-00600-8) |
| `stocz` | 2024 | chronological age | `age_years` | 514 | sorted monocytes | 450K | [Tong 2024](https://doi.org/10.1038/s43587-024-00600-8) |
| `vidalbralo` | 2016 | chronological age | `age_years` | 8 | whole blood | 27K | [Vidal-Bralo 2016](https://doi.org/10.3389/fgene.2016.00126) |
| `weidner` | 2014 | chronological age | `age_years` | 3 | whole blood | 27K, bisulfite sequencing | [Weidner 2014](https://doi.org/10.1186/gb-2014-15-2-r24) |
| `yingadaptage` | 2024 | adaptive epigenetic age | `age_years_relative` | 999 | whole blood | 450K | [Ying 2024](https://doi.org/10.1038/s43587-023-00557-0) |
| `yingcausage` | 2024 | chronological age | `age_years` | 585 | whole blood | 450K | [Ying 2024](https://doi.org/10.1038/s43587-023-00557-0) |
| `yingdamage` | 2024 | damaging epigenetic age | `age_years_relative` | 1089 | whole blood | 450K | [Ying 2024](https://doi.org/10.1038/s43587-023-00557-0) |
| `zhangblup` | 2019 | chronological age | `age_years` | 319607 | whole blood, saliva | 450K, EPICv1 | [Zhang 2019](https://doi.org/10.1186/s13073-019-0667-1) |
| `zhangen` | 2019 | chronological age | `age_years` | 514 | whole blood, saliva | 450K, EPICv1 | [Zhang 2019](https://doi.org/10.1186/s13073-019-0667-1) |
| `zhangmortality` | 2017 | mortality risk | `mortality_log_hazard` | 10 | whole blood | 450K | [Zhang 2017](https://doi.org/10.1038/ncomms14617) |

### Querying it from code

<div class="panel-tabset">

#### Python

``` python
reg = fa.registry.load()
reg.filter(availability="bundled", scale_type="age_years")
reg.search("mortality")
reg.compatible_with(data)
reg.get("horvath2013")
```

#### R

``` r
list_clocks(tier = "bundled")
list_clocks(search = "mortality")
compatible_clocks(d)
clock_info("horvath2013")
```

</div>



# Chapter 21. Known discrepancies

Some clocks are scored from coefficients that differ from what their
paper describes: a feature count, a changed statistic, a constant.
FALCONAge scores the coefficients listed here, records the difference in
the clock’s registry entry, and raises it as a warning on every run that
scores the clock, so it appears in `warnings.csv` and the report rather
than only here.

<!-- BEGIN GENERATED: discrepancies -->

17 of the 68 catalogued clocks carry a `known_discrepancies` note: a
place where the paper, its coefficients and the implementations in
circulation disagree. Each is raised as a warning at score time.

| Clock | The disagreement |
|:---|:---|
| `bohlin` | The paper reports 96 CpGs; the coefficient set in circulation carries 251. Scores here will match other packages and not the figures printed in the paper. |
| `mccartneyalcohol`, `mccartneybmi`, `mccartneybodyfat`, `mccartneyeducation`, `mccartneyhdlcholesterol`, `mccartneyldlcholesterol`, `mccartneysmoking`, `mccartneytotalcholesterol`, `mccartneytotalhdlratio`, `mccartneywhr` | The paper defines this predictor as a weighted sum of beta values and applies no link function; the ROC analysis it reports dichotomises the phenotype, not the score. Packages that pass the sum through a sigmoid report a different number. The scale is relative_score, whose legal operations are correlate and rank, and a sigmoid is monotone, so no permitted result changes either way. |
| `phenoage` | Two constants circulate in the divisor of the Gompertz inversion: 0.090165, printed in Levine 2018 Supplement 1, and 0.09165, printed in Liu et al. 2018 (PLoS Med). FALCONAge uses 0.090165, the value BioAge corrected to in April 2026. Code still using 0.09165 differs by several years on the same input. |
| `phenoage` | Levine 2018 Table 1 prints alkaline phosphatase as 0.0019; Liu et al. 2018 print 0.00188, and BioAge carries the fit at full precision (0.001868778, every weight rounding to Table 1). FALCONAge uses Table 1 as printed, a mean 0.074 years above the full-precision fit on NHANES III; phenoage(df, coefficients=‘bioage’) uses BioAge’s. |
| `phenoage` | BioAge enters CRP as log(1 + CRP), its lncrp, where the paper uses log(CRP). On NHANES III that puts BioAge’s phenoage0 a mean 1.50 years above the paper’s formula (SD 0.45, more at low CRP; n = 8,924). FALCONAge follows the paper; phenoage(df, crp_transform=‘log1p’, coefficients=‘bioage’) reproduces phenoage0 exactly. |
| `weidner` | The third site is a substitution. The paper’s gamma is not cg17861230 but an unnamed CpG upstream of it, measured by pyrosequencing and better correlated with age; no array id was ever published for it. Every array implementation of this clock, including this one, puts cg17861230 in its place, and gamma carries 164.7 of the model against 26.4 and 23.7 for the two genuine probes. Treat the result as the published model evaluated on a near neighbour. |
| `yingadaptage`, `yingdamage` | Scored across three healthy cohorts in the FALCONAge corpus, this clock’s median offset against chronological age swings 162 years between datasets while Horvath2013’s swings 15; DamAge and AdaptAge move as near mirror images (r = -0.975) and the swing in their sum is only 33, so the cause is one dataset-level shift amplified by their opposing intercepts of +543.43 and -511.97 rather than a fault in either. The slope against age is sound (0.967 pooled for DamAge). The scale is therefore age_years_relative: the residual and group differences are defined, predicted-minus-chronological is not. |
| `yingadaptage` | The paper reports 1,000 CpGs; the coefficient set carries 999. The same off-by-one appears in all three Ying clocks, consistent with the paper’s total counting an intercept row as a feature. |
| `yingcausage` | The paper reports 586 CpGs; the coefficient set carries 585. The same off-by-one appears in all three Ying clocks, consistent with the paper’s total counting an intercept row as a feature. |
| `yingdamage` | The paper reports 1,090 CpGs; the coefficient set carries 1,089. The same off-by-one appears in all three Ying clocks, consistent with the paper’s total counting an intercept row as a feature. |
| `zhangmortality` | The paper defines this as an integer count of markers past quartile thresholds; the implementations in circulation compute a continuous weighted sum. They are different statistics, and the continuous form has no published cut-points. FALCONAge scores the continuous sum of the LASSO Cox weights, a log hazard (scale_type mortality_log_hazard), not the count. |

<!-- END GENERATED: discrepancies -->

The table is generated from the registry by `docs/build_catalogue.py`:
`reg.get(id).known_discrepancies` returns the full text, and
`res.manifest["warnings"]` carries whichever of them fired on your run.
The Ying clocks additionally carry a measured cohort-offset note, which
is why they sit on `age_years_relative` rather than `age_years`, [What
the calibration found, and what it turned
into](https://bhagesh-h.github.io/FALCONAge/methods/uncertainty.html#what-the-calibration-found-and-what-it-turned-into).



# Chapter 22. Published formulas and constants

### Exact published formulas and constants

#### PhenoAge (Levine 2018), clinical-biomarker version

The paper prints the model to four decimals in Table 1 and Supplementary
Table S1, with γ and the inversion to years in Supplement 1. BioAge
carries the same fit at full precision. **Both are in the paper’s units:
SI, except CRP, which enters as ln(CRP) with CRP in mg/dL.**

**As printed (Levine 2018 Table 1 and Supplement 1), FALCONAge’s
default:**

    xb = −19.9067
         − 0.0336 · albumin          (g/L)
         + 0.0095 · creatinine       (µmol/L)
         + 0.1953 · glucose          (mmol/L)
         + 0.0954 · ln(CRP)          (CRP in mg/dL)
         − 0.0120 · lymphocyte%      (%)
         + 0.0268 · MCV              (fL)
         + 0.3306 · RDW              (%)
         + 0.0019 · ALP              (U/L)
         + 0.0554 · WBC              (10³/µL)
         + 0.0804 · age              (years)

    γ        = 0.0076927
    m        = 1 − exp( −exp(xb) · (exp(120γ) − 1) / γ )
    PhenoAge = 141.50225 + ln( −0.00553 · ln(1 − m) ) / 0.090165

**Full precision (BioAge `phenoage0`, [BioAge
phenoage_calc.R](https://github.com/dayoonkwon/BioAge)),
`coefficients="bioage"`:**

    xb = −19.90667
         − 0.03359355 · albumin      (g/L)
         + 0.009506491 · creatinine  (µmol/L)
         + 0.1953192  · glucose      (mmol/L)
         + 0.09536762 · lncrp        (BioAge: lncrp = ln(1 + CRP), CRP in mg/dL)
         − 0.01199984 · lymphocyte%  (%)
         + 0.02676401 · MCV          (fL)
         + 0.3306156  · RDW          (%)
         + 0.001868778 · ALP         (U/L)
         + 0.05542406 · WBC          (10³/µL)
         + 0.08035356 · age          (years)

    m        = 1 − exp( (−1.51714 · exp(xb)) / 0.007692696 )
    PhenoAge = 141.50225 + ln( −0.0055305 · ln(1 − m) ) / 0.090165

Every full-precision weight rounds to its Table 1 value, so these are
the fit the table was printed from. On BioAge’s 8,924 NHANES III rows
the printed table puts PhenoAge a mean 0.074 years above the
full-precision fit (at most 0.14 years). With `coefficients="bioage"`
and `crp_transform="log1p"` FALCONAge reproduces `phenoage0` on those
rows to below 0.00001 years.

**Four transcription errors circulate**, and all four appear in the
equation printed in Liu et al. 2018 ([PLoS Med
15:e1002718](https://doi.org/10.1371/journal.pmed.1002718)): alkaline
phosphatase 0.00188 (Table 1: 0.0019), glucose 0.0195 (0.1953), RDW
0.3356 (0.3306), and the divisor 0.09165 (Supplement 1: 0.090165).
FALCONAge carried 0.00188 until this was checked. The divisor is the
costly one: BioAge corrected it in its April 2026 commit (“Update
PhenoAge constant to 0.090165 and recompute data”), and code still using
0.09165 shifts results by several years. Guard `m` away from 0 and 1 or
`ln(1 − m)` blows up.

**The units are part of the formula.** The weights are per SI unit. An
implementation that applies them to albumin in g/dL, creatinine and
glucose in mg/dL and CRP in mg/L without converting, as
mcp-phenoage-clock does
([phenoage.ts](https://github.com/199-mcp/mcp-phenoage-clock)), returns
nonsense: for the healthy 50-year-old of Appendix F it gives xb = 8.36
and a ten-year mortality of 1, where the converted inputs give xb =
−9.07 and a PhenoAge of 41.85 years.

**The CRP term is where BioAge departs from the paper.** Levine 2018
enters ln(CRP). BioAge’s `lncrp`, the variable its NHANES PhenoAge
(`phenoage0`) is computed from, is ln(1 + CRP)
([`data-raw/nhanes_all.R`](https://github.com/dayoonkwon/BioAge/blob/master/data-raw/nhanes_all.R),
`lncrp = log(1 + crp)`). The difference is not small. On NHANES III (n =
8,924) FALCONAge with ln(CRP) sits a mean 1.50 years below `phenoage0`
(SD 0.45), and not by a constant: ln(1 + CRP) − ln(CRP) = ln(1 + 1/CRP),
which is largest at low CRP. With ln(1 + CRP) the gap falls to the 0.074
years of coefficient rounding, and with `coefficients="bioage"` as well
it closes. FALCONAge follows the paper, records BioAge’s choice as a
known discrepancy, and offers
`phenoage(df, crp_transform="log1p", coefficients="bioage")` for
comparison with BioAge output. Every PhenoAge computed through BioAge
carries the shift.

**DNAm PhenoAge** is the methylation surrogate of this quantity: 513
CpGs, elastic net trained to predict the clinical PhenoAge. pyaging
exposes both, `phenoage` (clinical, blood chemistry) and `dnamphenoage`
(methylation).

#### pyaging generalised PhenoAge postprocess

pyaging’s implementation with λ = 0.0192 (pyaging’s
`PhenoAge.postprocess` in
[`src/pyaging/models/_models.py`](https://github.com/lucascamillomd/pyaging),
commit `e7267e9`):

    mortality = 1 − exp( −exp(x) · (exp(120λ) − 1) / λ )
    age       = 141.50225 + ln( −0.00553 · ln(1 − mortality) ) / 0.090165

#### BiT age (*C. elegans*) second correction

The published biological ages are rescaled to account for truncation of
the lifespan distribution. With median lifespan 372 h (15.5 d) and SD
192/3 h (8/3 d) ([AgingClock
biological_age_correction.py](https://github.com/Meyer-DH/AgingClock)):

    corrected(y) = y − erfinv( 0.5 − ( ( erf(((372 − y)/sd)/√2)/2 ) + 0.5 ) / 2 ) · √2 · 2 · sd

Lifespan fold-change with error propagation uses `uncertainties.ufloat`
with a 5% lifespan-assay bias and 0.5 d age-reporting bias; biological
age is rescaled as
`chronological_age × 15.5 / reported_median_lifespan`.

#### Zhang 2019 predictors

514 elastic-net probes or 319,607 BLUP probes, trained on 13,566
samples. Per-sample z-scoring of probes is mandatory ([Penalised linear
regression, the field’s
default](https://bhagesh-h.github.io/FALCONAge/methods/formulas.html)).
Missing values are filled with the per-probe mean across individuals;
probes that are NA across all individuals are dropped
([DNAm-based-age-predictor
pred.R](https://github.com/qzhang314/DNAm-based-age-predictor)). BLUP
degrades more gracefully with missing probes than EN. RMSE reported as
2.04 y, the most accurate chronological clock, and the one whose
acceleration stopped predicting mortality.

FALCONAge standardises over every probe the data carries, exactly as
`pred.R` does, before the weights are applied, and leaves an absent
model probe at 0 (the sample’s own mean) as `pred.R` does by restricting
the sum to the probes present. It refuses when the data carries less
than `min_coverage` of the 319,607 probes the models were fitted on,
because a subset’s per-sample mean and SD are not the array’s. On the
authors’ example (10 samples, all 485,512 probes of the 450K) it matches
`pred.R` to 1e-13 years for the elastic net and 5e-12 for BLUP.

The scope of that standardisation is the part implementations disagree
on. pyaging (commit `e7267e9`) takes the row mean and SD over the
model’s own inputs, 514 probes for the elastic net. On the same 10
samples that places the elastic-net estimate 9.9 to 22.7 years below
`pred.R` (mean 17.7), and its mean absolute error against chronological
age rises from 4.7 to 21.3 years. The BLUP estimate moves by 0.6 to 2.0
years, because its model already spans 319,607 of the 485,512 probes.

### Appendix F - Reproducing the four reference computations by hand

Small worked checks to use as smoke tests while building.

**PhenoAge, from conventional units.** Inputs: age 50, albumin 4.5 g/dL,
creatinine 0.9 mg/dL, glucose 90 mg/dL, CRP 1.0 mg/L, lymphocyte 30%,
MCV 90 fL, RDW 13%, ALP 70 U/L, WBC 6.0 ×10³/µL. Convert first, to the
units of Table 1: albumin 45 g/L, creatinine 79.5615 µmol/L, glucose
4.9950 mmol/L, CRP 0.1 mg/dL. Then

    xb = −19.9067 − 0.0336(45) + 0.0095(79.5615) + 0.1953(4.9950) + 0.0954·ln(0.1)
         − 0.0120(30) + 0.0268(90) + 0.3306(13) + 0.0019(70) + 0.0554(6.0) + 0.0804(50)
       = −9.0718
    m        = 1 − exp( −exp(xb) · (exp(120·0.0076927) − 1) / 0.0076927 )
    PhenoAge = 141.50225 + ln(−0.00553·ln(1 − m)) / 0.090165  =  41.85 years

Put the unconverted numbers into the same weights and xb is 8.36, m is
1, and there is no age.

**Horvath output transform.** A raw linear score of −0.5 becomes
`21·exp(−0.5) − 1 = 11.74` years; a score of 1.2 becomes
`21·1.2 + 20 = 45.2` years.

**Checked against the sources (2026-09-25).** 5.1 against Levine et
al. 2018, Table 1, Supplementary Table S1 and Supplement 1, and BioAge’s
`phenoage_calc.R`; 5.2 against pyaging at commit `e7267e9`; 5.3 against
`src/biological_age_correction.py` and
`src/lifespan_prediction_with_error_propagation.py` in
Meyer-DH/AgingClock; 5.4 against Zhang et al. 2019 (the 2.04-year RMSE
and the absent mortality association in both Lothian cohorts) and their
`pred.R`; and the Horvath transform against dnaMethyAge’s
`HorvathS2013_transform`.



# Chapter 23. Uncertainty, specimen and platform

Computing a clock correctly is half the problem. A correctly computed
number is still not interpretable on its own, which is what the field’s
own literature says and what few implementations do anything about.

Reliability is not a property of a clock alone. The intraclass
correlation is `1 - SE^2 / SD^2`, so the same technical error divided by
a narrower between-sample spread gives a worse coefficient without
anything about the assay having changed. A clock with an excellent
published ICC, measured on a cohort spanning sixty years of age, can be
unable to resolve anything in a trial whose participants are all within
a decade of each other. That is the calculation to run before
recruiting, not after.

#### The point estimate problem

Split one DNA sample, run both halves on the same array, and six
prominent clocks disagree with themselves by **up to nine years** ([Nat
Aging 2022](https://doi.org/10.1038/s43587-022-00248-2)). In adult whole
blood many 450K probes are measured unreliably, and the unreliable ones
replicate worse (Sugden et al., *Patterns* 2020;1:100014,
[doi:10.1016/j.patter.2020.100014](https://doi.org/10.1016/j.patter.2020.100014)).
A reader handed “DNAmAge = 54.2” cannot tell whether a 1.5-year change
between two draws is biology or the assay.

Every package in the field emits that bare number. FALCONAge emits an
interval, and the arithmetic behind it is short enough to check by hand.

#### Propagating measurement error

A linear clock is `score = f(b + wᵀβ)`. Give each probe a measurement
variance `σ²ⱼ` and the score’s variance follows directly:

$$\operatorname{Var} = f'(\text{raw})^2 \sum_j w_j^2\,\sigma_j^2$$

$$\sigma_j^2 = s_j^2\,(1 - \mathrm{ICC}_j)$$

with `s²ⱼ` the spread of probe *j* across the cohort in front of you and
`ICCⱼ` its published test-retest reliability. One matrix–vector product
per clock.

Three parts of that are load-bearing:

**The ICC table is measured, not assumed.**
`registry/data/probe_icc.csv.gz` carries 283,860 probes, derived from 69
blood samples each assayed twice on EPIC v1 and preprocessed with SeSAMe
2, using the two-way random-effects, absolute-agreement, single-rating
model, ICC(2,1) ([Epigenetics
2024](https://doi.org/10.1080/15592294.2024.2333660), CC BY 4.0). Its
citation, licence and SHA-256 go into the run manifest, because an
interval whose provenance is not recorded is worse than no interval.

**An imputed feature contributes its full variance.** Not the reduced
`s²(1−ICC)`. An imputed probe is the cohort mean or a published
reference; it carries no information about the sample in front of you.
Treating it as well-measured would make *worse data produce a narrower
interval*, which is the wrong direction and the part of the calculation
most likely to look like a bug.

**The output transform is differentiated, not linearised once.**
Horvath’s `anti_log_linear` has slope `21·eˣ` below zero and `21` above
it, so a child’s uncertainty and an adult’s scale differently from the
same raw error. Every op in the catalogue has an analytic derivative;
the four that destroy the information (`binarize`, `rank_normalize`,
`quantile_normalize`, `simplex_projection`) have none, and a chain
containing one **refuses** rather than skipping the step and returning a
confidently small interval.

**The sum assumes probe errors are independent, and they are not.**
Writing $\sum_j w_j^2 \sigma_j^2$ drops the cross term
$2\sum_{j<k} w_j w_k \operatorname{Cov}(\varepsilon_j, \varepsilon_k)$.
Chip position, plate and scanner drift move many probes together, and
those covariances are positive far more often than negative, so **the SE
reported here is a lower bound**, and not necessarily a tight one, since
a clock with hundreds of positively correlated terms can have a true SE
several times this.

The honest alternative does not exist: a $319{,}607 \times 319{,}607$
error covariance would need replicate designs nobody publishes. What
exists is a cross-check. `source="clock"` derives the same quantity from
a published clock-level ICC measured on real technical replicates, which
*does* contain the correlated part; when the two disagree substantially,
the clock-level figure is the one to believe and the gap is the
correlated component the probe path cannot see. `icc_from_replicates()`
closes it properly on your own duplicates. This is stated rather than
buried because an interval presented without its assumption is exactly
the false precision the section exists to argue against.

On the corpus, Horvath 2013 comes out at ±1.58 years of technical error
with an implied cohort ICC of 0.98; DunedinPoAm38 is the least
repeatable at 0.72; the 319,607-probe BLUP clock reaches 1.00, because a
weight spread thinly over the whole array averages the noise away. Read
all three as lower bounds, for the reason just given.

#### Prediction error is a different, larger question

`technical_se()` asks what a repeat of the same DNA would do.
`conformal_interval()` asks how far the number is from the truth.

Split conformal: take healthy whole-blood samples with known ages,
compute the absolute residuals, and the `⌈(n+1)(1−α)⌉/n` quantile is a
half-width that covers the truth at the stated rate on any exchangeable
sample. No distributional assumption is made, and the guarantee is
finite-sample. Conformalised quantile regression ([Genet Epidemiol
2025](https://doi.org/10.1002/gepi.70008)) is the better version,
widening the interval where the training data were sparse; it needs
fitted quantile models, so split conformal ships and the calibration
table reports the width per age band so a reader can see where one width
is lying.

The calibration takes whole blood, buffy coat and peripheral blood
leukocytes from adults, and nothing else. The corpus also labels sorted
populations and PBMC as blood, and on those a whole-blood clock’s
residual carries the cell type: on its healthy controls Hannum ran 21
years low on CD8+ T cells, and DNAm PhenoAge 24 years low on CD14+
monocytes and 40 on CD8+ T cells. Until that was noticed they were more
than half the calibration set, and the widths quoted composition as
clock error.

The limitation is not small and is stated in the output: every row
carries `exchangeable = False`. The calibration cohort is adult, blood,
and overwhelmingly of European ancestry. On a paediatric or non-European
cohort the guarantee does not transfer, and no widening factor would
make it.

#### What the calibration found, and what it turned into

The first calibration put Ying’s DamAge and AdaptAge 37–150 years from
chronological age. The obvious reading (“these are not age predictors”)
turned out to be wrong, and the measurement that settled it is worth
reproducing because the distinction it draws is a general one.

Regress predicted on chronological across the corpus’s healthy cohorts:

| clock            |     r |     slope | offset swing between datasets |
|------------------|------:|----------:|------------------------------:|
| horvath2013      | 0.905 |     0.982 |                          15 y |
| yingcausage      | 0.960 |     0.954 |                          15 y |
| **yingdamage**   | 0.909 | **0.967** |                     **162 y** |
| **yingadaptage** | 0.745 |     1.170 |                     **162 y** |

DamAge’s slope is 0.967, better than DNAmPhenoAge’s 1.199. It tracks
age. What it does not have is a **fixed origin**: its offset against
chronological age is −84 years in one healthy cohort and +78 in another.

The mechanism is visible in one number. DamAge and AdaptAge move as near
mirror images, **r = −0.975** across datasets, and the swing in their
*sum* is only 33 years against 162 for each alone. Their published
intercepts are **+543.43** and **−511.97**; a dataset-level shift in
overall methylation pushes one up and the other down by nearly the same
amount. One shared offset, hugely amplified, not two broken clocks.

So neither obvious label fits. `age_years` would license
`predicted − chronological`, which measures the cohort. `relative_score`
would forbid the residual and the group difference, the operations the
paper itself reports, and would contradict a unit of years and a
training target of chronological age, both of which are accurate.

They are `age_years_relative`: years, slope near one, no fixed zero.
`LEGAL_OPS` admits `residual`, `difference`, `mean` and `correlate`, and
refuses `acceleration`. The vocabulary had listed `acceleration` and
`residual` separately since v1.0 and nothing had ever read the
difference; this is the first clock that needs it.

#### Specimen type is not metadata

Same 91 people, three specimens ([bioRxiv
2025.09.16.673560](https://doi.org/10.1101/2025.09.16.673560),
CATSLife1, mean age 30.9):

| Comparison | Mean difference in clock age | Spearman between the two |
|----|----|----|
| **saliva vs buffy coat** | **3.83 – 16.46 years** | 0.45 – 0.69 |
| saliva vs PBMC | in the same direction | 0.25 – 0.55 |
| buffy coat vs PBMC | −0.06 – 0.39 years | 0.66 – 0.87 |

Read the two columns together, because separately each is reassuring.
Saliva and buffy coat clock ages correlate at up to 0.69, a correlation
most people would accept, and are still a decade apart. **Correlation is
not agreement**, and the check that gets run is the correlation. The
blood pair is the control: same study, same pipeline, difference under
half a year, which is what makes the saliva number a specimen effect
rather than noise.

Which clock matters as much as which specimen. On those samples a
pace-of-aging clock differed by −0.007 biological years per
chronological year (p = 0.486) where Hannum differed by 12.5 years, so
“this clock transfers” is a per-clock fact, not a per-tissue one, and
FALCONAge therefore holds the policy per clock. Across unrelated tissues
the published figure is 20–30 years (PMC12714307).

FALCONAge reads `obs["tissue"]` against each clock’s declared training
tissue and takes one of three positions:

`allow`  
the genuinely pan-tissue clocks. Nothing to say.

`warn`  
the default. Says what the clock was fitted on, what it was given, and
the measured discordance where one is published.

`refuse`  
twelve clocks whose training tissue has no counterpart elsewhere: four
placenta clocks, three cord-blood clocks, neonatal blood spots, buccal,
and three brain clocks. A placenta clock on blood is a category error,
not an offset.

Not every package holds a policy. methylclock 1.16.0’s `DNAmAge()` takes
no tissue argument and, with its default `clocks = "all"`, returns
PedBE, a buccal clock ([McEwen et al., PNAS
2020](https://doi.org/10.1073/pnas.1820843116)), for blood. FALCONAge
refuses PedBE on blood, so a clock missing from a FALCONAge run that
another package reported is sometimes the refusal working.

Cell-free DNA is refused by **every** clock regardless of policy. It is
not a tissue a clock generalises to; it is a fragment population shed
from many of them, and array clocks applied to it directly perform
poorly ([bioRxiv
2025.11.27.690895](https://doi.org/10.1101/2025.11.27.690895)).

And when `obs` has no `tissue` column at all, the run says so once,
because silence was the previous behaviour, and silence is the bug.

> [!NOTE]
>
> ### This check found a real error in our own test suite
>
> At first the integration tests scored the three Lee **placenta**
> clocks on GSE66459, which is umbilical **cord blood**, and asserted
> only that the answers looked like gestational weeks. They did, because
> gestational age is gestational age whatever tissue you read it from.
> That is exactly the failure the check exists to catch, and it caught
> it here first.

#### Probe loss, priced

`probe_loss()` has always said how much of a model is absent: count and
coefficient mass. It could not say what that costs. Now it can, because
the cost was measured: every full-450K matrix in the corpus, masked down
to each platform’s probe set and rescored, 206 samples across eight
datasets. The two right-hand columns are the same masks under two ways
of filling an absent CpG: the mean of the clock’s present CpGs in the
data, which FALCONAge used until the reference values existed, and the
clock’s reference value, which it uses now.

| clock           | platform | probes kept       | pooled fill | reference fill    |
|-----------------|----------|-------------------|-------------|-------------------|
| hrsinchphenoage | EPICv2   | 874 / 959         | +15.9 y     | +0.88 y           |
| yingcausage     | EPICv2   | 492 / 585         | +14.8 y     | −6.1 y            |
| hannum          | EPICv2   | 64 / 71           | −11.5 y     | +1.03 y           |
| lin             | EPICv2   | 96 / 99           | −9.3 y      | +0.84 y           |
| yingdamage      | EPICv2   | 1009 / 1089       | +9.1 y      | +0.66 y           |
| horvath2013     | EPICv2   | 339 / 353         | −2.5 y      | −1.3 y            |
| zhangblup       | EPICv2   | 286,843 / 319,607 | −0.46 y     | −0.46 y (no fill) |
| yingdamage      | EPICv1   | 1089 / 1089       | 0.00 y      | 0.00 y            |
| vidalbralo      | either   | 8 / 8             | 0.00 y      | 0.00 y            |

Most of what the pooled column prices is the fill, not the loss. A
pooled value sits near 0.5, and clock CpGs are often near 0 or 1: `lin`
lost three probes of ninety-nine and moved nine years. Filled from the
reference, the same masks move `hannum`, `lin`, `hrsinchphenoage` and
`yingdamage` by about a year or less; over the 19 rows on the years
scale whose fill changed, the median absolute shift fell from 3.36 to
0.66 years, and 38 of the 45 rows with a reference moved less. Those
numbers are out of sample: the blood reference is a mean over healthy
controls in this corpus, so each dataset was scored against it rebuilt
without that dataset (scored in-sample, `hannum` read −0.40 rather than
+1.03). `yingcausage` still moves six years, its 93 lost CpGs carrying
weight that no fixed value stands in for.

`zhangblup` fills nothing, because an absent probe drops out after the
per-sample standardisation, and loses ten percent of a 319,607-probe
model for under half a year at the median, a graceful degradation. Its
shift has two parts. Scored on the same samples, the lost probes alone
move the estimate by −0.64 y at the median, and restandardising over the
EPIC v2 probe set by +0.15 y. And the two rows at exactly zero are the
internal check: a clock that loses nothing must shift by nothing, and
does.

**What the table does not cover, so it is not read as covering it.** 86
rows: 43 clocks × two targets, EPIC v1 and EPIC v2. For the six
deconvolution entries the shift is not probe loss alone: a 450K matrix
is deconvolved with the 350-CpG legacy IDOL table and an EPIC one with
the 450-CpG table, so their rows price a change of array, which is what
a user moving between arrays sees (a median shift of at most 0.034 in a
cell-type proportion). 450K is the *reference* the shift is measured
from, so it cannot appear, its shift is zero by construction, not by
measurement. 27K is absent for a different reason: masking a 450K matrix
to 27,578 probes leaves most of these clocks below the coverage floor,
so what would be measured is the shift of a clock that would have been
refused anyway. And the reference cohort is 206 blood-derived samples of
adults, whole blood and leukocytes as well as PBMC and sorted T cells; a
shift measured there is a reasonable prior for another blood cohort and
not a correction factor for a different tissue.

The shift is **reported and never applied**. An automatic offset would
be a second number nobody can trace, which is the failure the
coefficient digests exist to prevent.

**Platform loss or probe QC.** A clock CpG can be absent for two
reasons, and only one of them is permanent. If the array does not carry
it, nothing recovers it. If the array carries it and the data lacks it,
it was measured and then removed, almost always by probe filters
(SNP-affected, cross-reactive, failed detection) that belong to an
epigenome-wide association study and not to clock scoring. A table
bundled with the package records which arrays (27K, 450K, EPIC v1, EPIC
v2) carry each clock CpG, built from the Illumina manifests and, for
EPIC v2, the Zhou lab InfiniumAnnotation manifest. With it,
`probe_loss()` counts the second kind in `n_removed_by_qc` and
`qc_removed_mass`, and `score()` warns (category `probe_qc`) once the
removed CpGs carry 1% of a clock’s \|coefficient\|. Nothing is
downloaded during scoring. On QC-filtered betas this separates CpGs
removed by a filter from CpGs the array never carried, and for a clock
such as DNAmTL the first kind can be most of what is missing. The remedy
is to score clocks on normalised but unfiltered betas.

#### Before the first array, and after the last

**`power()`** answers “how many samples to see this effect on this
clock”, and needs no data file. It refuses to default the standard
deviation, because n scales with its square and a guessed SD is a
guessed answer reported to three significant figures. Where a
reliability figure is available it splits the answer: at ICC 0.9, a
tenth of the sample size exists only to average out the instrument. That
is the arithmetic behind the published finding that the original clocks
need 3 to 16 replicates per condition where more reliable versions need
1 to 2.

**`consensus()`** implements the decision rule from *When to Trust
Epigenetic Clocks* \[77\]. Re-analysing six intervention datasets, the
authors found that in **five of six** exactly one clock reached
significance, a first-generation clock every time, and **four of those
five lost it** under multiple-testing correction. Their conclusion, in
their words: *a single significant clock after an intervention is likely
a false positive.* The same group later widened this to 16 clocks and 94
further biomarkers across the 51 longitudinal studies of TranslAGE
\[78\], which is where the clock grouping the FALCONAge report uses
comes from.

So `consensus()` tests every scored clock, corrects across the whole set
actually run, and returns a verdict rather than a table to pick from:
`supported` needs significance across at least two generations including
an outcome-trained clock and survival of Bonferroni; one lit clock is
`unsupported` whatever its p-value. The verdict string always carries
the counts it was computed from, a verdict without its arithmetic is an
oracle, and that is the opposite of the posture of this package.

**Repeated measures.** An intervention usually measures the same people
more than once, and treating each visit as a new person lets the spread
between people swamp the change within them. `design="paired"` tests
each person’s change from one visit to another (`subject_col` names the
person); `design="mixed"` fits `y ~ visit + (1 | person)` by REML, keeps
a person who missed a visit, and takes any number of visits, testing
them jointly. It reproduces `nlme::lme` on a design with missing visits:
estimates to 1e-7, standard errors to 1e-6, and the containment degrees
of freedom exactly ([Pinheiro & Bates
2000](https://doi.org/10.1007/978-1-4419-0318-1)). Both add `mdc95`, the
minimum detectable change 1.96·√2·SEM with the SEM the within-person SD
across the visits ([Weir 2005](https://doi.org/10.1519/15184.1)), and
flag a significant mean change that is smaller than it: twelve people
can make a group change of 1.6 SD of the change significant while no one
of them could be shown to have changed. That SEM holds day-to-day
biology and assay noise together; `technical_se()` gives the assay part
alone, and `variance_components()` separates the two when there are
technical replicates.

#### Evidence, attached to the score

`result.evidence()` returns what a value on this clock has been *shown*
to predict, with effect sizes and DOIs. Seeded from studies that tested
many clocks on one cohort under one protocol, so the rows are comparable
to each other, such as the observation that first-generation clocks
account for about 5 % of significant disease associations across 174
outcomes in 18,859 people ([Nat Commun
2025](https://doi.org/10.1038/s41467-025-66106-y)).

A row without a DOI is rejected at load time. An uncheckable effect size
looks identical to a checkable one in a table, and is worth less than
nothing.

The most useful row is not about any clock. Across 39 biomarkers in more
than 20,000 people, a clock’s chronological-age accuracy and its
mortality prediction are **uncorrelated: R = 0.12, P = 0.67** ([Nat
Aging 2025](https://doi.org/10.1038/s43587-025-00987-y)). That is the
empirical justification for `scale_type` and `LEGAL_OPS`, and it is the
reason “which clock is most accurate” is the wrong question.

#### What was deliberately not built

Recorded so it does not appear by accident.

- **No silent correction.** Batch reference, platform offset and
  interval are all reported. A score adjusted by an untraceable factor
  destroys the provenance discipline that is the reason to use this
  package.
- **No percentile against an unnamed population.** The same person reads
  as accelerated or decelerated depending on the comparator; a
  percentile without a cited reference cohort means different things to
  different readers.
- **No diagnostic thresholds.** None exist in the literature. Nothing
  here is coloured red above a cut-off.
- **No LLM dependency.** A scoring library whose output depends on a
  model that changes weekly is not reproducible.



# Chapter 24. Downstream statistics on an aging score

#### Association with chronological age

Pearson r, Spearman ρ, MAE, MedAE, RMSE, and the regression slope of BA
on CA. The slope is the diagnostic: penalised regression compresses
predictions toward the training mean, so slopes \< 1 are normal and
produce the well-documented systematic underestimation in older
subjects. Report the slope, not just r.

#### Mortality

Cox proportional hazards with the standardised score plus CA and sex as
covariates:

``` r
coxph(Surv(time, status) ~ scale(BA_advance) + age + gender, data)
```

Report the HR per SD with 95% CI. BioAge standardises the advance within
sex so the effect size means “one sex-specific SD of biological age
advancement” ([BioAge
table_surv.R](https://github.com/dayoonkwon/BioAge)). Observed HRs from
BioAge’s NHANES IV tables run 1.21–1.61 per SD across measures and
subgroups, with KDM advance, PhenoAge advance and homeostatic
dysregulation broadly comparable ([BioAge
README](https://github.com/dayoonkwon/BioAge)).

Additional model families worth supporting: time-dependent ROC/AUC,
Harrell’s C-index, competing risks (Fine–Gray), and SuperLearner
ensembles with out-of-fold predictions (the TwinGene/UK Biobank pipeline
uses 10-fold CV, optionally repeated across seeds).

#### Morbidity and phenotype

Logistic or Poisson models for prevalent and incident disease;
multimorbidity counts; frailty index; intrinsic capacity; grip strength
and gait speed; cognitive scores. Interaction tests for BA × (BMI, sex,
smoking, education) are standard in the epidemiological literature.

#### Group comparison and intervention response

The ComputAgeBench formulation, which is the cleanest published
statement of the problem ([ComputAge
benchmarking.py:339–397](https://github.com/ComputationalAgingLab/ComputAge)):

- **AA2**: is the age acceleration in an aging-accelerating condition
  (AAC) cohort greater than in healthy controls from the same study?
  One-sided Welch’s t-test if Δ is assumed normal, else one-sided
  Mann–Whitney U.
- **AA1**: is the age acceleration in an AAC cohort greater than zero,
  with no control group? One-sided one-sample t-test, else one-sided
  Wilcoxon signed-rank.
- Benjamini–Hochberg FDR correction is applied **per model across
  datasets**, then thresholded at 0.05.

For paired intervention designs, use paired tests on within-subject
deltas and report both the absolute change and the change relative to
the measurement’s own ICC.

#### Reliability

Intraclass correlation coefficient on technical replicates (same DNA,
two arrays) and on biological replicates (same person, short interval).
Pool across studies with Fisher-Z. The result to remember is from Sehgal
et al. (bioRxiv 2025.10.13.682176), on the TranslAGE platform:
**technical reproducibility does not predict biological reliability**. A
tool should surface each clock’s published ICC next to its prediction.



# Chapter 25. Benchmarking and validation

#### ComputAgeBench, the reference methodology

AA2 compares a condition group against its own healthy controls from the
same study, so a clock that over-predicts everybody gains nothing from
it. AA1 has no controls to compare against and asks only whether the
condition group’s acceleration sits above zero, which a uniformly
over-predicting clock passes everywhere. The total discounts the AA1
credit by the clock’s own median signed error on healthy controls,
measured on the same data, which is the correction that separates a
clock that detects disease from a clock with a broken intercept.

`computage` (Kriukov, Efimov, Kuzmina, Khrameeva, Dylov; bioRxiv
2024.06.06.597715; KDD ’25) \[36\].

**Premise.** MAE against chronological age is the wrong metric because a
perfect chronological oracle is useless. Instead, a good clock must show
higher age acceleration in people with *pre-defined aging-accelerating
conditions* (AACs) than in healthy controls.

**Data.** Benchmark split: **10,404 samples, 900,449 CpGs, 65 studies**.
Training split: **7,419 samples, 907,766 CpGs, 46 studies** (healthy
people only). Hosted on Hugging Face at `computage/computage_bench` as
per-study parquet plus a single `computage_bench_meta.tsv`.

**Condition classes** ([ComputAge
data_utils.py](https://github.com/ComputationalAgingLab/ComputAge)):

| Class | Conditions |
|----|----|
| HC | healthy control |
| CVD | AS (atherosclerosis), IHD, CVA (stroke) |
| ISD | IBD, HIV, HIV_TB |
| MBD | XOB (extreme obesity), T1D, T2D |
| MSD | OP (osteoporosis), RA |
| NDD | MS, PD, AD, CJD |
| RSD | TB, COPD |
| PGS | CGL (congenital generalised lipodystrophy), WS (Werner), HGPS (progeria) |

The full study table with GSE accessions, PMIDs, first authors, tissues,
sample counts and HC availability is [ComputAge
BenchBSB_table.csv](https://github.com/ComputationalAgingLab/ComputAge) -
66 rows. Highlights: GSE56046 (n = 1,202, atherosclerosis), GSE42861 (n
= 689, RA), GSE117859 (n = 608, HIV), GSE111629 (n = 572, PD), GSE59685
(n = 531, AD), GSE131752 (Werner, n = 48), GSE182991 (HGPS, n = 27),
GSE214297 (CGL, n = 16).

**Filters.** Tissues restricted to Blood, Saliva, Buccal (“BSB”). Age
limited to \[18, 90\], except progeria (PGS) which is exempt so that
young progeria patients are retained.

**Scoring.**

    AA2_score = number of AA2 datasets where FDR-adjusted p < 0.05
    AA1_score = number of AA1 datasets where FDR-adjusted p < 0.05
    MedAE     = median |prediction − age| over all healthy-control samples
    MedE      = median (prediction − age) over healthy controls          # the bias
    total     = AA2_score + AA1_score × (1 − max(0, MedE) / MedAE)

The bias penalty is the clever part: a clock that simply over-predicts
everyone’s age will pass AA1 trivially, so AA1 credit is discounted by
how much of the clock’s error is systematic positive bias ([ComputAge
benchmarking.py:427](https://github.com/ComputationalAgingLab/ComputAge)).

**Running it.** `fa.run_benchmark()` (R: `run_benchmark()`) computes
AA1, AA2 and the combined score on a scored, combined result; see
[Benchmarking](https://bhagesh-h.github.io/FALCONAge/analysis/benchmarking.html).

\1 - reliability validation

TranslAGE (Borrus et al., bioRxiv 2025.10.16.682960) harmonises 179
blood methylation datasets and precomputes 41 biomarker scores. On it,
Sehgal et al. (bioRxiv 2025.10.13.682176) measured technical and
biological ICCs for 18 clocks, pooled with Fisher-Z: technical
reproducibility did not predict biological reliability.

\1 in the new tool should do

1.  Chronological accuracy on healthy controls: MedAE, MAE, RMSE, r, ρ,
    slope, bias (MedE).
2.  AA1 and AA2 with configurable distributional assumption and FDR
    correction.
3.  Mortality: HR per SD, C-index, time-dependent AUC.
4.  Reliability: ICC from user-supplied replicate structure, with
    Fisher-Z pooling.
5.  Responsiveness: paired-design effect sizes with the measurement ICC
    reported alongside.
6.  Cross-clock agreement: Spearman matrix, hierarchical clustering,
    UMAP.
7.  A composite leaderboard using the ComputAgeBench total-score
    formula, with the components shown, never just the total.



# Chapter 26. 23. Building a clock of your own

The catalogue is other people’s clocks. This is the arithmetic of
fitting one, with the numbers the published clocks actually used.

### The objective

With $n$ samples and $p$ CpGs, $p \gg n$ always. Horvath had 8,000
samples against 21,369 candidate probes; a modern EPIC study has 850,000
columns and a few hundred rows. An unpenalised least-squares fit is not
identifiable, because $X^\top X$ is singular whenever $p > n$.
Penalisation is what makes the problem have an answer, not a refinement
on one.

$$
\hat{\beta} = \arg\min_{\beta} \left\{ \frac{1}{2n}\sum_{i=1}^{n}\left(y_i - \beta_0 - x_i^{\top}\beta\right)^2 + \lambda\left[\frac{1-\alpha}{2}\lVert\beta\rVert_2^2 + \alpha\lVert\beta\rVert_1\right] \right\}
$$

The two penalties do different work. The $\ell_1$ term has a corner at
zero, so its subgradient can hold a coefficient exactly at zero, which
is what performs selection. The $\ell_2$ term is smooth and shrinks
correlated predictors together rather than choosing between them, which
matters because neighbouring CpGs are strongly correlated and pure LASSO
picks among them close to arbitrarily.

| $\alpha$ | Name | Behaviour on correlated CpGs | Used by |
|---:|----|----|----|
| 1 | LASSO | Selects one per correlated group, close to arbitrarily | eFRS, the McCartney EpiScores |
| 0.5 | Elastic net | Keeps correlated groups together while still zeroing most coefficients | Horvath 2013 |
| 0 | Ridge | Shrinks everything, selects nothing | Rarely used alone |

Horvath fitted $\alpha = 0.5$ with $\lambda = 0.0226$ chosen by
cross-validation, over the 21,369 probes shared by the 27K and 450K
platforms that had fewer than ten missing values. That produced the 353
sites.

> [!IMPORTANT]
>
> ### The selected set is not the biology
>
> Rerun the same fit with a slightly different $\lambda$, a different
> fold split, or a different subset of samples, and a different CpG set
> comes out with almost identical accuracy. The correlated groups are
> interchangeable to the optimiser. This is one mechanism behind the
> discrepancies listed in section [Where the paper and the coefficients
> disagree](https://bhagesh-h.github.io/FALCONAge/clocks/discrepancies.html),
> and it is why two faithful implementations of the same clock can
> disagree on membership.

### Choosing the penalty honestly

$\lambda$ comes from $k$-fold cross-validation: fit on $k-1$ folds,
measure on the held-out one, take the $\lambda$ minimising mean
cross-validated error, or the largest $\lambda$ within one standard
error of it for a sparser model.

Any step that looked at the outcome must sit inside the loop. Selecting
CpGs by their correlation with age on the full dataset and then
cross-validating the fit on those CpGs leaks the held-out fold into the
selection, and the reported error is optimistic by an amount that cannot
be recovered afterwards.

### The age transform

Methylation changes quickly in childhood and slowly afterwards, so a
model linear in age fits adults and misses the first two decades.
Horvath regresses a transformed age and inverts afterwards, with
$A = 20$. Up to $A$,

$$
F(\text{age}) = \log(\text{age} + 1) - \log(A + 1),
$$

and above it,

$$
F(\text{age}) = \frac{\text{age} - A}{A + 1}.
$$

Both branches give 0 at $\text{age} = A$ and both have derivative
$1/(A+1)$ there, so $F$ is continuous and differentiable at the join.
The model predicts $F$; the reported age is $F^{-1}$ of the linear
predictor. Applying the inverse twice, or omitting it, is invisible in
an adult cohort because the branches nearly agree there, and badly wrong
in a paediatric one.

### Feature selection is not settled

Elastic net is the default rather than the optimum. Benchmarked on the
Hannum blood data (GSE40279, 656 samples, 473,035 CpGs, 10-fold
cross-validation, 80/20 split) by Li et al. 2022
([doi:10.1371/journal.pcbi.1009938](https://doi.org/10.1371/journal.pcbi.1009938)):

| Method | CpGs kept | R² | Median error |
|----|---:|---:|----|
| SelectKBest (2,000) then Boruta | 35 | 0.873 | 3.08 years |
| Boruta alone, or KBest alone | varies | 0.861 to 0.862 |  |
| Recursive elimination, 1% per iteration | varies | ≥ 0.81 |  |
| Genetic algorithm, most threshold methods | varies | 0.77 to 0.81 |  |
| Neural network on 65 features | 65 | 0.76 | found 61 CpGs no other method did |
| Elastic net, no prior selection | 276 | below five of the above |  |
| The five most-selected CpGs overall | 5 | 0.83 | 3.79 years |
| cg16867657 (ELOVL2) alone | 1 | 0.73 |  |

Two rows there are worth sitting with. A single CpG in ELOVL2 reaches R²
= 0.73, so most of what a 353-CpG clock knows about chronological age is
available from a handful of sites. And an unfiltered elastic net over
all 473,035 probes was beaten by five selection strategies, which is the
opposite of the usual intuition: past a point the extra probes
contribute noise rather than signal.

### Two metrics that disagree, and both are needed

$$
\text{MedAE} = \operatorname{median}_i\left|\hat{y}_i - y_i\right|, \qquad r = \operatorname{corr}(\hat{y}, y)
$$

Correlation is inflated by a wide age range and says nothing about bias.
Median absolute error is in years and says nothing about ordering. A
clock at r = 0.95 on a cohort spanning 20 to 90 may have an MAE of six
years; the same clock on a cohort spanning 55 to 65 may have r near zero
and the same MAE. Neither number is wrong and neither alone is
informative.

Expect the fitted slope of $\hat{y}$ on $y$ to fall below one.
Penalisation shrinks coefficients toward zero, which compresses
predictions toward the training mean, so the old read young and the
young read old. That is regression to the mean, a property of the
estimator rather than a defect of the cohort, and it leaves the residual
correlated with age unless the slope is corrected. It is why [age
acceleration](https://bhagesh-h.github.io/FALCONAge/analysis/acceleration.html)
is a residual on chronological age.

### The step that gets skipped

A model fitted to chronological age will correlate with chronological
age. Reporting that as validation is circular. The claim worth making is
about the residual: whether age acceleration associates with disease,
mortality or an intervention, on a cohort that was not used to fit the
model. Everything in section [Benchmarking and
validation](https://bhagesh-h.github.io/FALCONAge/methods/benchmarking.html)
applies to a clock you fitted exactly as it applies to a published one.

### What to publish

Feature list, weights, intercept, the preprocessing chain and the
postprocess, together and in the order they apply. A clock published
without its postprocess is the commonest source of the disagreements in
section [The layer that says what a score is
worth](https://bhagesh-h.github.io/FALCONAge/dev/modules.html#the-layer-that-says-what-a-score-is-worth),
because the next implementer has to guess whether an anti-log was
already applied, and a plausible wrong guess produces plausible wrong
ages.

### Fitting one here

`fa.fit_clock(data, target="age")` fits an elastic net to one cohort and
reports only predictions made out of fold: the cohort is split into
outer folds, lambda is chosen by cross-validation inside each training
part, and each held-out fold is predicted by a model that saw neither
its samples nor their role in choosing lambda. The estimator is glmnet’s
for a gaussian outcome, including its internal scaling of the outcome,
its lambda grid and `cv.glmnet`’s `lambda.1se` or `lambda.min`. It
reproduces glmnet 5.1’s path to within 1e-6 and chooses exactly the
lambdas that `cv.glmnet`’s rules give on glmnet’s own fold fits;
`cv.glmnet`’s returned lambdas can differ slightly, because its internal
fold fits differ from direct `glmnet` calls by about 1e-4 in MSE. A
missing value is filled with its feature’s mean in the training part it
falls in. The model fitted on everyone is returned for new samples, and
its accuracy is the out-of-fold one, not its fit. The result is a model
of this cohort and is labelled as one.

Beyond the elastic net, `fa.compare_learners()` puts several learners
side by side on the same outer folds (ridge, lasso, CpG pre-screening,
principal components, and with scikit-learn a random forest, gradient
boosting, support vector regression and a small neural network), and
reports the error of choosing among them with the choice repeated inside
each outer fold. That nested error is the honest one (Varma and Simon
2006, doi:10.1186/1471-2105-7-91); the best row of the table is not.
`groups=` keeps a person’s repeated visits, or a batch, on one side of
every split. A linear model, whichever learner produced it, is written
out with `ClockFit.to_clock()` and scored through the catalogue like any
other clock; see [Build a
clock](https://bhagesh-h.github.io/FALCONAge/own/compare.html), [Add a
clock](https://bhagesh-h.github.io/FALCONAge/own/add.html) and [Stack
clocks](https://bhagesh-h.github.io/FALCONAge/own/stack.html).



# Chapter 27. References

<!-- GENERATED by docs/build_references.py from docs/references.yml.
     Edit the YAML, not this file. -->

Citations across this site are numbers in square brackets and every one
of them points here. The numbering is global rather than per page, so a
source keeps its number wherever it is cited, and the same list is bound
into the PDF as its own chapter.

Where a source is available at a stable identifier the entry links to
it. Some of these are preprints and are cited as preprints on purpose:
the field moves faster than journal review, and a claim resting on one
is worth knowing about.

### Prior software this package builds on

<span id="ref-1">1</span>. de Lima Camillo LP. pyaging: a Python-based
compendium of GPU-optimized aging clocks. *Bioinformatics* 40(4):btae200
(2024). <https://doi.org/10.1093/bioinformatics/btae200>

<span id="ref-2">2</span>. Yu D, Li M, Linghu G, Hu Y, Hajdarovic KH,
Wang A, Singh R, Webb AE. CellBiAge: Improved single-cell age
classification using data binarization. *Cell Reports* 42(12):113500
(2023). - PMC10791072. <https://doi.org/10.1016/j.celrep.2023.113500>

### Foundational clocks

<span id="ref-3">3</span>. Bocklandt S et al. Epigenetic predictor of
age. *PLoS ONE* 6(6):e14821 (2011).
<https://doi.org/10.1371/journal.pone.0014821>

<span id="ref-4">4</span>. Hannum G et al. Genome-wide methylation
profiles reveal quantitative views of human aging rates. *Mol Cell*
49(2):359–367 (2013). <https://doi.org/10.1016/j.molcel.2012.10.016>

<span id="ref-5">5</span>. Horvath S. DNA methylation age of human
tissues and cell types. *Genome Biol* 14:R115 (2013).
<https://doi.org/10.1186/gb-2013-14-10-r115>

<span id="ref-6">6</span>. Weidner CI et al. Aging of blood can be
tracked by DNA methylation changes at just three CpG sites. *Genome
Biol* 15:R24 (2014). <https://doi.org/10.1186/gb-2014-15-2-r24>

<span id="ref-7">7</span>. Yang Z et al. Correlation of an epigenetic
mitotic clock with cancer risk. *Genome Biol* 17:205 (2016). - epiTOC
<https://doi.org/10.1186/s13059-016-1064-3>

<span id="ref-8">8</span>. Levine ME et al. An epigenetic biomarker of
aging for lifespan and healthspan. *Aging* 10(4):573–591 (2018).
<https://doi.org/10.18632/aging.101414>

<span id="ref-9">9</span>. Liu Z, Kuo P-L, Horvath S, Crimmins E,
Ferrucci L, Levine M. A new aging measure captures morbidity and
mortality risk across diverse subpopulations from NHANES IV. *PLoS Med*
15(12):e1002718 (2018). <https://doi.org/10.1371/journal.pmed.1002760>

<span id="ref-10">10</span>. Horvath S et al. Epigenetic clock for skin
and blood cells. *Aging* 10(7):1758–1775 (2018).
<https://doi.org/10.18632/aging.101508>

<span id="ref-11">11</span>. Lu AT et al. DNA methylation GrimAge
strongly predicts lifespan and healthspan. *Aging* 11(2):303–327 (2019).
<https://doi.org/10.18632/aging.101684>

<span id="ref-12">12</span>. Lu AT et al. DNA methylation GrimAge
version 2. *Aging* 14(23):9484–9549 (2022).
<https://doi.org/10.18632/aging.204434>

<span id="ref-13">13</span>. Zhang Q et al. Improved precision of
epigenetic clock estimates across tissues and its implication for
biological ageing. *Genome Med* 11:54 (2019).
<https://doi.org/10.1186/s13073-019-0667-1>

<span id="ref-14">14</span>. Belsky DW et al. Quantification of the pace
of biological aging in humans through a blood test, the DunedinPoAm DNA
methylation algorithm. *eLife* 9:e54870 (2020).
<https://doi.org/10.7554/elife.54870>

<span id="ref-15">15</span>. Belsky DW et al. DunedinPACE, a DNA
methylation biomarker of the pace of aging. *eLife* 11:e73420 (2022).
<https://doi.org/10.7554/elife.73420>

<span id="ref-16">16</span>. Higgins-Chen AT et al. A computational
solution for bolstering reliability of epigenetic clocks. *Nat Aging*
2:644–661 (2022). - PC clocks
<https://doi.org/10.1038/s43587-022-00248-2>

<span id="ref-17">17</span>. de Lima Camillo LP, Lapierre LR, Singh R. A
pan-tissue DNA-methylation epigenetic clock based on deep learning. *npj
Aging* 8:4 (2022). - AltumAge
<https://doi.org/10.1038/s41514-022-00085-y>

<span id="ref-18">18</span>. Lu AT et al. Universal DNA methylation age
across mammalian tissues. *Nat Aging* 3:1144–1166 (2023).
<https://doi.org/10.1038/s43587-023-00462-6>

<span id="ref-19">19</span>. Ying K et al. Causality-enriched epigenetic
age uncouples damage and adaptation. *Nat Aging* 4:231–246 (2024). -
CausAge, DamAge, AdaptAge <https://doi.org/10.1038/s43587-023-00557-0>

<span id="ref-20">20</span>. Teschendorff AE. A comparison of epigenetic
mitotic-like clocks for cancer risk prediction. *Genome Med* 12:56
(2020). The paper that introduces epiTOC2 and HypoClock, which is what
this entry is cited for. <https://doi.org/10.1186/s13073-020-00752-3>

<span id="ref-21">21</span>. Higgins-Chen AT, Levine ME et al. Systems
Age: a single blood methylation test to quantify aging heterogeneity
across 11 physiological systems. *Nat Aging* (2025).
<https://doi.org/10.1038/s43587-025-00958-3>

### Non-methylation clocks

<span id="ref-22">22</span>. Meyer DH, Schumacher B. BiT age: a
transcriptome-based aging clock near the theoretical limit of accuracy.
*Aging Cell* 20:e13320 (2021). <https://doi.org/10.1111/acel.13320>

<span id="ref-23">23</span>. Oh HS-H et al. Organ aging signatures in
the plasma proteome track health and disease. *Nature* 624:164–172
(2023). <https://doi.org/10.1038/s41586-023-06802-1>

<span id="ref-24">24</span>. Goeminne LJE et al. Plasma protein-based
organ-specific aging and mortality models unveil diseases as accelerated
aging of organismal systems. *Cell Metab* 37(1):205–222.e6 (2025).
<https://doi.org/10.1016/j.cmet.2024.10.005>

<span id="ref-25">25</span>. Tyshkovskiy A, Kholdina D, Davitadze M et
al. Universal transcriptomic hallmarks of mammalian ageing and
mortality. *Nature* 654(8117):173–188 (2026).
<https://doi.org/10.1038/s41586-026-10542-3>

<span id="ref-26">26</span>. Sun ED, Zhou OY, Hauptschein M, Rappoport
N, Xu L, Navarro Negredo P, Ling L, Rando TA, Zou J, Brunet A. Spatial
transcriptomic clocks reveal cell proximity effects in brain ageing.
*Nature* 638:160–171 (2025).
<https://doi.org/10.1038/s41586-024-08334-8>

<span id="ref-27">27</span>. Li W et al. Single-cell immune aging clocks
reveal inter-individual heterogeneity during infection and vaccination.
*Nat Aging* (2025). <https://doi.org/10.1038/s43587-025-00819-z>

<span id="ref-28">28</span>. Trapp A, Kerepesi C, Gladyshev VN.
Profiling epigenetic age in single cells. *Nat Aging* 1:1189–1201
(2021). - scAge <https://doi.org/10.1038/s43587-021-00134-3>

<span id="ref-29">29</span>. Bonder MJ et al. scEpiAge: an age predictor
highlighting single-cell ageing heterogeneity in mouse blood. *Nat
Commun* 15:7567 (2024). <https://doi.org/10.1038/s41467-024-51833-5>

<span id="ref-30">30</span>. Ren X, Kuan PF. RNAAgeCalc: a multi-tissue
transcriptional age calculator. *PLoS ONE* 15(8):e0237006 (2020).
<https://doi.org/10.1371/journal.pone.0237006>

<span id="ref-31">31</span>. Krištić J et al. Glycans are a novel
biomarker of chronological and biological ages. *J Gerontol A*
69(7):779–789 (2014). <https://doi.org/10.1093/gerona/glt202>

<span id="ref-32">32</span>. Putin E et al. Deep biomarkers of human
aging. *Aging* 8(5):1021–1033 (2016).
<https://doi.org/10.18632/aging.100968>

<span id="ref-33">33</span>. Hao M et al. Gompertz law-based biological
age (GOLD BioAge). *Adv Sci* 12(32) (2025).
<https://doi.org/10.1002/advs.202501765>

<span id="ref-34">34</span>. Chen Q, Dwaraka VB, Carreras-Gallo N et
al. OMICmAge quantifies biological age by integrating multi-omics with
electronic medical records. *Nat Aging* (2026).
<https://doi.org/10.1038/s43587-026-01073-7>

### Methods, tooling, benchmarking

<span id="ref-35">35</span>. Kwon D, Belsky DW. A toolkit for
quantification of biological age from blood chemistry and organ function
test data: BioAge. *GeroScience* 43:2795–2808 (2021).
<https://doi.org/10.1007/s11357-021-00480-5>

<span id="ref-36">36</span>. Kriukov D, Efimov E, Kuzmina EA, Khrameeva
EE, Dylov DV. ComputAgeBench: epigenetic aging clocks benchmark. bioRxiv
2024.06.06.597715; KDD ’25. <https://doi.org/10.1101/2024.06.06.597715>

<span id="ref-37">37</span>. Ying K et al. Biolearn, an open-source
library for biomarkers of aging / A unified framework for systematic
curation and evaluation of aging biomarkers. *Nat Aging* (2025).
<https://doi.org/10.1038/s43587-025-00987-y>

<span id="ref-38">38</span>. TranslAGE: a comprehensive platform for
systematic validation of epigenetic aging biomarkers. bioRxiv
2025.10.16.682960. <https://doi.org/10.1101/2025.10.16.682960>

<span id="ref-39">39</span>. Biological versus technical reliability of
epigenetic clocks and implications for disease prognosis and
intervention response. bioRxiv 2025.10.13.682176.
<https://doi.org/10.1101/2025.10.13.682176>

<span id="ref-40">40</span>. Teschendorff AE. Epigenetic ageing clocks:
statistical methods and emerging computational challenges. *Nat Rev
Genet* 26 (2025). <https://doi.org/10.1038/s41576-024-00807-w>

<span id="ref-41">41</span>. Zoller JA, Horvath S. MammalMethylClock R
package. bioRxiv 2023.09.06.556506.
<https://doi.org/10.1101/2023.09.06.556506>

<span id="ref-42">42</span>. Thrush KL, Higgins-Chen AT et al. R
methylCIPHER: a methylation clock investigational package. bioRxiv
2022.07.13.499978. <https://doi.org/10.1101/2022.07.13.499978>

<span id="ref-43">43</span>. de Lima Camillo LP, Horvath S, Wang B et
al. CpGPT: a foundation model for DNA methylation. bioRxiv
2024.10.24.619766. <https://doi.org/10.1101/2024.10.24.619766>

<span id="ref-44">44</span>. Varshavsky M et al. Accurate age prediction
from blood using a small set of DNA methylation sites and a cohort-based
machine learning algorithm. *Cell Rep Methods* 3(9):100567 (2023). -
GP-age <https://doi.org/10.1016/j.crmeth.2023.100567>

<span id="ref-45">45</span>. Liu Z et al. Underlying features of
epigenetic aging clocks in vivo and in vitro. *Aging Cell* 19(10):e13229
(2020). <https://doi.org/10.1111/acel.13229>

<span id="ref-46">46</span>. Porter HL et al. Many chronological aging
clocks can be found throughout the epigenome. *Aging Cell* 20:e13492
(2021). <https://doi.org/10.1111/acel.13492>

<span id="ref-47">47</span>. Nelson PG, Promislow DEL, Masel J.
Biomarkers for aging identified in cross-sectional studies tend to be
non-causative. *J Gerontol A* 75(3):466–472 (2020).
<https://doi.org/10.1093/gerona/glz174>

<span id="ref-48">48</span>. Ying K et al. ClockBase: a comprehensive
platform for biological age profiling in human and mouse. bioRxiv
2023.02.28.530532. <https://doi.org/10.1101/2023.02.28.530532>

<span id="ref-49">49</span>. Vasileiou et al. Multi-omics signatures of
organ clocks in biological aging and disease. *Aging Cell* (2026).
<https://doi.org/10.1111/acel.70518>

<span id="ref-50">50</span>. Liu et al. The evolving landscape of
clinical aging clocks: from epigenetic to multi-omics integration.
*Aging Cell* (2026). <https://doi.org/10.1111/acel.70579>

<span id="ref-51">51</span>. Turning back time: a comprehensive list of
interventions that decrease next-generation epigenetic aging clocks in
humans. *Front Genet* (2026).
<https://doi.org/10.3389/fgene.2026.1836446>

<span id="ref-52">52</span>. Waziry R et al. Effect of long-term caloric
restriction on DNA methylation measures of biological aging in healthy
adults from the CALERIE trial. *Nat Aging* 3:248–257 (2023).
<https://doi.org/10.1038/s43587-022-00357-y>

<span id="ref-53">53</span>. DeepStrataAge: an interpretable
deep-learning clock. *npj Aging* (2026).
<https://doi.org/10.1038/s41514-026-00358-w>

<span id="ref-54">54</span>. GraphAge: unleashing the power of graph
neural networks to decode epigenetic aging. *PNAS Nexus* 4(6):pgaf177
(2025). <https://doi.org/10.1093/pnasnexus/pgaf294>

### Biology of aging

<span id="ref-55">55</span>. López-Otín C, Blasco MA, Partridge L,
Serrano M, Kroemer G. The hallmarks of aging. *Cell* 153(6):1194–1217
(2013). <https://doi.org/10.1016/j.cell.2013.05.039>

<span id="ref-56">56</span>. López-Otín C, Blasco MA, Partridge L,
Serrano M, Kroemer G. Hallmarks of aging: an expanding universe. *Cell*
186(2):243–278 (2023). <https://doi.org/10.1016/j.cell.2022.11.001>

<span id="ref-57">57</span>. Vijg J, Dong X. Pathogenic mechanisms of
somatic mutation and genome mosaicism in aging. *Cell* 182(1):12–23
(2020). <https://doi.org/10.1016/j.cell.2020.06.024>

<span id="ref-58">58</span>. Cagan A et al. Somatic mutation rates scale
with lifespan across mammals. *Nature* 604:517–524 (2022).
<https://doi.org/10.1038/s41586-022-04618-z>

<span id="ref-59">59</span>. Horvath S, Raj K. DNA methylation-based
biomarkers and the epigenetic clock theory of ageing. *Nat Rev Genet*
19:371–384 (2018). <https://doi.org/10.1038/s41576-018-0004-3>

<span id="ref-60">60</span>. Field AE et al. DNA methylation clocks in
aging: categories, causes, and consequences. *Mol Cell* 71(6):882–895
(2018). <https://doi.org/10.1016/j.molcel.2018.08.008>

<span id="ref-61">61</span>. Moqri M et al. Biomarkers of aging for the
identification and evaluation of longevity interventions. *Cell*
186(18):3758–3775 (2023). <https://doi.org/10.1016/j.cell.2023.08.003>

### Sources traced while implementing the clocks they describe

<span id="ref-62">62</span>. Shireby GL, Davies JP, Francis PT et
al. Recalibrating the epigenetic clock: implications for assessing
biological age in the human cortex. *Brain* 143(12):3763-3775 (2020).
Supplementary Table 3 carries the 347 weights the cortical clock uses
here. <https://doi.org/10.1093/brain/awaa334>

<span id="ref-63">63</span>. McCartney DL, Hillary RF, Stevenson AJ et
al. Epigenetic prediction of complex traits and death. *Genome Biology*
19:136 (2018). Additional file 1 carries the ten EpiScore weight sets.
<https://doi.org/10.1186/s13059-018-1514-1>

<span id="ref-64">64</span>. Horvath S. Putting epigenetic aging clocks
on trial. *Nature Medicine* (2026). Asks whether a methylation clock
behaves as a surrogate endpoint should, which is the question a score
has to survive before it is used to judge an intervention.
<https://doi.org/10.1038/s41591-026-04524-1>

### Mechanism, limits and translation

<span id="ref-65">65</span>. Tong H, Dwaraka VB, Chen Q et
al. Quantifying the stochastic component of epigenetic aging. *Nature
Aging* 4(6):886-901 (2024). Across 22,770 blood samples from 25 cohorts,
66 to 75 per cent of Horvath’s accuracy is reproducible by drift alone,
rising to about 90 per cent for Zhang and falling to about 63 per cent
for PhenoAge. <https://doi.org/10.1038/s43587-024-00600-8>

<span id="ref-66">66</span>. Tarkhov AE, Denisov KA, Fedichev PO. Aging
clocks based on accumulating stochastic variation. *Nature Aging*
4(6):871-885 (2024). <https://doi.org/10.1038/s43587-024-00619-x>

<span id="ref-67">67</span>. Meyer DH, Schumacher B. Epigenetic drift
underlies epigenetic clock signals, but displays distinct responses to
lifespan interventions, development, and cellular dedifferentiation.
*Aging* 16(2) (2024). <https://doi.org/10.18632/aging.205503>

<span id="ref-68">68</span>. From population science to the clinic?
Limits of epigenetic clocks as personal biomarkers. *Epigenomics*
17:1447-1461 (2025). PMC12714307. The source of the cross-tissue 20 to
30 year error figure and the replicate spread this package cites at
score time. <https://doi.org/10.1080/17501911.2025.2603880>

<span id="ref-69">69</span>. Fahy GM et al. Reversal of epigenetic aging
and immunosenescent trends in humans. *Aging Cell* 18(6):e13028 (2019).
The TRIIM trial: nine men, no control arm.
<https://doi.org/10.1111/acel.13028>

### Beyond the clock score: disorder, repertoire and coefficient mass

<span id="ref-70">70</span>. Mei X, Blanchard J, Luellen C, Conboy MJ,
Conboy IM. Fail-tests of DNA methylation clocks, and development of a
noise barometer for measuring epigenetic pressure of aging and disease.
*Aging* 15:8552-8575 (2023). The barometer implemented as
`fa.noise_barometer`: a summed per-site standard deviation over
cytosines whose variance rises with age.
<https://doi.org/10.18632/aging.205046>

<span id="ref-71">71</span>. Nachun D, Lu AT, Bick AG, Natarajan P,
Weinstock J, Szeto MD et al. Clonal hematopoiesis associated with
epigenetic aging and clinical outcomes. *Aging Cell* 20:e13366 (2021).
The myeloid clonality result: 1.31 years of acceleration on GrimAge to
3.08 on extrinsic EEAA, with DNMT3A and TET2 producing opposing
genome-wide patterns. <https://doi.org/10.1111/acel.13366>

<span id="ref-72">72</span>. Salas LA, Zhang Z, Koestler DC, Butler RA,
Hansen HM, Molinaro AM, Wiencke JK, Kelsey KT, Christensen BC. Enhanced
cell deconvolution of peripheral blood using DNA methylation for
high-resolution immune profiling. *Nature Communications* 13:761 (2022).
The twelve-subset EPIC IDOL-Ext reference that resolves naive and memory
CD4T and CD8T. <https://doi.org/10.1038/s41467-021-27864-7>

<span id="ref-73">73</span>. Tomusiak A, Floro A, Tiwari R, Riley R,
Matsui H, Andrews N, Kasler H, Verdin E. Development of an epigenetic
clock resistant to changes in immune cell composition. *Communications
Biology* 7:934 (2024). IntrinClock. Composition-resistant is not
clonality-resistant, and the two invariances are separate claims.
<https://doi.org/10.1038/s42003-024-06609-4>

<span id="ref-74">74</span>. Zhang Z, Reynolds SR, Stolrow HG, Chen JQ,
Christensen BC, Salas LA. Deciphering the role of immune cell
composition in epigenetic age acceleration: insights from cell-type
deconvolution applied to human blood epigenetic clocks. *Aging Cell*
23:e14071 (2024). Nine or more of twelve cell types associate
significantly with age acceleration in most of six widely used clocks.
<https://doi.org/10.1111/acel.14071>

<span id="ref-75">75</span>. Cruz-Gonzalez A, Okpala U, Gu C, Gomez A,
Mews P, Vance JM et al. Methylation clocks fail to generalize across
genetically admixed individuals. *eLife* (2026). The accuracy loss that
motivates measuring each clock’s meQTL exposure from its coefficients.
<https://doi.org/10.7554/eLife.105343>

<span id="ref-76">76</span>. Patel S, Schwarz M, Riege K, Varshavsky M,
Kestler HA et al. An improved epigenetic age estimation with TFMethyl
Clock reveals DNA methylation changes during aging in transcription
factor binding sites. bioRxiv 2025.10.07.680024. A preprint. Its central
finding is that most CpGs used by established clocks do *not* overlap
known transcription factor binding sites, which is the motivation for
measuring coefficient mass against an annotation rather than assuming
it. <https://doi.org/10.1101/2025.10.07.680024>

<span id="ref-77">77</span>. Borrus DS, Sehgal R, Armstrong JF, Kasamoto
J, Gonzalez J, Higgins-Chen A. When to Trust Epigenetic Clocks: Avoiding
False Positives in Aging Interventions. bioRxiv 2024.10.22.619720
(2024). PMC11526921. The decision rule `consensus()` implements: across
six intervention datasets, five had exactly one significant clock, a
first-generation clock every time, four of those five lost it under
multiple-testing correction, and in no case did the principal-component
version of the same clock corroborate.
<https://doi.org/10.1101/2024.10.22.619720>

<span id="ref-78">78</span>. Sehgal R, Borrus DS, Armstrong JF, Gonzalez
J, Kasamoto J, Markov Y et al. Responsiveness of epigenetic aging
biomarkers to longevity interventions in humans. *Nature Medicine*
(2026). The published successor to \[77\] by the same group, widened to
16 clocks and 94 further biomarkers across the 51 longitudinal studies
of the TranslAGE database. The source of the clock grouping the
FALCONAge report uses. <https://doi.org/10.1038/s41591-026-04562-9>
